import { Construct } from "constructs";
import * as atlas from "../../index";
import { ClusterProps, DatabaseUserProps, IpAccessListProps } from "../common/props";
export interface EncryptionAtRestProps {
    /**
     * ID of an AWS IAM role authorized to manage an AWS customer master key.
     *
     * @schema AwsKms#RoleID
     */
    readonly roleId: string;
    /**
     * The AWS customer master key used to encrypt and decrypt the MongoDB master keys.
     *
     * @schema AwsKms#CustomerMasterKeyID
     */
    readonly customerMasterKeyId: string;
    /**
     * Specifies whether Encryption at Rest is enabled for an Atlas project. To disable Encryption at Rest, pass only this parameter with a value of false. When you disable Encryption at Rest, Atlas also removes the configuration details.
     * Default Value: true
     * @schema AwsKms#Enabled
     */
    readonly enabledEncryptionAtRest?: boolean;
    /**
     * The AWS region in which the AWS customer master key exists.
     *
     * @schema AwsKms#Region
     */
    readonly region?: string;
}
export interface AtlasEncryptionAtRestExpressProps {
    readonly cluster?: ClusterProps;
    readonly accessList?: IpAccessListProps;
    readonly encryptionAtRest: EncryptionAtRestProps;
    readonly databaseUser?: DatabaseUserProps;
    readonly profile?: string;
    readonly projectId: string;
}
export declare class AtlasEncryptionAtRestExpress extends Construct {
    readonly encryptionAtRest: atlas.CfnEncryptionAtRest;
    readonly cluster?: atlas.CfnCluster;
    readonly accessList?: atlas.CfnProjectIpAccessList;
    readonly databaseUser?: atlas.CfnDatabaseUser;
    constructor(scope: Construct, id: string, props: AtlasEncryptionAtRestExpressProps);
}
