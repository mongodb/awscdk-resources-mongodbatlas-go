import { aws_iam as iam } from "aws-cdk-lib";
import { Construct } from "constructs";
export declare const AtlasBasicResources: string[];
export declare class MongoAtlasBootstrapProps {
    /**
     * The IAM role name for CloudFormation Extension Execution.
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/registry-public.html
     * @default auto generat the name.
     */
    readonly roleName: string;
    /**
     * The secret profile name for MongoDB Atlas.
     * @default generate a dummy secret.
     * @see https://github.com/mongodb/mongodbatlas-cloudformation-resources/tree/master#2-configure-your-profile
     */
    readonly secretProfile: string;
    /**
     * List of strings representing mongoDB atlas types to activate.
     * the exported AtlasBasicResources can be used for AtlasBasic resources
     * if not provided non resources will be activated
     * @example typesToActivate=["Cluster","Project"] this will actiate MongoDB::Atlas::Project && MongoDB::Atlas::Cluster
     */
    readonly typesToActivate?: string[];
}
/**
 * Generate the CFN extension execution role.
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/registry-public.html
 */
export declare class MongoAtlasBootstrap extends Construct {
    readonly role: iam.IRole;
    constructor(scope: Construct, id: string, props?: MongoAtlasBootstrapProps);
}
export declare class MongoSecretProfile extends Construct {
    constructor(scope: Construct, id: string, profileName: string);
}
