import { Construct } from "constructs";
import * as atlas from "../../index";
import { AtlasBasicProps } from "../common/props";
/**
 * @description
 * @export
 * @class AtlasBasic
 * @extends {Construct}
 */
export declare class AtlasBasic extends Construct {
    /**
     * @description
     * @type {project.CfnProject}
     * @memberof AtlasBasic
     */
    readonly mProject: atlas.CfnProject;
    /**
     * @description
     * @type {atlas.CfnCluster}
     * @memberof AtlasBasic
     */
    readonly mCluster: atlas.CfnCluster;
    /**
     * @description
     * @type {user.CfnDatabaseUser}
     * @memberof AtlasBasic
     */
    readonly mDBUser: atlas.CfnDatabaseUser;
    /**
     * @description
     * @type {ipAccessList.CfnProjectIpAccessList}
     * @memberof AtlasBasic
     */
    readonly ipAccessList: atlas.CfnProjectIpAccessList;
    /**
     * Creates an instance of AtlasBasic.
     * @param {Construct} scope
     * @param {string} id
     * @param {AtlasBasicProps} props
     * @memberof AtlasBasic
     */
    constructor(scope: Construct, id: string, props: AtlasBasicProps);
}
