import * as ec2 from "aws-cdk-lib/aws-ec2";
import { Construct } from "constructs";
import { CfnPrivateEndpointAws, CfnPrivateEndpointService } from "../../index";
import { AtlasBasic } from "../atlas-basic";
import { AtlasBasicProps } from "../common/props";
/**
 * @description
 * @export
 * @class AtlasBasicPrivateEndpoint
 * @extends {Construct}
 */
export declare class AtlasBasicPrivateEndpoint extends Construct {
    readonly atlasBasic: AtlasBasic;
    readonly privateEndpointService: CfnPrivateEndpointService;
    readonly awsPrivateEndpoint: ec2.CfnVPCEndpoint;
    readonly privateEndpointAws: CfnPrivateEndpointAws;
    /**
     * Creates an instance of AtlasBasicPrivateEndpoint.
     * @param {Construct} scope
     * @param {string} id
     * @param {AtlasBasicPrivateEndpointProps} props
     * @memberof AtlasBasicPrivateEndpoint
     */
    constructor(scope: Construct, id: string, props: AtlasBasicPrivateEndpointProps);
}
/**
 * @description
 * @export
 * @interface AtlasBasicPrivateEndpointProps
 */
export interface AtlasBasicPrivateEndpointProps {
    readonly profile?: string;
    /**
     * @description AWS Region
     * @type {string}
     * @default us-east-1
     * @memberof AtlasPrivateEndpointProps
     */
    readonly region?: string;
    /**
     * @description
     * @type {AtlasBasicProps}
     * @memberof AtlasPrivateEndpointProps
     */
    readonly atlasBasicProps: AtlasBasicProps;
    /**
     * @description
     * @type {CfnPrivateEndpointProps}
     * @memberof AtlasPrivateEndpointProps
     */
    readonly privateEndpointProps: PrivateEndpointProps;
}
/**
 * @description
 * @export
 * @interface PrivateEndpointProps
 */
export interface PrivateEndpointProps {
    /**
     * @description AWS VPC ID (like: vpc-xxxxxxxxxxxxxxxx) (Used For Creating the AWS VPC Endpoint)
     * @type {string}
     * @memberof PrivateEndpointProps
     */
    readonly awsVpcId: string;
    /**
     * @description AWS VPC Subnet ID (like: subnet-xxxxxxxxxxxxxxxxx) (Used For Creating the AWS VPC Endpoint)
     * @type {string}
     * @memberof PrivateEndpointProps
     */
    readonly awsSubnetId: string;
}
