import { Construct } from "constructs";
import { CfnEncryptionAtRest } from "../../index";
export interface AtlasEncryptionAtRestProps {
    /**
     * ID of an AWS IAM role authorized to manage an AWS customer master key.
     *
     * @schema AwsKms#RoleID
     */
    readonly roleId: string;
    /**
     * The AWS customer master key used to encrypt and decrypt the MongoDB master keys.
     *
     * @schema AwsKms#CustomerMasterKeyID
     */
    readonly customerMasterKeyId: string;
    /**
     * Specifies whether Encryption at Rest is enabled for an Atlas project. To disable Encryption at Rest, pass only this parameter with a value of false. When you disable Encryption at Rest, Atlas also removes the configuration details.
     * Default Value: true
     * @schema AwsKms#Enabled
     */
    readonly enabled?: boolean;
    /**
     * The AWS region in which the AWS customer master key exists.
     * Default Value: US_EAST_1
     * @schema AwsKms#Region
     */
    readonly region?: string;
    /**
     * Unique identifier of the Atlas project to which the user belongs.
     *
     * @schema CfnEncryptionAtRestProps#ProjectId
     */
    readonly projectId: string;
    /**
     * The profile is defined in AWS Secret manager.
     * See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnEncryptionAtRestProps#Profile
     */
    readonly profile?: string;
}
/**
 *
 *
 * @export
 * @class AtlasEncryptionAtRest
 * @extends {Construct}
 */
export declare class AtlasEncryptionAtRest extends Construct {
    /**
     *
     *
     * @type {CfnEncryptionAtRest}
     * @memberof AtlasEncryptionAtRest
     */
    readonly cfnEncryptionAtRest: CfnEncryptionAtRest;
    constructor(scope: Construct, id: string, props: AtlasEncryptionAtRestProps);
}
