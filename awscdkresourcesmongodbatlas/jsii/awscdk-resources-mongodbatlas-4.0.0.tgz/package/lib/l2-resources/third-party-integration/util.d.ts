import { ThirdPartyIntegrationProps } from "./thirdPartyIntegrationBase";
/**
 * This method validates that all required properties are present.
 * @param props
 */
export declare const validate: (props: ThirdPartyIntegrationProps) => void;
export declare const getPropUndefinedMsg: (prop: string) => string;
