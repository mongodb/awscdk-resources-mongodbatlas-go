import { Construct } from "constructs";
import { ThirdPartyIntegrationProps } from "./thirdPartyIntegrationBase";
import { CfnThirdPartyIntegration } from "../../index";
export interface MicrosoftTeamsIntegrationProps extends ThirdPartyIntegrationProps {
    /**
     * Endpoint web address of the Microsoft Teams webhook to which MongoDB Cloud sends notifications.
     */
    readonly microsoftTeamsWebhookUrl: string;
}
export declare class MicrosoftTeamsIntegration extends Construct {
    readonly cfnThirdPartyIntegration: CfnThirdPartyIntegration;
    constructor(scope: Construct, id: string, props: MicrosoftTeamsIntegrationProps);
}
