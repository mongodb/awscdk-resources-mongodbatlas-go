export interface ThirdPartyIntegrationProps {
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     */
    readonly projectId: string;
    /**
     * Atlas API keys.
     */
    readonly profile?: string;
}
