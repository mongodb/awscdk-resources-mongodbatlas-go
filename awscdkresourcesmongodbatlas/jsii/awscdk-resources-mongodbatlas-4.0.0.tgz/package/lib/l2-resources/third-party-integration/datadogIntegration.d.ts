import { Construct } from "constructs";
import { ThirdPartyIntegrationProps } from "./thirdPartyIntegrationBase";
import { CfnThirdPartyIntegration } from "../../index";
export declare enum DatadogRegion {
    US = "US",
    EU = "EU",
    US3 = "US3",
    US5 = "US5"
}
export interface DatadogIntegrationProps extends ThirdPartyIntegrationProps {
    /**
     * Key that allows MongoDB Cloud to access your Datadog account.
     */
    readonly apiKey: string;
    /**
     * Two-letter code that indicates which regional URL MongoDB uses to access the Datadog API.
     */
    readonly region: DatadogRegion;
    /**
     * Flag that indicates whether to include user-defined resource tags when sending metrics and alerts to Datadog.
     */
    readonly sendUserProvidedResourceTags?: boolean;
}
export declare class DatadogIntegration extends Construct {
    readonly cfnThirdPartyIntegration: CfnThirdPartyIntegration;
    constructor(scope: Construct, id: string, props: DatadogIntegrationProps);
}
