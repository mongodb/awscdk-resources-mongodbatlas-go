import { Construct } from "constructs";
import { ThirdPartyIntegrationProps } from "./thirdPartyIntegrationBase";
import { CfnThirdPartyIntegration } from "../../index";
export declare enum PagerDutyRegion {
    US = "US",
    EU = "EU"
}
export interface PagerDutyIntegrationProps extends ThirdPartyIntegrationProps {
    /**
     * Service key associated with your PagerDuty account.
     */
    readonly serviceKey: string;
    /**
     * PagerDuty region that indicates the API Uniform Resource Locator (URL) to use.
     */
    readonly region: PagerDutyRegion;
}
export declare class PagerDutyIntegration extends Construct {
    readonly cfnThirdPartyIntegration: CfnThirdPartyIntegration;
    constructor(scope: Construct, id: string, props: PagerDutyIntegrationProps);
}
