import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Grants temporary access to MongoDB employees for a specific cluster. This allows MongoDB support engineers to access cluster infrastructure, database logs, or app services sync data for troubleshooting purposes.
 *
 * @schema CfnMongoDbEmployeeAccessGrantProps
 */
export interface CfnMongoDbEmployeeAccessGrantProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnMongoDbEmployeeAccessGrantProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project. Use the [/groups](#tag/Projects/operation/listProjects) endpoint to retrieve all projects to which the authenticated user has access.
     *
     * **NOTE**: Groups and projects are synonymous terms. Your group id is the same as your project id. For existing groups, your group/project id remains the same. The resource and corresponding endpoints use the term groups.
     *
     * @schema CfnMongoDbEmployeeAccessGrantProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Human-readable label that identifies this cluster.
     *
     * @schema CfnMongoDbEmployeeAccessGrantProps#ClusterName
     */
    readonly clusterName: string;
    /**
     * Level of access to grant to MongoDB Employees. Possible values are CLUSTER_DATABASE_LOGS, CLUSTER_INFRASTRUCTURE or CLUSTER_INFRASTRUCTURE_AND_APP_SERVICES_SYNC_DATA.
     *
     * @schema CfnMongoDbEmployeeAccessGrantProps#GrantType
     */
    readonly grantType: string;
    /**
     * Expiration date for the employee access grant in ISO 8601 date and time format in UTC.
     *
     * @schema CfnMongoDbEmployeeAccessGrantProps#ExpirationTime
     */
    readonly expirationTime: Date;
}
/**
 * Converts an object of type 'CfnMongoDbEmployeeAccessGrantProps' to JSON representation.
 */
export declare function toJson_CfnMongoDbEmployeeAccessGrantProps(obj: CfnMongoDbEmployeeAccessGrantProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::MongoDbEmployeeAccessGrant`
 *
 * @cloudformationResource MongoDB::Atlas::MongoDbEmployeeAccessGrant
 * @stability external
 */
export declare class CfnMongoDbEmployeeAccessGrant extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::MongoDbEmployeeAccessGrant";
    /**
     * Resource props.
     */
    readonly props: CfnMongoDbEmployeeAccessGrantProps;
    /**
     * Create a new `MongoDB::Atlas::MongoDbEmployeeAccessGrant`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnMongoDbEmployeeAccessGrantProps);
}
