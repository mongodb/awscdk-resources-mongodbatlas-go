import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Query limit for one federated database instance.
 *
 * @schema CfnFederatedQueryLimitProps
 */
export interface CfnFederatedQueryLimitProps {
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnFederatedQueryLimitProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Human-readable label that identifies the data federated database instance to which the query limit applies.
     *
     * @schema CfnFederatedQueryLimitProps#TenantName
     */
    readonly tenantName: string;
    /**
     * Human-readable label that identifies this data federation instance limit.
     *
     * @schema CfnFederatedQueryLimitProps#LimitName
     */
    readonly limitName: CfnFederatedQueryLimitPropsLimitName;
    /**
     * Action to take when the usage limit is exceeded. If limit span is set to QUERY, this is ignored because MongoDB Cloud stops the query when it exceeds the usage limit.
     *
     * @schema CfnFederatedQueryLimitProps#OverrunPolicy
     */
    readonly overrunPolicy?: string;
    /**
     * Amount to set the limit to.
     *
     * @schema CfnFederatedQueryLimitProps#Value
     */
    readonly value: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnFederatedQueryLimitProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnFederatedQueryLimitProps' to JSON representation.
 */
export declare function toJson_CfnFederatedQueryLimitProps(obj: CfnFederatedQueryLimitProps | undefined): Record<string, any> | undefined;
/**
 * Human-readable label that identifies this data federation instance limit.
 *
 * @schema CfnFederatedQueryLimitPropsLimitName
 */
export declare enum CfnFederatedQueryLimitPropsLimitName {
    /** bytesProcessed.query */
    BYTES_PROCESSED_QUERY = "bytesProcessed.query",
    /** bytesProcessed.daily */
    BYTES_PROCESSED_DAILY = "bytesProcessed.daily",
    /** bytesProcessed.weekly */
    BYTES_PROCESSED_WEEKLY = "bytesProcessed.weekly",
    /** bytesProcessed.monthly */
    BYTES_PROCESSED_MONTHLY = "bytesProcessed.monthly"
}
/**
 * A CloudFormation `MongoDB::Atlas::FederatedQueryLimit`
 *
 * @cloudformationResource MongoDB::Atlas::FederatedQueryLimit
 * @stability external
 */
export declare class CfnFederatedQueryLimit extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::FederatedQueryLimit";
    /**
     * Resource props.
     */
    readonly props: CfnFederatedQueryLimitProps;
    /**
     * Attribute `MongoDB::Atlas::FederatedQueryLimit.CurrentUsage`
     */
    readonly attrCurrentUsage: string;
    /**
     * Attribute `MongoDB::Atlas::FederatedQueryLimit.LastModifiedDate`
     */
    readonly attrLastModifiedDate: string;
    /**
     * Attribute `MongoDB::Atlas::FederatedQueryLimit.MaximumLimit`
     */
    readonly attrMaximumLimit: string;
    /**
     * Attribute `MongoDB::Atlas::FederatedQueryLimit.DefaultLimit`
     */
    readonly attrDefaultLimit: string;
    /**
     * Create a new `MongoDB::Atlas::FederatedQueryLimit`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnFederatedQueryLimitProps);
}
