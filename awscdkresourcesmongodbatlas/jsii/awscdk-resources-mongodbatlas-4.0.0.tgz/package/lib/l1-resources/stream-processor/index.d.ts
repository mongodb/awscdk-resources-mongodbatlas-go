import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, edits, and removes Atlas Stream Processors.
 *
 * @schema CfnStreamProcessorProps
 */
export interface CfnStreamProcessorProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnStreamProcessorProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * **NOTE**: Groups and projects are synonymous terms. Your group id is the same as your project id. For existing groups, your group/project id remains the same. The resource and corresponding endpoints use the term groups.
     *
     * @schema CfnStreamProcessorProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Label that identifies the stream processing workspace.
     *
     * @schema CfnStreamProcessorProps#WorkspaceName
     */
    readonly workspaceName: string;
    /**
     * Label that identifies the stream processor.
     *
     * @schema CfnStreamProcessorProps#ProcessorName
     */
    readonly processorName: string;
    /**
     * Stream aggregation pipeline you want to apply to your streaming data. This should be a JSON-encoded array of pipeline stages. Refer to MongoDB Atlas Docs for more information on stream aggregation pipelines.
     *
     * @schema CfnStreamProcessorProps#Pipeline
     */
    readonly pipeline: string;
    /**
     * The desired state of the stream processor. Used to start or stop the Stream Processor. Valid values are CREATED, STARTED or STOPPED. When a Stream Processor is created without specifying the desired state, it will default to CREATED state. When a Stream Processor is updated without specifying the desired state, it will default to the Previous state.
     *
     * **NOTE** When a Stream Processor is updated without specifying the desired state, it is stopped and then restored to previous state upon update completion.
     *
     * @schema CfnStreamProcessorProps#DesiredState
     */
    readonly desiredState?: CfnStreamProcessorPropsDesiredState;
    /**
     * @schema CfnStreamProcessorProps#Options
     */
    readonly options?: StreamsOptions;
    /**
     * Configurable timeouts for stream processor operations.
     *
     * @schema CfnStreamProcessorProps#Timeouts
     */
    readonly timeouts?: Timeouts;
    /**
     * Indicates whether to delete the resource being created if a timeout is reached when waiting for completion. When set to `true` and timeout occurs, it triggers the deletion and returns immediately without waiting for deletion to complete. When set to `false`, the timeout will not trigger resource deletion. If you suspect a transient error when the value is `true`, wait before retrying to allow resource deletion to finish. Default is `true`.
     *
     * @default true`.
     * @schema CfnStreamProcessorProps#DeleteOnCreateTimeout
     */
    readonly deleteOnCreateTimeout?: boolean;
}
/**
 * Converts an object of type 'CfnStreamProcessorProps' to JSON representation.
 */
export declare function toJson_CfnStreamProcessorProps(obj: CfnStreamProcessorProps | undefined): Record<string, any> | undefined;
/**
 * The desired state of the stream processor. Used to start or stop the Stream Processor. Valid values are CREATED, STARTED or STOPPED. When a Stream Processor is created without specifying the desired state, it will default to CREATED state. When a Stream Processor is updated without specifying the desired state, it will default to the Previous state.
 *
 * **NOTE** When a Stream Processor is updated without specifying the desired state, it is stopped and then restored to previous state upon update completion.
 *
 * @schema CfnStreamProcessorPropsDesiredState
 */
export declare enum CfnStreamProcessorPropsDesiredState {
    /** CREATED */
    CREATED = "CREATED",
    /** STARTED */
    STARTED = "STARTED",
    /** STOPPED */
    STOPPED = "STOPPED"
}
/**
 * Optional configuration for the stream processor.
 *
 * @schema StreamsOptions
 */
export interface StreamsOptions {
    /**
     * @schema StreamsOptions#Dlq
     */
    readonly dlq: StreamsDlq;
}
/**
 * Converts an object of type 'StreamsOptions' to JSON representation.
 */
export declare function toJson_StreamsOptions(obj: StreamsOptions | undefined): Record<string, any> | undefined;
/**
 * Configurable timeouts for stream processor operations.
 *
 * @schema Timeouts
 */
export interface Timeouts {
    /**
     * Timeout for create operation in Go duration format (e.g., '5m', '10s'). Default is 20 minutes.
     *
     * @default 20 minutes.
     * @schema Timeouts#Create
     */
    readonly create?: string;
}
/**
 * Converts an object of type 'Timeouts' to JSON representation.
 */
export declare function toJson_Timeouts(obj: Timeouts | undefined): Record<string, any> | undefined;
/**
 * Dead letter queue for the stream processor. Refer to the MongoDB Atlas Docs for more information.
 *
 * @schema StreamsDLQ
 */
export interface StreamsDlq {
    /**
     * Name of the collection to use for the DLQ.
     *
     * @schema StreamsDLQ#Coll
     */
    readonly coll: string;
    /**
     * Name of the connection to write DLQ messages to. Must be an Atlas connection.
     *
     * @schema StreamsDLQ#ConnectionName
     */
    readonly connectionName: string;
    /**
     * Name of the database to use for the DLQ.
     *
     * @schema StreamsDLQ#Db
     */
    readonly db: string;
}
/**
 * Converts an object of type 'StreamsDlq' to JSON representation.
 */
export declare function toJson_StreamsDlq(obj: StreamsDlq | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::StreamProcessor`
 *
 * @cloudformationResource MongoDB::Atlas::StreamProcessor
 * @stability external
 */
export declare class CfnStreamProcessor extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::StreamProcessor";
    /**
     * Resource props.
     */
    readonly props: CfnStreamProcessorProps;
    /**
     * Attribute `MongoDB::Atlas::StreamProcessor.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::StreamProcessor.Stats`
     */
    readonly attrStats: string;
    /**
     * Attribute `MongoDB::Atlas::StreamProcessor.State`
     */
    readonly attrState: string;
    /**
     * Create a new `MongoDB::Atlas::StreamProcessor`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnStreamProcessorProps);
}
