import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Retrieves or creates projects in any given Atlas organization.
 *
 * @schema CfnProjectProps
 */
export interface CfnProjectProps {
    /**
     * Name of the project to create.
     *
     * @schema CfnProjectProps#Name
     */
    readonly name: string;
    /**
     * Unique identifier of the organization within which to create the project.
     *
     * @schema CfnProjectProps#OrgId
     */
    readonly orgId: string;
    /**
     * Unique identifier of the organization within which to create the project.
     *
     * @schema CfnProjectProps#ProjectOwnerId
     */
    readonly projectOwnerId?: string;
    /**
     * Flag that indicates whether to create the project with default alert settings.
     *
     * @schema CfnProjectProps#WithDefaultAlertsSettings
     */
    readonly withDefaultAlertsSettings?: boolean;
    /**
     * @schema CfnProjectProps#ProjectSettings
     */
    readonly projectSettings?: ProjectSettings;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnProjectProps#Profile
     */
    readonly profile?: string;
    /**
     * Teams to which the authenticated user has access in the project specified using its unique 24-hexadecimal digit identifier.
     *
     * @schema CfnProjectProps#ProjectTeams
     */
    readonly projectTeams?: ProjectTeam[];
    /**
     * API keys that you assigned to the specified project.
     *
     * @schema CfnProjectProps#ProjectApiKeys
     */
    readonly projectApiKeys?: ProjectApiKey[];
    /**
     * Region usage restrictions that designate the project's AWS region.Enum: "GOV_REGIONS_ONLY" "COMMERCIAL_FEDRAMP_REGIONS_ONLY" "NONE"
     *
     * @schema CfnProjectProps#RegionUsageRestrictions
     */
    readonly regionUsageRestrictions?: string;
    /**
     * @schema CfnProjectProps#Tags
     */
    readonly tags?: any;
}
/**
 * Converts an object of type 'CfnProjectProps' to JSON representation.
 */
export declare function toJson_CfnProjectProps(obj: CfnProjectProps | undefined): Record<string, any> | undefined;
/**
 * @schema projectSettings
 */
export interface ProjectSettings {
    /**
     * Flag that indicates whether to collect database-specific metrics for the specified project.
     *
     * @schema projectSettings#IsCollectDatabaseSpecificsStatisticsEnabled
     */
    readonly isCollectDatabaseSpecificsStatisticsEnabled?: boolean;
    /**
     * Flag that indicates whether to enable the Data Explorer for the specified project.
     *
     * @schema projectSettings#IsDataExplorerEnabled
     */
    readonly isDataExplorerEnabled?: boolean;
    /**
     * Flag that indicates whether to enable extended storage sizes for the specified project.
     *
     * @schema projectSettings#IsExtendedStorageSizesEnabled
     */
    readonly isExtendedStorageSizesEnabled?: boolean;
    /**
     * Flag that indicates whether to enable the Performance Advisor and Profiler for the specified project.
     *
     * @schema projectSettings#IsPerformanceAdvisorEnabled
     */
    readonly isPerformanceAdvisorEnabled?: boolean;
    /**
     * Flag that indicates whether to enable the Real Time Performance Panel for the specified project.
     *
     * @schema projectSettings#IsRealtimePerformancePanelEnabled
     */
    readonly isRealtimePerformancePanelEnabled?: boolean;
    /**
     * Flag that indicates whether to enable the Schema Advisor for the specified project.
     *
     * @schema projectSettings#IsSchemaAdvisorEnabled
     */
    readonly isSchemaAdvisorEnabled?: boolean;
}
/**
 * Converts an object of type 'ProjectSettings' to JSON representation.
 */
export declare function toJson_ProjectSettings(obj: ProjectSettings | undefined): Record<string, any> | undefined;
/**
 * @schema projectTeam
 */
export interface ProjectTeam {
    /**
     * Unique 24-hexadecimal character string that identifies the team. string = 24 characters ^([a-f0-9]{24})$
     *
     * @schema projectTeam#TeamId
     */
    readonly teamId?: string;
    /**
     * One or more organization- or project-level roles to assign to the MongoDB Cloud user. tems Enum: "GROUP_CLUSTER_MANAGER" "GROUP_DATA_ACCESS_ADMIN" "GROUP_DATA_ACCESS_READ_ONLY" "GROUP_DATA_ACCESS_READ_WRITE" "GROUP_OWNER" "GROUP_READ_ONLY"
     *
     * @schema projectTeam#RoleNames
     */
    readonly roleNames?: string[];
}
/**
 * Converts an object of type 'ProjectTeam' to JSON representation.
 */
export declare function toJson_ProjectTeam(obj: ProjectTeam | undefined): Record<string, any> | undefined;
/**
 * @schema projectApiKey
 */
export interface ProjectApiKey {
    /**
     * Unique 24-hexadecimal digit string that identifies this organization API key assigned to this project.
     *
     * @schema projectApiKey#Key
     */
    readonly key?: string;
    /**
     * List of roles to grant this API key. If you provide this list, provide a minimum of one role and ensure each role applies to this project.Items Enum: "ORG_OWNER" "ORG_MEMBER" "ORG_GROUP_CREATOR" "ORG_BILLING_ADMIN" "ORG_READ_ONLY" "ORG_TEAM_MEMBERS_ADMIN" "GROUP_ATLAS_ADMIN" "GROUP_AUTOMATION_ADMIN" "GROUP_BACKUP_ADMIN" "GROUP_MONITORING_ADMIN" "GROUP_OWNER" "GROUP_READ_ONLY" "GROUP_USER_ADMIN" "GROUP_BILLING_ADMIN" "GROUP_DATA_ACCESS_ADMIN" "GROUP_DATA_ACCESS_READ_ONLY" "GROUP_DATA_ACCESS_READ_WRITE" "GROUP_CHARTS_ADMIN" "GROUP_CLUSTER_MANAGER" "GROUP_SEARCH_INDEX_EDITOR"
     *
     * @schema projectApiKey#RoleNames
     */
    readonly roleNames?: string[];
}
/**
 * Converts an object of type 'ProjectApiKey' to JSON representation.
 */
export declare function toJson_ProjectApiKey(obj: ProjectApiKey | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::Project`
 *
 * @cloudformationResource MongoDB::Atlas::Project
 * @stability external
 */
export declare class CfnProject extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::Project";
    /**
     * Resource props.
     */
    readonly props: CfnProjectProps;
    /**
     * Attribute `MongoDB::Atlas::Project.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::Project.Created`
     */
    readonly attrCreated: string;
    /**
     * Attribute `MongoDB::Atlas::Project.ClusterCount`
     */
    readonly attrClusterCount: number;
    /**
     * Create a new `MongoDB::Atlas::Project`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnProjectProps);
}
