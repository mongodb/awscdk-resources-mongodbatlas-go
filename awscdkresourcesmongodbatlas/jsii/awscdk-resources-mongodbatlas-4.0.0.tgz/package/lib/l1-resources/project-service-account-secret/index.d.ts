import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Creates a secret for the specified Service Account at the project level.
 *
 * @schema CfnProjectServiceAccountSecretProps
 */
export interface CfnProjectServiceAccountSecretProps {
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnProjectServiceAccountSecretProps#ProjectId
     */
    readonly projectId: string;
    /**
     * The Client ID of the Service Account.
     *
     * @schema CfnProjectServiceAccountSecretProps#ClientId
     */
    readonly clientId: string;
    /**
     * The expiration time of the new Service Account secret, provided in hours. The minimum and maximum allowed expiration times are subject to change and are controlled by the organization's settings.
     *
     * @schema CfnProjectServiceAccountSecretProps#SecretExpiresAfterHours
     */
    readonly secretExpiresAfterHours?: number;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used.
     *
     * @schema CfnProjectServiceAccountSecretProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnProjectServiceAccountSecretProps' to JSON representation.
 */
export declare function toJson_CfnProjectServiceAccountSecretProps(obj: CfnProjectServiceAccountSecretProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::ProjectServiceAccountSecret`
 *
 * @cloudformationResource MongoDB::Atlas::ProjectServiceAccountSecret
 * @stability external
 */
export declare class CfnProjectServiceAccountSecret extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ProjectServiceAccountSecret";
    /**
     * Resource props.
     */
    readonly props: CfnProjectServiceAccountSecretProps;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountSecret.SecretId`
     */
    readonly attrSecretId: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountSecret.Secret`
     */
    readonly attrSecret: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountSecret.MaskedSecretValue`
     */
    readonly attrMaskedSecretValue: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountSecret.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountSecret.ExpiresAt`
     */
    readonly attrExpiresAt: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountSecret.LastUsedAt`
     */
    readonly attrLastUsedAt: string;
    /**
     * Create a new `MongoDB::Atlas::ProjectServiceAccountSecret`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnProjectServiceAccountSecretProps);
}
