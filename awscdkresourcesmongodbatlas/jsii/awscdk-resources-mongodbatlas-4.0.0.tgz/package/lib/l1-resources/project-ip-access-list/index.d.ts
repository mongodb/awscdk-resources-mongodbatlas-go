import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, edits, and removes network access limits to database deployments in Atlas.
 *
 * @schema CfnProjectIpAccessListProps
 */
export interface CfnProjectIpAccessListProps {
    /**
     * @schema CfnProjectIpAccessListProps#AccessList
     */
    readonly accessList: AccessListDefinition[];
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnProjectIpAccessListProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnProjectIpAccessListProps#Profile
     */
    readonly profile?: string;
    /**
     * @schema CfnProjectIpAccessListProps#ListOptions
     */
    readonly listOptions?: ListOptions;
}
/**
 * Converts an object of type 'CfnProjectIpAccessListProps' to JSON representation.
 */
export declare function toJson_CfnProjectIpAccessListProps(obj: CfnProjectIpAccessListProps | undefined): Record<string, any> | undefined;
/**
 * @schema accessListDefinition
 */
export interface AccessListDefinition {
    /**
     * Date and time after which MongoDB Cloud deletes the temporary access list entry. This parameter expresses its value in the ISO 8601 timestamp format in UTC and can include the time zone designation. The date must be later than the current date but no later than one week after you submit this request. The resource returns this parameter if you specified an expiration date when creating this IP access list entry.
     *
     * @schema accessListDefinition#DeleteAfterDate
     */
    readonly deleteAfterDate?: string;
    /**
     * Unique string of the Amazon Web Services (AWS) security group that you want to add to the project's IP access list. Your IP access list entry can be one awsSecurityGroup, one cidrBlock, or one ipAddress. You must configure Virtual Private Connection (VPC) peering for your project before you can add an AWS security group to an IP access list. You cannot set AWS security groups as temporary access list entries. Don't set this parameter if you set cidrBlock or ipAddress.
     *
     * @schema accessListDefinition#AwsSecurityGroup
     */
    readonly awsSecurityGroup?: string;
    /**
     * Range of IP addresses in Classless Inter-Domain Routing (CIDR) notation that you want to add to the project's IP access list. Your IP access list entry can be one awsSecurityGroup, one cidrBlock, or one ipAddress. Don't set this parameter if you set awsSecurityGroup or ipAddress
     *
     * @schema accessListDefinition#CIDRBlock
     */
    readonly cidrBlock?: string;
    /**
     * Remark that explains the purpose or scope of this IP access list entry.
     *
     * @schema accessListDefinition#Comment
     */
    readonly comment?: string;
    /**
     * IP address that you want to add to the project's IP access list. Your IP access list entry can be one awsSecurityGroup, one cidrBlock, or one ipAddress. Don't set this parameter if you set awsSecurityGroup or cidrBlock.
     *
     * @schema accessListDefinition#IPAddress
     */
    readonly ipAddress?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema accessListDefinition#ProjectId
     */
    readonly projectId?: string;
}
/**
 * Converts an object of type 'AccessListDefinition' to JSON representation.
 */
export declare function toJson_AccessListDefinition(obj: AccessListDefinition | undefined): Record<string, any> | undefined;
/**
 * @schema listOptions
 */
export interface ListOptions {
    /**
     * Number of the page that displays the current set of the total objects that the response returns.
     *
     * @schema listOptions#PageNum
     */
    readonly pageNum?: number;
    /**
     * Number of items that the response returns per page.
     *
     * @schema listOptions#ItemsPerPage
     */
    readonly itemsPerPage?: number;
    /**
     * Flag that indicates whether the response returns the total number of items (totalCount) in the response.
     *
     * @schema listOptions#IncludeCount
     */
    readonly includeCount?: boolean;
}
/**
 * Converts an object of type 'ListOptions' to JSON representation.
 */
export declare function toJson_ListOptions(obj: ListOptions | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::ProjectIpAccessList`
 *
 * @cloudformationResource MongoDB::Atlas::ProjectIpAccessList
 * @stability external
 */
export declare class CfnProjectIpAccessList extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ProjectIpAccessList";
    /**
     * Resource props.
     */
    readonly props: CfnProjectIpAccessListProps;
    /**
     * Attribute `MongoDB::Atlas::ProjectIpAccessList.TotalCount`
     */
    readonly attrTotalCount: number;
    /**
     * Create a new `MongoDB::Atlas::ProjectIpAccessList`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnProjectIpAccessListProps);
}
