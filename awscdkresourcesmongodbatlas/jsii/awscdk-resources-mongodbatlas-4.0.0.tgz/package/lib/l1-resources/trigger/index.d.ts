import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * View and manage your application's triggers: https://www.mongodb.com/docs/atlas/app-services/triggers/
 *
 * @schema CfnTriggerProps
 */
export interface CfnTriggerProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnTriggerProps#Profile
     */
    readonly profile?: string;
    /**
     * @schema CfnTriggerProps#DatabaseTrigger
     */
    readonly databaseTrigger?: DatabaseConfig;
    /**
     * @schema CfnTriggerProps#AuthTrigger
     */
    readonly authTrigger?: AuthConfig;
    /**
     * @schema CfnTriggerProps#ScheduleTrigger
     */
    readonly scheduleTrigger?: ScheduleConfig;
    /**
     * The trigger's name.
     *
     * @schema CfnTriggerProps#Name
     */
    readonly name: string;
    /**
     * The trigger's type.
     *
     * @schema CfnTriggerProps#Type
     */
    readonly type: string;
    /**
     * If `true`, the trigger is disabled and does not listen for events or execute.
     *
     * @schema CfnTriggerProps#Disabled
     */
    readonly disabled?: boolean;
    /**
     * The ID of the function that the trigger calls when it fires.
     *
     * This value is the same as `event_processors.FUNCTION.function_id`.
     * You can either define the value here or in `event_processors.FUNCTION.function_id`.
     * The App Services backend duplicates the value to the configuration location where you did not define it.
     *
     * For example, if you define `function_id`, the backend duplicates it to `event_processors.FUNCTION.function_id`.
     *
     * @schema CfnTriggerProps#FunctionId
     */
    readonly functionId?: string;
    /**
     * The name of the function that the trigger calls when it
     * fires, i.e. the function described by `function_id`.
     *
     * This value is the same as `event_processors.FUNCTION.function_name`.
     * You can either define the value here or in `event_processors.FUNCTION.function_name`.
     * The App Services backend duplicates the value to the configuration location where you did not define it.
     *
     * For example, if you define `function_name`, the backend duplicates it to `event_processors.FUNCTION.function_name`.
     *
     * @schema CfnTriggerProps#FunctionName
     */
    readonly functionName?: string;
    /**
     * An object where each field name is an event processor ID and
     * each value is an object that configures its corresponding
     * event processor. For an example configuration object, see
     * [Send Trigger Events to AWS
     * EventBridge](https://www.mongodb.com/docs/atlas/app-services/triggers/aws-eventbridge/#std-label-event_processor_example).
     *
     * @schema CfnTriggerProps#EventProcessors
     */
    readonly eventProcessors?: Event;
    /**
     * App Services Application ID
     *
     * @schema CfnTriggerProps#AppId
     */
    readonly appId: string;
    /**
     * Project Id for application services
     *
     * @schema CfnTriggerProps#ProjectId
     */
    readonly projectId: string;
}
/**
 * Converts an object of type 'CfnTriggerProps' to JSON representation.
 */
export declare function toJson_CfnTriggerProps(obj: CfnTriggerProps | undefined): Record<string, any> | undefined;
/**
 * @schema DatabaseConfig
 */
export interface DatabaseConfig {
    /**
     * The _id value of a linked MongoDB data source.
     *
     * See [Get a Data Source](#operation/adminGetService).
     *
     *
     * @schema DatabaseConfig#ServiceId
     */
    readonly serviceId?: string;
    /**
     * The name of a database in the linked data source.
     *
     * @schema DatabaseConfig#Database
     */
    readonly database?: string;
    /**
     * The name of a collection in the specified database. The
     * trigger listens to events from this collection.
     *
     * @schema DatabaseConfig#Collection
     */
    readonly collection?: string;
    /**
     * The type(s) of MongoDB change event that the trigger listens for.
     *
     * @schema DatabaseConfig#OperationTypes
     */
    readonly operationTypes?: DatabaseConfigOperationTypes[];
    /**
     * stringify version of a [$match](https://www.mongodb.com/docs/manual/reference/operator/aggregation/match) expression filters change events. The trigger will only fire if the expression evaluates to true for a given change event.
     *
     * @schema DatabaseConfig#Match
     */
    readonly match?: string;
    /**
     * stringify version of a [$project](https://www.mongodb.com/docs/manual/reference/operator/aggregation/project/) expressions to limit the data included in each event.
     *
     * @schema DatabaseConfig#Project
     */
    readonly project?: string;
    /**
     * If `true`, indicates that `UPDATE` change events should
     * include the most current
     * [majority-committed](https://www.mongodb.com/docs/manual/reference/read-concern-majority/)
     * version of the modified document in the `fullDocument`
     * field.
     *
     * @schema DatabaseConfig#FullDocument
     */
    readonly fullDocument?: boolean;
    /**
     * If true, indicates that `UPDATE` change events should
     * include a snapshot of the modified document from
     * immediately before the update was applied.
     *
     * You must enable [document
     * preimages](https://www.mongodb.com/docs/atlas/app-services/mongodb/preimages/)
     * for your cluster to include these snapshots.
     *
     * @schema DatabaseConfig#FullDocumentBeforeChange
     */
    readonly fullDocumentBeforeChange?: boolean;
    /**
     * If `true`, enabling the Trigger after it was disabled
     * will not invoke events that occurred while the Trigger
     * was disabled.
     *
     * @schema DatabaseConfig#SkipCatchupEvents
     */
    readonly skipCatchupEvents?: boolean;
    /**
     * If `true`, when this Trigger's resume token
     * cannot be found in the cluster's oplog, the Trigger automatically resumes
     * processing events at the next relevant change stream event.
     * All change stream events from when the Trigger was suspended until the Trigger
     * resumes execution do not have the Trigger fire for them.
     *
     * @schema DatabaseConfig#TolerateResumeErrors
     */
    readonly tolerateResumeErrors?: boolean;
    /**
     * If `true`, the trigger will use the maximize throughput option (https://www.mongodb.com/docs/atlas/app-services/triggers/database-triggers/#std-label-triggers-maximum-throughput).
     *
     * @schema DatabaseConfig#MaximumThroughput
     */
    readonly maximumThroughput?: boolean;
    /**
     * If `true`, event ordering is disabled and this Trigger
     * can process events in parallel. If `false`, event
     * ordering is enabled and the Trigger executes events
     * serially.
     *
     * @schema DatabaseConfig#Unordered
     */
    readonly unordered?: boolean;
}
/**
 * Converts an object of type 'DatabaseConfig' to JSON representation.
 */
export declare function toJson_DatabaseConfig(obj: DatabaseConfig | undefined): Record<string, any> | undefined;
/**
 * @schema AuthConfig
 */
export interface AuthConfig {
    /**
     * The type of authentication event that the trigger listens for.
     *
     * @schema AuthConfig#OperationType
     */
    readonly operationType: AuthConfigOperationType;
    /**
     * The type(s) of authentication provider that the trigger listens to.
     *
     * @schema AuthConfig#Providers
     */
    readonly providers: AuthConfigProviders[];
}
/**
 * Converts an object of type 'AuthConfig' to JSON representation.
 */
export declare function toJson_AuthConfig(obj: AuthConfig | undefined): Record<string, any> | undefined;
/**
 * @schema ScheduleConfig
 */
export interface ScheduleConfig {
    /**
     * A [cron expression](https://www.mongodb.com/docs/atlas/app-services/triggers/scheduled-triggers/#cron-expressions) that specifies when the trigger executes.
     *
     * @schema ScheduleConfig#Schedule
     */
    readonly schedule?: string;
    /**
     * If `true`, enabling the trigger after it was disabled
     * will not invoke events that occurred while the trigger
     * was disabled.
     *
     * @schema ScheduleConfig#SkipcatchupEvents
     */
    readonly skipcatchupEvents?: boolean;
}
/**
 * Converts an object of type 'ScheduleConfig' to JSON representation.
 */
export declare function toJson_ScheduleConfig(obj: ScheduleConfig | undefined): Record<string, any> | undefined;
/**
 * @schema Event
 */
export interface Event {
    /**
     * @schema Event#FUNCTION
     */
    readonly function?: EventFunction;
    /**
     * @schema Event#AWSEVENTBRIDGE
     */
    readonly awseventbridge?: EventAwseventbridge;
}
/**
 * Converts an object of type 'Event' to JSON representation.
 */
export declare function toJson_Event(obj: Event | undefined): Record<string, any> | undefined;
/**
 * @schema DatabaseConfigOperationTypes
 */
export declare enum DatabaseConfigOperationTypes {
    /** INSERT */
    INSERT = "INSERT",
    /** UPDATE */
    UPDATE = "UPDATE",
    /** REPLACE */
    REPLACE = "REPLACE",
    /** DELETE */
    DELETE = "DELETE"
}
/**
 * The type of authentication event that the trigger listens for.
 *
 * @schema AuthConfigOperationType
 */
export declare enum AuthConfigOperationType {
    /** LOGIN */
    LOGIN = "LOGIN",
    /** CREATE */
    CREATE = "CREATE",
    /** DELETE */
    DELETE = "DELETE"
}
/**
 * @schema AuthConfigProviders
 */
export declare enum AuthConfigProviders {
    /** anon-user */
    ANON_USER = "anon-user",
    /** api-key */
    API_KEY = "api-key",
    /** custom-token */
    CUSTOM_TOKEN = "custom-token",
    /** custom-function */
    CUSTOM_FUNCTION = "custom-function",
    /** local-userpass */
    LOCAL_USERPASS = "local-userpass",
    /** oauth2-apple */
    OAUTH2_APPLE = "oauth2-apple",
    /** oauth2-facebook */
    OAUTH2_FACEBOOK = "oauth2-facebook",
    /** oauth2-google */
    OAUTH2_GOOGLE = "oauth2-google"
}
/**
 * @schema EventFunction
 */
export interface EventFunction {
    /**
     * @schema EventFunction#FuncConfig
     */
    readonly funcConfig?: EventFunctionFuncConfig;
}
/**
 * Converts an object of type 'EventFunction' to JSON representation.
 */
export declare function toJson_EventFunction(obj: EventFunction | undefined): Record<string, any> | undefined;
/**
 * @schema EventAwseventbridge
 */
export interface EventAwseventbridge {
    /**
     * @schema EventAwseventbridge#AWSConfig
     */
    readonly awsConfig?: EventAwseventbridgeAwsConfig;
}
/**
 * Converts an object of type 'EventAwseventbridge' to JSON representation.
 */
export declare function toJson_EventAwseventbridge(obj: EventAwseventbridge | undefined): Record<string, any> | undefined;
/**
 * @schema EventFunctionFuncConfig
 */
export interface EventFunctionFuncConfig {
    /**
     * The ID of the function that the trigger calls when it fires.
     *
     * This value is the same as the root-level `function_id`.
     * You can either define the value here or in `function_id`.
     * The App Services backend duplicates the value to the configuration location where you did not define it.
     *
     * For example, if you define `event_processors.FUNCTION.function_id`, the backend duplicates it to `function_id`.
     *
     * @schema EventFunctionFuncConfig#FunctionId
     */
    readonly functionId?: string;
    /**
     * The name of the function that the trigger calls when it
     * fires, i.e. the function described by `function_id`.
     *
     * This value is the same as the root-level `function_name`.
     * You can either define the value here or in `function_name`.
     * The App Services backend duplicates the value to the configuration location where you did not define it.
     *
     * For example, if you define `event_processors.FUNCTION.function_name`, the backend duplicates it to `function_name`.
     *
     * @schema EventFunctionFuncConfig#FunctionName
     */
    readonly functionName?: string;
}
/**
 * Converts an object of type 'EventFunctionFuncConfig' to JSON representation.
 */
export declare function toJson_EventFunctionFuncConfig(obj: EventFunctionFuncConfig | undefined): Record<string, any> | undefined;
/**
 * @schema EventAwseventbridgeAwsConfig
 */
export interface EventAwseventbridgeAwsConfig {
    /**
     * An AWS Account ID.
     *
     * @schema EventAwseventbridgeAwsConfig#AccountId
     */
    readonly accountId?: string;
    /**
     * An AWS region.
     *
     * @schema EventAwseventbridgeAwsConfig#Region
     */
    readonly region?: string;
    /**
     * If `true`, event objects are serialized using EJSON.
     *
     * @schema EventAwseventbridgeAwsConfig#ExtendedJsonEnabled
     */
    readonly extendedJsonEnabled?: boolean;
}
/**
 * Converts an object of type 'EventAwseventbridgeAwsConfig' to JSON representation.
 */
export declare function toJson_EventAwseventbridgeAwsConfig(obj: EventAwseventbridgeAwsConfig | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::Trigger`
 *
 * @cloudformationResource MongoDB::Atlas::Trigger
 * @stability external
 */
export declare class CfnTrigger extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::Trigger";
    /**
     * Resource props.
     */
    readonly props: CfnTriggerProps;
    /**
     * Attribute `MongoDB::Atlas::Trigger.Id`
     */
    readonly attrId: string;
    /**
     * Create a new `MongoDB::Atlas::Trigger`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnTriggerProps);
}
