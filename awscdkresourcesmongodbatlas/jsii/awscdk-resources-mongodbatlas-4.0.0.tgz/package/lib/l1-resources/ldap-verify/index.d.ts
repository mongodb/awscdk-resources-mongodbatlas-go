import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Requests a verification of an LDAP configuration over TLS for an Atlas project. Pass the requestId in the response object to the Verify |ldap| Configuration endpoint to get the status of a verification request. Atlas retains only the most recent request for each project.
 *
 * @schema CfnLdapVerifyProps
 */
export interface CfnLdapVerifyProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnLdapVerifyProps#Profile
     */
    readonly profile?: string;
    /**
     * List of validation messages related to the verification of the provided LDAP over TLS configuration details. The array contains a document for each test that Atlas runs. Atlas stops running tests after the first failure.
     *
     * @schema CfnLdapVerifyProps#Validations
     */
    readonly validations?: Validation[];
    /**
     * Full Distinguished Name (DN) of the Lightweight Directory Access Protocol (LDAP) user that MongoDB Cloud uses to connect to the LDAP host. LDAP distinguished names must be formatted according to RFC 2253.
     *
     * @schema CfnLdapVerifyProps#BindUsername
     */
    readonly bindUsername: string;
    /**
     * Human-readable label that identifies the hostname or Internet Protocol (IP) address of the Lightweight Directory Access Protocol (LDAP) host. This host must have access to the internet or have a Virtual Private Cloud (VPC) peering connection to your cluster.
     *
     * @schema CfnLdapVerifyProps#HostName
     */
    readonly hostName: string;
    /**
     * Certificate Authority (CA) certificate that MongoDB Cloud uses to verify the identity of the Lightweight Directory Access Protocol (LDAP) host. MongoDB Cloud allows self-signed certificates. To delete an assigned value, pass an empty string: `"caCertificate": ""`
     *
     * @schema CfnLdapVerifyProps#CaCertificate
     */
    readonly caCertificate?: string;
    /**
     * Lightweight Directory Access Protocol (LDAP) query template that MongoDB Cloud runs to obtain the LDAP groups associated with the authenticated user. MongoDB Cloud uses this parameter only for user authorization. Use the `{USER}` placeholder in the Uniform Resource Locator (URL) to substitute the authenticated username. The query relates to the host specified with the hostname. Format this query according to [RFC 4515](https://tools.ietf.org/search/rfc4515) and [RFC 4516](https://datatracker.ietf.org/doc/html/rfc4516).
     *
     * @schema CfnLdapVerifyProps#AuthzQueryTemplate
     */
    readonly authzQueryTemplate?: string;
    /**
     * Password that MongoDB Cloud uses to authenticate the **bindUsername**.
     *
     * @schema CfnLdapVerifyProps#BindPassword
     */
    readonly bindPassword: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnLdapVerifyProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Port to which the Lightweight Directory Access Protocol (LDAP) host listens for client connections.
     *
     * @schema CfnLdapVerifyProps#Port
     */
    readonly port: number;
}
/**
 * Converts an object of type 'CfnLdapVerifyProps' to JSON representation.
 */
export declare function toJson_CfnLdapVerifyProps(obj: CfnLdapVerifyProps | undefined): Record<string, any> | undefined;
/**
 * @schema Validation
 */
export interface Validation {
    /**
     * @schema Validation#Status
     */
    readonly status?: string;
    /**
     * @schema Validation#ValidationType
     */
    readonly validationType?: string;
}
/**
 * Converts an object of type 'Validation' to JSON representation.
 */
export declare function toJson_Validation(obj: Validation | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::LDAPVerify`
 *
 * @cloudformationResource MongoDB::Atlas::LDAPVerify
 * @stability external
 */
export declare class CfnLdapVerify extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::LDAPVerify";
    /**
     * Resource props.
     */
    readonly props: CfnLdapVerifyProps;
    /**
     * Attribute `MongoDB::Atlas::LDAPVerify.RequestId`
     */
    readonly attrRequestId: string;
    /**
     * Attribute `MongoDB::Atlas::LDAPVerify.Status`
     */
    readonly attrStatus: string;
    /**
     * Create a new `MongoDB::Atlas::LDAPVerify`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnLdapVerifyProps);
}
