import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * The flex cluster resource provides access to your flex cluster configurations. The resource lets you create, edit and delete flex clusters. The resource requires your Project ID.
 *
 * @schema CfnFlexClusterProps
 */
export interface CfnFlexClusterProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnFlexClusterProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique identifier of the project the cluster belongs to.
     *
     * @schema CfnFlexClusterProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Human-readable label that identifies the flex cluster.
     *
     * @schema CfnFlexClusterProps#Name
     */
    readonly name: string;
    /**
     * @schema CfnFlexClusterProps#ProviderSettings
     */
    readonly providerSettings: ProviderSettings;
    /**
     * @schema CfnFlexClusterProps#BackupSettings
     */
    readonly backupSettings?: BackupSettings;
    /**
     * @schema CfnFlexClusterProps#ConnectionStrings
     */
    readonly connectionStrings?: ConnectionStrings;
    /**
     * Flag that indicates whether termination protection is enabled on the cluster. If set to true, MongoDB Cloud won't delete the cluster. If set to false, MongoDB Cloud will delete the cluster.
     *
     * @schema CfnFlexClusterProps#TerminationProtectionEnabled
     */
    readonly terminationProtectionEnabled?: boolean;
    /**
     * Map that contains key-value pairs between 1 to 255 characters in length for tagging and categorizing the flex cluster.
     *
     * @schema CfnFlexClusterProps#Tags
     */
    readonly tags?: Tag[];
}
/**
 * Converts an object of type 'CfnFlexClusterProps' to JSON representation.
 */
export declare function toJson_CfnFlexClusterProps(obj: CfnFlexClusterProps | undefined): Record<string, any> | undefined;
/**
 * Group of cloud provider settings that configure the provisioned MongoDB flex cluster.
 *
 * @schema ProviderSettings
 */
export interface ProviderSettings {
    /**
     * Cloud service provider on which MongoDB Cloud provisioned the flex cluster.
     *
     * @schema ProviderSettings#BackingProviderName
     */
    readonly backingProviderName: string;
    /**
     * Human-readable label that identifies the geographic location of your MongoDB flex cluster. The region you choose can affect network latency for clients accessing your databases.
     *
     * @schema ProviderSettings#RegionName
     */
    readonly regionName: string;
    /**
     * Storage capacity available to the flex cluster expressed in gigabytes.
     *
     * @schema ProviderSettings#DiskSizeGB
     */
    readonly diskSizeGb?: number;
    /**
     * Human-readable label that identifies the cloud service provider.
     *
     * @schema ProviderSettings#ProviderName
     */
    readonly providerName?: string;
}
/**
 * Converts an object of type 'ProviderSettings' to JSON representation.
 */
export declare function toJson_ProviderSettings(obj: ProviderSettings | undefined): Record<string, any> | undefined;
/**
 * Flex backup configuration
 *
 * @schema BackupSettings
 */
export interface BackupSettings {
    /**
     * Flag that indicates whether backups are performed for this flex cluster. Backup uses flex cluster backups.
     *
     * @schema BackupSettings#Enabled
     */
    readonly enabled?: boolean;
}
/**
 * Converts an object of type 'BackupSettings' to JSON representation.
 */
export declare function toJson_BackupSettings(obj: BackupSettings | undefined): Record<string, any> | undefined;
/**
 * Collection of Uniform Resource Locators that point to the MongoDB database.
 *
 * @schema ConnectionStrings
 */
export interface ConnectionStrings {
    /**
     * Public connection string that you can use to connect to this cluster. This connection string uses the mongodb:// protocol.
     *
     * @schema ConnectionStrings#Standard
     */
    readonly standard?: string;
    /**
     * Public connection string that you can use to connect to this flex cluster. This connection string uses the mongodb+srv:// protocol.
     *
     * @schema ConnectionStrings#StandardSrv
     */
    readonly standardSrv?: string;
}
/**
 * Converts an object of type 'ConnectionStrings' to JSON representation.
 */
export declare function toJson_ConnectionStrings(obj: ConnectionStrings | undefined): Record<string, any> | undefined;
/**
 * List that contains key-value pairs between 1 to 255 characters in length for tagging and categorizing the cluster.
 *
 * @schema tag
 */
export interface Tag {
    /**
     * Constant that defines the set of the tag. For example, environment in the environment : production tag.
     *
     * @schema tag#Key
     */
    readonly key: string;
    /**
     * Variable that belongs to the set of the tag. For example, production in the environment : production tag.
     *
     * @schema tag#Value
     */
    readonly value: string;
}
/**
 * Converts an object of type 'Tag' to JSON representation.
 */
export declare function toJson_Tag(obj: Tag | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::FlexCluster`
 *
 * @cloudformationResource MongoDB::Atlas::FlexCluster
 * @stability external
 */
export declare class CfnFlexCluster extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::FlexCluster";
    /**
     * Resource props.
     */
    readonly props: CfnFlexClusterProps;
    /**
     * Attribute `MongoDB::Atlas::FlexCluster.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::FlexCluster.StateName`
     */
    readonly attrStateName: string;
    /**
     * Attribute `MongoDB::Atlas::FlexCluster.ClusterType`
     */
    readonly attrClusterType: string;
    /**
     * Attribute `MongoDB::Atlas::FlexCluster.CreateDate`
     */
    readonly attrCreateDate: string;
    /**
     * Attribute `MongoDB::Atlas::FlexCluster.MongoDBVersion`
     */
    readonly attrMongoDBVersion: string;
    /**
     * Attribute `MongoDB::Atlas::FlexCluster.VersionReleaseSystem`
     */
    readonly attrVersionReleaseSystem: string;
    /**
     * Create a new `MongoDB::Atlas::FlexCluster`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnFlexClusterProps);
}
