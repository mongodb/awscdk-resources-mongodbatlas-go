import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, starts, and cancels Cloud Backup restore jobs.
 *
 * @schema CfnCloudBackUpRestoreJobsProps
 */
export interface CfnCloudBackUpRestoreJobsProps {
    /**
     * The unique identifier of the project for the Atlas cluster.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Type of instance specified on the Instance Name.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#InstanceType
     */
    readonly instanceType: CfnCloudBackUpRestoreJobsPropsInstanceType;
    /**
     * Human-readable label that identifies the cluster.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#InstanceName
     */
    readonly instanceName: string;
    /**
     * Type of restore job to create.The value can be any one of download,automated or point_in_time
     *
     * @schema CfnCloudBackUpRestoreJobsProps#DeliveryType
     */
    readonly deliveryType: CfnCloudBackUpRestoreJobsPropsDeliveryType;
    /**
     * Unique identifier of the source snapshot ID of the restore job.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#SnapshotId
     */
    readonly snapshotId: string;
    /**
     * One or more links to sub-resources and/or related resources.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#Links
     */
    readonly links?: CfnCloudBackUpRestoreJobsPropsLinks[];
    /**
     * Timestamp in the number of seconds that have elapsed since the UNIX epoch from which to you want to restore this snapshot. This is the first part of an Oplog timestamp.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#OpLogTs
     */
    readonly opLogTs?: string;
    /**
     * Oplog operation number from which to you want to restore this snapshot. This is the second part of an Oplog timestamp.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#OpLogInc
     */
    readonly opLogInc?: string;
    /**
     * If you performed a Point-in-Time restores at a time specified by a Unix time in seconds since epoch, pointInTimeUTCSeconds indicates the Unix time used.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#PointInTimeUtcSeconds
     */
    readonly pointInTimeUtcSeconds?: number;
    /**
     * Name of the target Atlas project of the restore job. Only visible if deliveryType is automated.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#TargetProjectId
     */
    readonly targetProjectId?: string;
    /**
     * Name of the target Atlas cluster to which the restore job restores the snapshot. Only visible if deliveryType is automated.
     *
     * @schema CfnCloudBackUpRestoreJobsProps#TargetClusterName
     */
    readonly targetClusterName?: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnCloudBackUpRestoreJobsProps#Profile
     */
    readonly profile?: string;
    /**
     * If set to true, the CloudFormation resource will wait until the job is completed, WARNING: if the snapshot has a big load of data, the cloud formation resource might take a long time to finish leading to high costs
     *
     * @schema CfnCloudBackUpRestoreJobsProps#EnableSynchronousCreation
     */
    readonly enableSynchronousCreation?: boolean;
    /**
     * Options that needs to be set to control the synchronous creation flow, this options need to be set if EnableSynchronousCreation is se to TRUE
     *
     * @schema CfnCloudBackUpRestoreJobsProps#SynchronousCreationOptions
     */
    readonly synchronousCreationOptions?: SynchronousCreationOptions;
}
/**
 * Converts an object of type 'CfnCloudBackUpRestoreJobsProps' to JSON representation.
 */
export declare function toJson_CfnCloudBackUpRestoreJobsProps(obj: CfnCloudBackUpRestoreJobsProps | undefined): Record<string, any> | undefined;
/**
 * Type of instance specified on the Instance Name.
 *
 * @schema CfnCloudBackUpRestoreJobsPropsInstanceType
 */
export declare enum CfnCloudBackUpRestoreJobsPropsInstanceType {
    /** cluster */
    CLUSTER = "cluster"
}
/**
 * Type of restore job to create.The value can be any one of download,automated or point_in_time
 *
 * @schema CfnCloudBackUpRestoreJobsPropsDeliveryType
 */
export declare enum CfnCloudBackUpRestoreJobsPropsDeliveryType {
    /** download */
    DOWNLOAD = "download",
    /** automated */
    AUTOMATED = "automated",
    /** pointInTime */
    POINT_IN_TIME = "pointInTime"
}
/**
 * @schema CfnCloudBackUpRestoreJobsPropsLinks
 */
export interface CfnCloudBackUpRestoreJobsPropsLinks {
    /**
     * @schema CfnCloudBackUpRestoreJobsPropsLinks#Rel
     */
    readonly rel?: string;
    /**
     * @schema CfnCloudBackUpRestoreJobsPropsLinks#Href
     */
    readonly href?: string;
}
/**
 * Converts an object of type 'CfnCloudBackUpRestoreJobsPropsLinks' to JSON representation.
 */
export declare function toJson_CfnCloudBackUpRestoreJobsPropsLinks(obj: CfnCloudBackUpRestoreJobsPropsLinks | undefined): Record<string, any> | undefined;
/**
 * Options that needs to be set to control the synchronous creation flow, this options need to be set if EnableSynchronousCreation is se to TRUE
 *
 * @schema SynchronousCreationOptions
 */
export interface SynchronousCreationOptions {
    /**
     * The amount of time the process will wait until exiting with a success, default (1200 seconds)
     *
     * @schema SynchronousCreationOptions#TimeOutInSeconds
     */
    readonly timeOutInSeconds?: number;
    /**
     * Represents the time interval, measured in seconds, for the synchronous process to wait before checking again to verify if the job has been completed. example: if set to 20, it will chek every 20 seconds if the resource is completed, default (30 seconds)
     *
     * @schema SynchronousCreationOptions#CallbackDelaySeconds
     */
    readonly callbackDelaySeconds?: number;
    /**
     * if set to true, the process will return success, in the event of a timeOut, default false
     *
     * @schema SynchronousCreationOptions#ReturnSuccessIfTimeOut
     */
    readonly returnSuccessIfTimeOut?: boolean;
}
/**
 * Converts an object of type 'SynchronousCreationOptions' to JSON representation.
 */
export declare function toJson_SynchronousCreationOptions(obj: SynchronousCreationOptions | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::CloudBackUpRestoreJobs`
 *
 * @cloudformationResource MongoDB::Atlas::CloudBackUpRestoreJobs
 * @stability external
 */
export declare class CfnCloudBackUpRestoreJobs extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::CloudBackUpRestoreJobs";
    /**
     * Resource props.
     */
    readonly props: CfnCloudBackUpRestoreJobsProps;
    /**
     * Attribute `MongoDB::Atlas::CloudBackUpRestoreJobs.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackUpRestoreJobs.DeliveryUrl`
     */
    readonly attrDeliveryUrl: string[];
    /**
     * Attribute `MongoDB::Atlas::CloudBackUpRestoreJobs.Cancelled`
     */
    readonly attrCancelled: cdk.IResolvable;
    /**
     * Attribute `MongoDB::Atlas::CloudBackUpRestoreJobs.Failed`
     */
    readonly attrFailed: cdk.IResolvable;
    /**
     * Attribute `MongoDB::Atlas::CloudBackUpRestoreJobs.Expired`
     */
    readonly attrExpired: cdk.IResolvable;
    /**
     * Attribute `MongoDB::Atlas::CloudBackUpRestoreJobs.ExpiresAt`
     */
    readonly attrExpiresAt: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackUpRestoreJobs.FinishedAt`
     */
    readonly attrFinishedAt: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackUpRestoreJobs.Timestamp`
     */
    readonly attrTimestamp: string;
    /**
     * Create a new `MongoDB::Atlas::CloudBackUpRestoreJobs`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnCloudBackUpRestoreJobsProps);
}
