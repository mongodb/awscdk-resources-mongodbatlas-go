import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns and edits database auditing settings for MongoDB Cloud projects.
 *
 * @schema CfnAuditingProps
 */
export interface CfnAuditingProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnAuditingProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnAuditingProps#ProjectId
     */
    readonly projectId: string;
}
/**
 * Converts an object of type 'CfnAuditingProps' to JSON representation.
 */
export declare function toJson_CfnAuditingProps(obj: CfnAuditingProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::Auditing`
 *
 * @cloudformationResource MongoDB::Atlas::Auditing
 * @stability external
 */
export declare class CfnAuditing extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::Auditing";
    /**
     * Resource props.
     */
    readonly props: CfnAuditingProps;
    /**
     * Attribute `MongoDB::Atlas::Auditing.AuditFilter`
     */
    readonly attrAuditFilter: string;
    /**
     * Attribute `MongoDB::Atlas::Auditing.ConfigurationType`
     */
    readonly attrConfigurationType: string;
    /**
     * Attribute `MongoDB::Atlas::Auditing.AuditAuthorizationSuccess`
     */
    readonly attrAuditAuthorizationSuccess: cdk.IResolvable;
    /**
     * Create a new `MongoDB::Atlas::Auditing`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnAuditingProps);
}
