import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, edits, and removes one connection for a stream workspace in the specified project. To use this resource, the requesting API Key must have the Project Owner roles.
 *
 * @schema CfnStreamConnectionProps
 */
export interface CfnStreamConnectionProps {
    /**
     * Unique 24-hexadecimal digit string that identifies your project. Use the [/groups](#tag/Projects/operation/listProjects) endpoint to retrieve all projects to which the authenticated user has access.
     *
     * **NOTE**: Groups and projects are synonymous terms. Your group id is the same as your project id. For existing groups, your group/project id remains the same. The resource and corresponding endpoints use the term groups.
     *
     * @schema CfnStreamConnectionProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnStreamConnectionProps#Profile
     */
    readonly profile?: string;
    /**
     * Human-readable label that identifies the stream connection. In the case of the Sample type, this is the name of the sample source.
     *
     * @schema CfnStreamConnectionProps#ConnectionName
     */
    readonly connectionName: string;
    /**
     * Human-readable label that identifies the stream instance. WARNING: This field is deprecated and will be removed in the next major release. Please use WorkspaceName instead.
     *
     * @schema CfnStreamConnectionProps#InstanceName
     */
    readonly instanceName?: string;
    /**
     * Human-readable label that identifies the stream workspace.
     *
     * @schema CfnStreamConnectionProps#WorkspaceName
     */
    readonly workspaceName?: string;
    /**
     * Type of the connection. Can be Cluster, Kafka, Sample, AWSLambda, or Https.
     *
     * @schema CfnStreamConnectionProps#Type
     */
    readonly type: CfnStreamConnectionPropsType;
    /**
     * Name of the cluster configured for this connection.
     *
     * @schema CfnStreamConnectionProps#ClusterName
     */
    readonly clusterName?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the project containing the cluster for cross-project cluster connections.
     *
     * @schema CfnStreamConnectionProps#ClusterProjectId
     */
    readonly clusterProjectId?: string;
    /**
     * @schema CfnStreamConnectionProps#DbRoleToExecute
     */
    readonly dbRoleToExecute?: DbRoleToExecute;
    /**
     * @schema CfnStreamConnectionProps#Authentication
     */
    readonly authentication?: StreamsKafkaAuthentication;
    /**
     * Comma separated list of server addresses.
     *
     * @schema CfnStreamConnectionProps#BootstrapServers
     */
    readonly bootstrapServers?: string;
    /**
     * @schema CfnStreamConnectionProps#Security
     */
    readonly security?: StreamsKafkaSecurity;
    /**
     * @schema CfnStreamConnectionProps#Config
     */
    readonly config?: any;
    /**
     * @schema CfnStreamConnectionProps#Networking
     */
    readonly networking?: Networking;
    /**
     * @schema CfnStreamConnectionProps#Aws
     */
    readonly aws?: Aws;
    /**
     * URL endpoint for HTTPS type connections.
     *
     * @schema CfnStreamConnectionProps#Url
     */
    readonly url?: string;
    /**
     * HTTP headers for HTTPS type connections.
     *
     * @schema CfnStreamConnectionProps#Headers
     */
    readonly headers?: any;
    /**
     * The Schema Registry provider.
     *
     * @schema CfnStreamConnectionProps#Provider
     */
    readonly provider?: string;
    /**
     * @schema CfnStreamConnectionProps#SchemaRegistryAuthentication
     */
    readonly schemaRegistryAuthentication?: SchemaRegistryAuthentication;
    /**
     * List of Schema Registry endpoint URLs. Each URL must use the http or https scheme and specify a valid host and optional port.
     *
     * @schema CfnStreamConnectionProps#SchemaRegistryUrls
     */
    readonly schemaRegistryUrls?: string[];
}
/**
 * Converts an object of type 'CfnStreamConnectionProps' to JSON representation.
 */
export declare function toJson_CfnStreamConnectionProps(obj: CfnStreamConnectionProps | undefined): Record<string, any> | undefined;
/**
 * Type of the connection. Can be Cluster, Kafka, Sample, AWSLambda, or Https.
 *
 * @schema CfnStreamConnectionPropsType
 */
export declare enum CfnStreamConnectionPropsType {
    /** Kafka */
    KAFKA = "Kafka",
    /** Cluster */
    CLUSTER = "Cluster",
    /** Sample */
    SAMPLE = "Sample",
    /** AWSLambda */
    AWS_LAMBDA = "AWSLambda",
    /** Https */
    HTTPS = "Https"
}
/**
 * The name of a Built in or Custom DB Role to connect to an Atlas Cluster.
 *
 * @schema DBRoleToExecute
 */
export interface DbRoleToExecute {
    /**
     * The name of the role to use. Can be a built in role or a custom role.
     *
     * @schema DBRoleToExecute#Role
     */
    readonly role?: string;
    /**
     * Type of the DB role. Can be either BuiltIn or Custom.
     *
     * @schema DBRoleToExecute#Type
     */
    readonly type?: DbRoleToExecuteType;
}
/**
 * Converts an object of type 'DbRoleToExecute' to JSON representation.
 */
export declare function toJson_DbRoleToExecute(obj: DbRoleToExecute | undefined): Record<string, any> | undefined;
/**
 * User credentials required to connect to a Kafka Cluster. Includes the authentication type, as well as the parameters for that authentication mode.
 *
 * @schema StreamsKafkaAuthentication
 */
export interface StreamsKafkaAuthentication {
    /**
     * Style of authentication. Can be one of PLAIN, SCRAM-256, SCRAM-512, or OAUTHBEARER.
     *
     * @schema StreamsKafkaAuthentication#Mechanism
     */
    readonly mechanism?: string;
    /**
     * OAuth authentication method.
     *
     * @schema StreamsKafkaAuthentication#Method
     */
    readonly method?: string;
    /**
     * Username of the account to connect to the Kafka cluster.
     *
     * @schema StreamsKafkaAuthentication#Username
     */
    readonly username?: string;
    /**
     * Password of the account to connect to the Kafka cluster. Review [AWS security best practices for CloudFormation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/security-best-practices.html#creds) to manage credentials.
     *
     * @schema StreamsKafkaAuthentication#Password
     */
    readonly password?: string;
    /**
     * OAuth token endpoint URL.
     *
     * @schema StreamsKafkaAuthentication#TokenEndpointUrl
     */
    readonly tokenEndpointUrl?: string;
    /**
     * OAuth client ID.
     *
     * @schema StreamsKafkaAuthentication#ClientId
     */
    readonly clientId?: string;
    /**
     * OAuth client secret. Review [AWS security best practices for CloudFormation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/security-best-practices.html#creds) to manage credentials.
     *
     * @schema StreamsKafkaAuthentication#ClientSecret
     */
    readonly clientSecret?: string;
    /**
     * OAuth scope.
     *
     * @schema StreamsKafkaAuthentication#Scope
     */
    readonly scope?: string;
    /**
     * SASL OAuth bearer extensions.
     *
     * @schema StreamsKafkaAuthentication#SaslOauthbearerExtensions
     */
    readonly saslOauthbearerExtensions?: string;
    /**
     * SSL certificate for client authentication to Kafka.
     *
     * @schema StreamsKafkaAuthentication#SslCertificate
     */
    readonly sslCertificate?: string;
    /**
     * SSL key for client authentication to Kafka. Review [AWS security best practices for CloudFormation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/security-best-practices.html#creds) to manage credentials.
     *
     * @schema StreamsKafkaAuthentication#SslKey
     */
    readonly sslKey?: string;
    /**
     * Password for the SSL key, if it is password protected. Review [AWS security best practices for CloudFormation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/security-best-practices.html#creds) to manage credentials.
     *
     * @schema StreamsKafkaAuthentication#SslKeyPassword
     */
    readonly sslKeyPassword?: string;
}
/**
 * Converts an object of type 'StreamsKafkaAuthentication' to JSON representation.
 */
export declare function toJson_StreamsKafkaAuthentication(obj: StreamsKafkaAuthentication | undefined): Record<string, any> | undefined;
/**
 * Properties for the secure transport connection to Kafka. For SSL, this can include the trusted certificate to use.
 *
 * @schema StreamsKafkaSecurity
 */
export interface StreamsKafkaSecurity {
    /**
     * A trusted, public x509 certificate for connecting to Kafka over SSL.
     *
     * @schema StreamsKafkaSecurity#BrokerPublicCertificate
     */
    readonly brokerPublicCertificate?: string;
    /**
     * Describes the transport type. Can be either PLAINTEXT or SSL.
     *
     * @schema StreamsKafkaSecurity#Protocol
     */
    readonly protocol?: string;
}
/**
 * Converts an object of type 'StreamsKafkaSecurity' to JSON representation.
 */
export declare function toJson_StreamsKafkaSecurity(obj: StreamsKafkaSecurity | undefined): Record<string, any> | undefined;
/**
 * Networking configuration for connections.
 *
 * @schema Networking
 */
export interface Networking {
    /**
     * Network access configuration.
     *
     * @schema Networking#Access
     */
    readonly access: NetworkingAccess;
}
/**
 * Converts an object of type 'Networking' to JSON representation.
 */
export declare function toJson_Networking(obj: Networking | undefined): Record<string, any> | undefined;
/**
 * AWS Lambda connection configuration.
 *
 * @schema Aws
 */
export interface Aws {
    /**
     * Amazon Resource Name (ARN) of the IAM role for AWS Lambda connection.
     *
     * @schema Aws#RoleArn
     */
    readonly roleArn: string;
    /**
     * The name of an S3 bucket used to check authorization of the passed-in IAM role ARN.
     *
     * @schema Aws#TestBucket
     */
    readonly testBucket?: string;
}
/**
 * Converts an object of type 'Aws' to JSON representation.
 */
export declare function toJson_Aws(obj: Aws | undefined): Record<string, any> | undefined;
/**
 * Authentication configuration for Schema Registry.
 *
 * @schema SchemaRegistryAuthentication
 */
export interface SchemaRegistryAuthentication {
    /**
     * Authentication type discriminator. Specifies the authentication mechanism for Schema Registry.
     *
     * @schema SchemaRegistryAuthentication#Type
     */
    readonly type?: string;
    /**
     * Username or Public Key for authentication.
     *
     * @schema SchemaRegistryAuthentication#Username
     */
    readonly username?: string;
    /**
     * Password or Private Key for authentication. Review [AWS security best practices for CloudFormation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/security-best-practices.html#creds) to manage credentials.
     *
     * @schema SchemaRegistryAuthentication#Password
     */
    readonly password?: string;
}
/**
 * Converts an object of type 'SchemaRegistryAuthentication' to JSON representation.
 */
export declare function toJson_SchemaRegistryAuthentication(obj: SchemaRegistryAuthentication | undefined): Record<string, any> | undefined;
/**
 * Type of the DB role. Can be either BuiltIn or Custom.
 *
 * @schema DbRoleToExecuteType
 */
export declare enum DbRoleToExecuteType {
    /** BUILT_IN */
    BUILT_IN = "BUILT_IN",
    /** CUSTOM */
    CUSTOM = "CUSTOM"
}
/**
 * Network access configuration.
 *
 * @schema NetworkingAccess
 */
export interface NetworkingAccess {
    /**
     * Type of network access. Can be PUBLIC, VPC, PRIVATE_LINK, or TRANSIT_GATEWAY.
     *
     * @schema NetworkingAccess#Type
     */
    readonly type?: string;
    /**
     * Unique identifier of the connection.
     *
     * @schema NetworkingAccess#ConnectionId
     */
    readonly connectionId?: string;
    /**
     * Reserved. Will be used by PRIVATE_LINK connection type.
     *
     * @schema NetworkingAccess#Name
     */
    readonly name?: string;
    /**
     * Reserved. Will be used by TRANSIT_GATEWAY connection type.
     *
     * @schema NetworkingAccess#TgwRouteId
     */
    readonly tgwRouteId?: string;
}
/**
 * Converts an object of type 'NetworkingAccess' to JSON representation.
 */
export declare function toJson_NetworkingAccess(obj: NetworkingAccess | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::StreamConnection`
 *
 * @cloudformationResource MongoDB::Atlas::StreamConnection
 * @stability external
 */
export declare class CfnStreamConnection extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::StreamConnection";
    /**
     * Resource props.
     */
    readonly props: CfnStreamConnectionProps;
    /**
     * Create a new `MongoDB::Atlas::StreamConnection`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnStreamConnectionProps);
}
