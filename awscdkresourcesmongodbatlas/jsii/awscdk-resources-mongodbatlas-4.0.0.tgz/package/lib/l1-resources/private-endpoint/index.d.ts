import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * DEPRECATED- USE MongoDB::Atlas::PrivateEndpointService and MongoDB::Atlas::PrivateEndpointAWS instead, The Private Endpoint creation flow consists of the creation of three related resources in the next order: 1. Atlas Private Endpoint Service 2. Aws VPC private Endpoint 3. Atlas Private Endpoint
 *
 * @schema CfnPrivateEndpointProps
 */
export interface CfnPrivateEndpointProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml)
     *
     * @schema CfnPrivateEndpointProps#Profile
     */
    readonly profile?: string;
    /**
     * Name of the AWS PrivateLink endpoint service. Atlas returns null while it is creating the endpoint service.
     *
     * @schema CfnPrivateEndpointProps#EndpointServiceName
     */
    readonly endpointServiceName?: string;
    /**
     * Error message pertaining to the AWS PrivateLink connection. Returns null if there are no errors.
     *
     * @schema CfnPrivateEndpointProps#ErrorMessage
     */
    readonly errorMessage?: string;
    /**
     * Status of the Atlas PrivateEndpoint service connection
     *
     * @schema CfnPrivateEndpointProps#Status
     */
    readonly status?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnPrivateEndpointProps#GroupId
     */
    readonly groupId: string;
    /**
     * Aws Region
     *
     * @schema CfnPrivateEndpointProps#Region
     */
    readonly region: string;
    /**
     * List of private endpoint associated to the service
     *
     * @schema CfnPrivateEndpointProps#PrivateEndpoints
     */
    readonly privateEndpoints?: PrivateEndpoint[];
}
/**
 * Converts an object of type 'CfnPrivateEndpointProps' to JSON representation.
 */
export declare function toJson_CfnPrivateEndpointProps(obj: CfnPrivateEndpointProps | undefined): Record<string, any> | undefined;
/**
 * @schema PrivateEndpoint
 */
export interface PrivateEndpoint {
    /**
     * String Representing the AWS VPC ID (like: vpc-xxxxxxxxxxxxxxxx) (Used For Creating the AWS VPC Endpoint)
     *
     * @schema PrivateEndpoint#VpcId
     */
    readonly vpcId?: string;
    /**
     * List of string representing the AWS VPC Subnet ID (like: subnet-xxxxxxxxxxxxxxxxx) (Used For Creating the AWS VPC Endpoint)
     *
     * @schema PrivateEndpoint#SubnetIds
     */
    readonly subnetIds?: string[];
    /**
     * Unique identifiers of the interface endpoints in your VPC that you added to the AWS PrivateLink connection.
     *
     * @schema PrivateEndpoint#InterfaceEndpointId
     */
    readonly interfaceEndpointId?: string;
    /**
     * Status of the AWS PrivateEndpoint connection.
     *
     * @schema PrivateEndpoint#AWSPrivateEndpointStatus
     */
    readonly awsPrivateEndpointStatus?: string;
    /**
     * Status of the Atlas PrivateEndpoint connection.
     *
     * @schema PrivateEndpoint#AtlasPrivateEndpointStatus
     */
    readonly atlasPrivateEndpointStatus?: string;
}
/**
 * Converts an object of type 'PrivateEndpoint' to JSON representation.
 */
export declare function toJson_PrivateEndpoint(obj: PrivateEndpoint | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::PrivateEndpoint`
 *
 * @cloudformationResource MongoDB::Atlas::PrivateEndpoint
 * @stability external
 */
export declare class CfnPrivateEndpoint extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::PrivateEndpoint";
    /**
     * Resource props.
     */
    readonly props: CfnPrivateEndpointProps;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpoint.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpoint.InterfaceEndpoints`
     */
    readonly attrInterfaceEndpoints: string[];
    /**
     * Create a new `MongoDB::Atlas::PrivateEndpoint`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnPrivateEndpointProps);
}
