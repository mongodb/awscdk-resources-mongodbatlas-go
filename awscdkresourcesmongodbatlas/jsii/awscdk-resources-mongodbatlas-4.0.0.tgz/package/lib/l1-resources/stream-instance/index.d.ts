import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, edits, and removes Atlas Stream Processing Instances.
 *
 * @schema CfnStreamInstanceProps
 */
export interface CfnStreamInstanceProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnStreamInstanceProps#Profile
     */
    readonly profile?: string;
    /**
     * Human-readable label that identifies the stream connection.
     *
     * @schema CfnStreamInstanceProps#InstanceName
     */
    readonly instanceName: string;
    /**
     * @schema CfnStreamInstanceProps#DataProcessRegion
     */
    readonly dataProcessRegion: StreamsDataProcessRegion;
    /**
     * @schema CfnStreamInstanceProps#StreamConfig
     */
    readonly streamConfig: StreamConfig;
    /**
     * @schema CfnStreamInstanceProps#Connections
     */
    readonly connections?: StreamsConnection[];
    /**
     * Unique 24-hexadecimal character string that identifies the project.
     *
     * @schema CfnStreamInstanceProps#ProjectId
     */
    readonly projectId: string;
}
/**
 * Converts an object of type 'CfnStreamInstanceProps' to JSON representation.
 */
export declare function toJson_CfnStreamInstanceProps(obj: CfnStreamInstanceProps | undefined): Record<string, any> | undefined;
/**
 * Information about the cloud provider region in which MongoDB Cloud processes the stream.
 *
 * @schema StreamsDataProcessRegion
 */
export interface StreamsDataProcessRegion {
    /**
     * Label that identifies the cloud service provider where MongoDB Cloud performs stream processing. Currently, this parameter supports AWS only.
     *
     * @schema StreamsDataProcessRegion#CloudProvider
     */
    readonly cloudProvider: StreamsDataProcessRegionCloudProvider;
    /**
     * @schema StreamsDataProcessRegion#Region
     */
    readonly region: string;
}
/**
 * Converts an object of type 'StreamsDataProcessRegion' to JSON representation.
 */
export declare function toJson_StreamsDataProcessRegion(obj: StreamsDataProcessRegion | undefined): Record<string, any> | undefined;
/**
 * Configuration options for an Atlas Stream Processing Instance.
 *
 * @schema StreamConfig
 */
export interface StreamConfig {
    /**
     * Selected tier for the Stream Instance. Configures Memory / VCPU allowances.
     *
     * @schema StreamConfig#Tier
     */
    readonly tier?: string;
}
/**
 * Converts an object of type 'StreamConfig' to JSON representation.
 */
export declare function toJson_StreamConfig(obj: StreamConfig | undefined): Record<string, any> | undefined;
/**
 * Settings that define a connection to an external data store.
 *
 * @schema StreamsConnection
 */
export interface StreamsConnection {
    /**
     * Human-readable label that identifies the stream connection.
     *
     * @schema StreamsConnection#Name
     */
    readonly name?: string;
    /**
     * Type of the connection. Can be either Cluster or Kafka.
     *
     * @schema StreamsConnection#Type
     */
    readonly type?: StreamsConnectionType;
    /**
     * @schema StreamsConnection#Authentication
     */
    readonly authentication?: StreamsKafkaAuthentication;
    /**
     * Comma separated list of server addresses.
     *
     * @schema StreamsConnection#BootstrapServers
     */
    readonly bootstrapServers?: string;
    /**
     * @schema StreamsConnection#Security
     */
    readonly security?: StreamsKafkaSecurity;
    /**
     * Name of the cluster configured for this connection.
     *
     * @schema StreamsConnection#ClusterName
     */
    readonly clusterName?: string;
    /**
     * @schema StreamsConnection#DbRoleToExecute
     */
    readonly dbRoleToExecute?: DbRoleToExecute;
}
/**
 * Converts an object of type 'StreamsConnection' to JSON representation.
 */
export declare function toJson_StreamsConnection(obj: StreamsConnection | undefined): Record<string, any> | undefined;
/**
 * Label that identifies the cloud service provider where MongoDB Cloud performs stream processing. Currently, this parameter supports AWS only.
 *
 * @schema StreamsDataProcessRegionCloudProvider
 */
export declare enum StreamsDataProcessRegionCloudProvider {
    /** AWS */
    AWS = "AWS",
    /** GCP */
    GCP = "GCP",
    /** AZURE */
    AZURE = "AZURE",
    /** TENANT */
    TENANT = "TENANT",
    /** SERVERLESS */
    SERVERLESS = "SERVERLESS"
}
/**
 * Type of the connection. Can be either Cluster or Kafka.
 *
 * @schema StreamsConnectionType
 */
export declare enum StreamsConnectionType {
    /** Kafka */
    KAFKA = "Kafka",
    /** Cluster */
    CLUSTER = "Cluster",
    /** Sample */
    SAMPLE = "Sample"
}
/**
 * User credentials required to connect to a Kafka Cluster. Includes the authentication type, as well as the parameters for that authentication mode.
 *
 * @schema StreamsKafkaAuthentication
 */
export interface StreamsKafkaAuthentication {
    /**
     * Style of authentication. Can be one of PLAIN, SCRAM-256, or SCRAM-512.
     *
     * @schema StreamsKafkaAuthentication#Mechanism
     */
    readonly mechanism?: string;
    /**
     * Username of the account to connect to the Kafka cluster.
     *
     * @schema StreamsKafkaAuthentication#Username
     */
    readonly username?: string;
}
/**
 * Converts an object of type 'StreamsKafkaAuthentication' to JSON representation.
 */
export declare function toJson_StreamsKafkaAuthentication(obj: StreamsKafkaAuthentication | undefined): Record<string, any> | undefined;
/**
 * Properties for the secure transport connection to Kafka. For SSL, this can include the trusted certificate to use.
 *
 * @schema StreamsKafkaSecurity
 */
export interface StreamsKafkaSecurity {
    /**
     * A trusted, public x509 certificate for connecting to Kafka over SSL.
     *
     * @schema StreamsKafkaSecurity#BrokerPublicCertificate
     */
    readonly brokerPublicCertificate?: string;
    /**
     * Describes the transport type. Can be either PLAINTEXT or SSL.
     *
     * @schema StreamsKafkaSecurity#Protocol
     */
    readonly protocol?: string;
}
/**
 * Converts an object of type 'StreamsKafkaSecurity' to JSON representation.
 */
export declare function toJson_StreamsKafkaSecurity(obj: StreamsKafkaSecurity | undefined): Record<string, any> | undefined;
/**
 * The name of a Built in or Custom DB Role to connect to an Atlas Cluster.
 *
 * @schema DBRoleToExecute
 */
export interface DbRoleToExecute {
    /**
     * The name of the role to use. Can be a built in role or a custom role.
     *
     * @schema DBRoleToExecute#Role
     */
    readonly role?: string;
    /**
     * Type of the DB role. Can be either BuiltIn or Custom.
     *
     * @schema DBRoleToExecute#Type
     */
    readonly type?: DbRoleToExecuteType;
}
/**
 * Converts an object of type 'DbRoleToExecute' to JSON representation.
 */
export declare function toJson_DbRoleToExecute(obj: DbRoleToExecute | undefined): Record<string, any> | undefined;
/**
 * Type of the DB role. Can be either BuiltIn or Custom.
 *
 * @schema DbRoleToExecuteType
 */
export declare enum DbRoleToExecuteType {
    /** BUILT_IN */
    BUILT_IN = "BUILT_IN",
    /** CUSTOM */
    CUSTOM = "CUSTOM"
}
/**
 * A CloudFormation `MongoDB::Atlas::StreamInstance`
 *
 * @cloudformationResource MongoDB::Atlas::StreamInstance
 * @stability external
 */
export declare class CfnStreamInstance extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::StreamInstance";
    /**
     * Resource props.
     */
    readonly props: CfnStreamInstanceProps;
    /**
     * Attribute `MongoDB::Atlas::StreamInstance.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::StreamInstance.Hostnames`
     */
    readonly attrHostnames: string[];
    /**
     * Create a new `MongoDB::Atlas::StreamInstance`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnStreamInstanceProps);
}
