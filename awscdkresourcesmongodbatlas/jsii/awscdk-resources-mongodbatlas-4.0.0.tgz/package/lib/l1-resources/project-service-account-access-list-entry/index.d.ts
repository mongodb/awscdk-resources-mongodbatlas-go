import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Manages IP access list entries for MongoDB Atlas Project Service Accounts.
 *
 * @schema CfnProjectServiceAccountAccessListEntryProps
 */
export interface CfnProjectServiceAccountAccessListEntryProps {
    /**
     * Unique 24-hexadecimal digit string that identifies the project.
     *
     * @schema CfnProjectServiceAccountAccessListEntryProps#ProjectId
     */
    readonly projectId: string;
    /**
     * The Client ID of the Service Account.
     *
     * @schema CfnProjectServiceAccountAccessListEntryProps#ClientId
     */
    readonly clientId: string;
    /**
     * Range of IP addresses in CIDR notation to be added to the access list. You can set a value for this parameter or IPAddress, but not both.
     *
     * @schema CfnProjectServiceAccountAccessListEntryProps#CIDRBlock
     */
    readonly cidrBlock?: string;
    /**
     * Single IP address to be added to the access list. You can set a value for this parameter or CIDRBlock, but not both.
     *
     * @schema CfnProjectServiceAccountAccessListEntryProps#IPAddress
     */
    readonly ipAddress?: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used.
     *
     * @schema CfnProjectServiceAccountAccessListEntryProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnProjectServiceAccountAccessListEntryProps' to JSON representation.
 */
export declare function toJson_CfnProjectServiceAccountAccessListEntryProps(obj: CfnProjectServiceAccountAccessListEntryProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::ProjectServiceAccountAccessListEntry`
 *
 * @cloudformationResource MongoDB::Atlas::ProjectServiceAccountAccessListEntry
 * @stability external
 */
export declare class CfnProjectServiceAccountAccessListEntry extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ProjectServiceAccountAccessListEntry";
    /**
     * Resource props.
     */
    readonly props: CfnProjectServiceAccountAccessListEntryProps;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountAccessListEntry.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountAccessListEntry.LastUsedAddress`
     */
    readonly attrLastUsedAddress: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountAccessListEntry.LastUsedAt`
     */
    readonly attrLastUsedAt: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccountAccessListEntry.RequestCount`
     */
    readonly attrRequestCount: number;
    /**
     * Create a new `MongoDB::Atlas::ProjectServiceAccountAccessListEntry`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnProjectServiceAccountAccessListEntryProps);
}
