import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Creates and manages a Project Service Account. This resource creates a Service Account and assigns it to a project. Note: Deleting this resource only unassigns the Service Account from the project, but doesn't delete it from the organization.
 *
 * @schema CfnProjectServiceAccountProps
 */
export interface CfnProjectServiceAccountProps {
    /**
     * Profile used to provide credentials information.
     *
     * @schema CfnProjectServiceAccountProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnProjectServiceAccountProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Human-readable name for the Service Account.
     *
     * @schema CfnProjectServiceAccountProps#Name
     */
    readonly name: string;
    /**
     * Human readable description for the Service Account.
     *
     * @schema CfnProjectServiceAccountProps#Description
     */
    readonly description: string;
    /**
     * A list of project-level roles for the Service Account.
     *
     * @schema CfnProjectServiceAccountProps#Roles
     */
    readonly roles: string[];
    /**
     * Expiration time of the new Service Account secret in hours.
     *
     * @schema CfnProjectServiceAccountProps#SecretExpiresAfterHours
     */
    readonly secretExpiresAfterHours: number;
    /**
     * List of secrets associated with the Service Account.
     *
     * @schema CfnProjectServiceAccountProps#Secrets
     */
    readonly secrets?: SecretDefinition[];
}
/**
 * Converts an object of type 'CfnProjectServiceAccountProps' to JSON representation.
 */
export declare function toJson_CfnProjectServiceAccountProps(obj: CfnProjectServiceAccountProps | undefined): Record<string, any> | undefined;
/**
 * @schema SecretDefinition
 */
export interface SecretDefinition {
    /**
     * Unique identifier of the secret.
     *
     * @schema SecretDefinition#Id
     */
    readonly id?: string;
    /**
     * Date and time that the secret was created on.
     *
     * @schema SecretDefinition#CreatedAt
     */
    readonly createdAt?: string;
    /**
     * Date and time when the secret expires.
     *
     * @schema SecretDefinition#ExpiresAt
     */
    readonly expiresAt?: string;
    /**
     * Date and time when the secret was last used.
     *
     * @schema SecretDefinition#LastUsedAt
     */
    readonly lastUsedAt?: string;
    /**
     * Masked value of the secret.
     *
     * @schema SecretDefinition#MaskedSecretValue
     */
    readonly maskedSecretValue?: string;
    /**
     * The secret value. Only returned on create.
     *
     * @schema SecretDefinition#Secret
     */
    readonly secret?: string;
}
/**
 * Converts an object of type 'SecretDefinition' to JSON representation.
 */
export declare function toJson_SecretDefinition(obj: SecretDefinition | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::ProjectServiceAccount`
 *
 * @cloudformationResource MongoDB::Atlas::ProjectServiceAccount
 * @stability external
 */
export declare class CfnProjectServiceAccount extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ProjectServiceAccount";
    /**
     * Resource props.
     */
    readonly props: CfnProjectServiceAccountProps;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccount.ClientId`
     */
    readonly attrClientId: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectServiceAccount.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Create a new `MongoDB::Atlas::ProjectServiceAccount`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnProjectServiceAccountProps);
}
