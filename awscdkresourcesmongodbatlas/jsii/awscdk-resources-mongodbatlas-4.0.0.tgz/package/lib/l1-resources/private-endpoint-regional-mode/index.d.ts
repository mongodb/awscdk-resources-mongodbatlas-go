import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * An example resource schema demonstrating some basic constructs and validation rules.
 *
 * @schema CfnPrivateEndPointRegionalModeProps
 */
export interface CfnPrivateEndPointRegionalModeProps {
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnPrivateEndPointRegionalModeProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnPrivateEndPointRegionalModeProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnPrivateEndPointRegionalModeProps' to JSON representation.
 */
export declare function toJson_CfnPrivateEndPointRegionalModeProps(obj: CfnPrivateEndPointRegionalModeProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::PrivateEndPointRegionalMode`
 *
 * @cloudformationResource MongoDB::Atlas::PrivateEndPointRegionalMode
 * @stability external
 */
export declare class CfnPrivateEndPointRegionalMode extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::PrivateEndPointRegionalMode";
    /**
     * Resource props.
     */
    readonly props: CfnPrivateEndPointRegionalModeProps;
    /**
     * Create a new `MongoDB::Atlas::PrivateEndPointRegionalMode`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnPrivateEndPointRegionalModeProps);
}
