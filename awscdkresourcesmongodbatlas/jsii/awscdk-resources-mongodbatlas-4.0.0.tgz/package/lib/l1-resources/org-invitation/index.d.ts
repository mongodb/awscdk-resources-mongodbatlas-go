import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, and edits organizational units in MongoDB Cloud.
 *
 * @schema CfnOrgInvitationProps
 */
export interface CfnOrgInvitationProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnOrgInvitationProps#Profile
     */
    readonly profile: string;
    /**
     * Flag that indicates whether the response returns the total number of items (**totalCount**) in the response.
     *
     * @schema CfnOrgInvitationProps#IncludeCount
     */
    readonly includeCount?: boolean;
    /**
     * Unique 24-hexadecimal digit string that identifies the invitation.
     *
     * @schema CfnOrgInvitationProps#InvitationId
     */
    readonly invitationId?: string;
    /**
     * Number of items that the response returns per page.
     *
     * @schema CfnOrgInvitationProps#ItemsPerPage
     */
    readonly itemsPerPage?: number;
    /**
     * Unique 24-hexadecimal digit string that identifies the organization that contains your projects.
     *
     * @schema CfnOrgInvitationProps#OrgId
     */
    readonly orgId?: string;
    /**
     * Human-readable label that identifies this organization.
     *
     * @schema CfnOrgInvitationProps#OrgName
     */
    readonly orgName?: string;
    /**
     * Number of the page that displays the current set of the total objects that the response returns.
     *
     * @schema CfnOrgInvitationProps#PageNum
     */
    readonly pageNum?: number;
    /**
     * One or more organization or project level roles to assign to the MongoDB Cloud user.
     *
     * @schema CfnOrgInvitationProps#Roles
     */
    readonly roles?: CfnOrgInvitationPropsRoles[];
    /**
     * List of unique 24-hexadecimal digit strings that identifies each team.
     *
     * @schema CfnOrgInvitationProps#TeamIds
     */
    readonly teamIds?: string[];
    /**
     * Number of documents returned in this response.
     *
     * @schema CfnOrgInvitationProps#TotalCount
     */
    readonly totalCount?: number;
    /**
     * Email address of the MongoDB Cloud user invited to join the organization.
     *
     * @schema CfnOrgInvitationProps#Username
     */
    readonly username?: string;
}
/**
 * Converts an object of type 'CfnOrgInvitationProps' to JSON representation.
 */
export declare function toJson_CfnOrgInvitationProps(obj: CfnOrgInvitationProps | undefined): Record<string, any> | undefined;
/**
 * @schema CfnOrgInvitationPropsRoles
 */
export declare enum CfnOrgInvitationPropsRoles {
    /** ORG_OWNER */
    ORG_OWNER = "ORG_OWNER",
    /** ORG_MEMBER */
    ORG_MEMBER = "ORG_MEMBER",
    /** ORG_GROUP_CREATOR */
    ORG_GROUP_CREATOR = "ORG_GROUP_CREATOR",
    /** ORG_BILLING_ADMIN */
    ORG_BILLING_ADMIN = "ORG_BILLING_ADMIN",
    /** ORG_READ_ONLY */
    ORG_READ_ONLY = "ORG_READ_ONLY",
    /** GROUP_CLUSTER_MANAGER */
    GROUP_CLUSTER_MANAGER = "GROUP_CLUSTER_MANAGER",
    /** GROUP_DATA_ACCESS_ADMIN */
    GROUP_DATA_ACCESS_ADMIN = "GROUP_DATA_ACCESS_ADMIN",
    /** GROUP_DATA_ACCESS_READ_ONLY */
    GROUP_DATA_ACCESS_READ_ONLY = "GROUP_DATA_ACCESS_READ_ONLY",
    /** GROUP_DATA_ACCESS_READ_WRITE */
    GROUP_DATA_ACCESS_READ_WRITE = "GROUP_DATA_ACCESS_READ_WRITE",
    /** GROUP_OWNER */
    GROUP_OWNER = "GROUP_OWNER",
    /** GROUP_READ_ONLY */
    GROUP_READ_ONLY = "GROUP_READ_ONLY"
}
/**
 * A CloudFormation `MongoDB::Atlas::OrgInvitation`
 *
 * @cloudformationResource MongoDB::Atlas::OrgInvitation
 * @stability external
 */
export declare class CfnOrgInvitation extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::OrgInvitation";
    /**
     * Resource props.
     */
    readonly props: CfnOrgInvitationProps;
    /**
     * Attribute `MongoDB::Atlas::OrgInvitation.ExpiresAt`
     */
    readonly attrExpiresAt: string;
    /**
     * Attribute `MongoDB::Atlas::OrgInvitation.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::OrgInvitation.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Attribute `MongoDB::Atlas::OrgInvitation.InviterUsername`
     */
    readonly attrInviterUsername: string;
    /**
     * Create a new `MongoDB::Atlas::OrgInvitation`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnOrgInvitationProps);
}
