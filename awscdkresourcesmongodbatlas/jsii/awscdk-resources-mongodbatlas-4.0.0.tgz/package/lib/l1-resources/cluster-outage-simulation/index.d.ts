import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * An example resource schema demonstrating some basic constructs and validation rules.
 *
 * @schema CfnClusterOutageSimulationProps
 */
export interface CfnClusterOutageSimulationProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnClusterOutageSimulationProps#Profile
     */
    readonly profile: string;
    /**
     * List of settings that configure your cluster regions. For Global Clusters, each object in the array represents a zone where your clusters nodes deploy. For non-Global replica sets and sharded clusters, this array has one object representing where your clusters nodes deploy.
     *
     * @schema CfnClusterOutageSimulationProps#OutageFilters
     */
    readonly outageFilters: Filter[];
    /**
     * Human-readable label that identifies the project.
     *
     * @schema CfnClusterOutageSimulationProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Human-readable label that identifies the cluster .
     *
     * @schema CfnClusterOutageSimulationProps#ClusterName
     */
    readonly clusterName: string;
}
/**
 * Converts an object of type 'CfnClusterOutageSimulationProps' to JSON representation.
 */
export declare function toJson_CfnClusterOutageSimulationProps(obj: CfnClusterOutageSimulationProps | undefined): Record<string, any> | undefined;
/**
 * @schema Filter
 */
export interface Filter {
    /**
     * @schema Filter#CloudProvider
     */
    readonly cloudProvider?: FilterCloudProvider;
    /**
     * @schema Filter#Region
     */
    readonly region?: string;
    /**
     * @schema Filter#Type
     */
    readonly type?: string;
}
/**
 * Converts an object of type 'Filter' to JSON representation.
 */
export declare function toJson_Filter(obj: Filter | undefined): Record<string, any> | undefined;
/**
 * @schema FilterCloudProvider
 */
export declare enum FilterCloudProvider {
    /** AWS */
    AWS = "AWS",
    /** AZURE */
    AZURE = "AZURE",
    /** GCP */
    GCP = "GCP"
}
/**
 * A CloudFormation `MongoDB::Atlas::ClusterOutageSimulation`
 *
 * @cloudformationResource MongoDB::Atlas::ClusterOutageSimulation
 * @stability external
 */
export declare class CfnClusterOutageSimulation extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ClusterOutageSimulation";
    /**
     * Resource props.
     */
    readonly props: CfnClusterOutageSimulationProps;
    /**
     * Attribute `MongoDB::Atlas::ClusterOutageSimulation.SimulationId`
     */
    readonly attrSimulationId: string;
    /**
     * Attribute `MongoDB::Atlas::ClusterOutageSimulation.StartRequestDate`
     */
    readonly attrStartRequestDate: string;
    /**
     * Attribute `MongoDB::Atlas::ClusterOutageSimulation.State`
     */
    readonly attrState: string;
    /**
     * Create a new `MongoDB::Atlas::ClusterOutageSimulation`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnClusterOutageSimulationProps);
}
