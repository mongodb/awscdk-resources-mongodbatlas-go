import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns and edits the Encryption at Rest using Customer Key Management configuration.
 *
 * @schema CfnEncryptionAtRestProps
 */
export interface CfnEncryptionAtRestProps {
    /**
     * @schema CfnEncryptionAtRestProps#AwsKmsConfig
     */
    readonly awsKmsConfig: AwsKmsConfig;
    /**
     * Flag that indicates whether Encryption at Rest for Dedicated Search Nodes is enabled in the specified project.
     *
     * @schema CfnEncryptionAtRestProps#EnabledForSearchNodes
     */
    readonly enabledForSearchNodes?: boolean;
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnEncryptionAtRestProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique identifier of the Atlas project to which the user belongs.
     *
     * @schema CfnEncryptionAtRestProps#ProjectId
     */
    readonly projectId: string;
}
/**
 * Converts an object of type 'CfnEncryptionAtRestProps' to JSON representation.
 */
export declare function toJson_CfnEncryptionAtRestProps(obj: CfnEncryptionAtRestProps | undefined): Record<string, any> | undefined;
/**
 * Specifies AWS KMS configuration details and whether Encryption at Rest is enabled for an Atlas project.
 *
 * @schema AwsKmsConfig
 */
export interface AwsKmsConfig {
    /**
     * Specifies whether Encryption at Rest is enabled for an Atlas project. To disable Encryption at Rest, pass only this parameter with a value of false. When you disable Encryption at Rest, Atlas also removes the configuration details.
     *
     * @schema AwsKmsConfig#Enabled
     */
    readonly enabled?: boolean;
    /**
     * Unique alphanumeric string that identifies the Amazon Web Services (AWS) Customer Master Key (CMK) you used to encrypt and decrypt the MongoDB master keys.
     *
     * @schema AwsKmsConfig#CustomerMasterKeyID
     */
    readonly customerMasterKeyId?: string;
    /**
     * Physical location where MongoDB Atlas deploys your AWS-hosted MongoDB cluster nodes. The region you choose can affect network latency for clients accessing your databases.
     *
     * @schema AwsKmsConfig#Region
     */
    readonly region?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies an Amazon Web Services (AWS) Identity and Access Management (IAM) role. This IAM role has the permissions required to manage your AWS customer master key.
     *
     * @schema AwsKmsConfig#RoleID
     */
    readonly roleId?: string;
    /**
     * Flag that indicates whether the Amazon Web Services (AWS) Key Management Service (KMS) encryption key can encrypt and decrypt data.
     *
     * @schema AwsKmsConfig#Valid
     */
    readonly valid?: boolean;
    /**
     * Enable connection to your Amazon Web Services (AWS) Key Management Service (KMS) over private networking.
     *
     * @schema AwsKmsConfig#RequirePrivateNetworking
     */
    readonly requirePrivateNetworking?: boolean;
}
/**
 * Converts an object of type 'AwsKmsConfig' to JSON representation.
 */
export declare function toJson_AwsKmsConfig(obj: AwsKmsConfig | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::EncryptionAtRest`
 *
 * @cloudformationResource MongoDB::Atlas::EncryptionAtRest
 * @stability external
 */
export declare class CfnEncryptionAtRest extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::EncryptionAtRest";
    /**
     * Resource props.
     */
    readonly props: CfnEncryptionAtRestProps;
    /**
     * Attribute `MongoDB::Atlas::EncryptionAtRest.Id`
     */
    readonly attrId: string;
    /**
     * Create a new `MongoDB::Atlas::EncryptionAtRest`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnEncryptionAtRestProps);
}
