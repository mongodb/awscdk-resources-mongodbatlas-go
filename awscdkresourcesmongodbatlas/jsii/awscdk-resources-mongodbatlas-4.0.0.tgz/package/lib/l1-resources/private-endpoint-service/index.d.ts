import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Creates one private endpoint service for the specified cloud service provider. This cloud service provider manages the private endpoint service for the project. When you create a private endpoint service, MongoDB Cloud creates a network container in the project for the cloud provider for which you create the private endpoint service if one doesn't already exist.
 *
 * @schema CfnPrivateEndpointServiceProps
 */
export interface CfnPrivateEndpointServiceProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml)
     *
     * @schema CfnPrivateEndpointServiceProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnPrivateEndpointServiceProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Aws Region
     *
     * @schema CfnPrivateEndpointServiceProps#Region
     */
    readonly region: string;
    /**
     * Cloud service provider that manages this private endpoint, default : AWS
     *
     * @schema CfnPrivateEndpointServiceProps#CloudProvider
     */
    readonly cloudProvider: CfnPrivateEndpointServicePropsCloudProvider;
}
/**
 * Converts an object of type 'CfnPrivateEndpointServiceProps' to JSON representation.
 */
export declare function toJson_CfnPrivateEndpointServiceProps(obj: CfnPrivateEndpointServiceProps | undefined): Record<string, any> | undefined;
/**
 * Cloud service provider that manages this private endpoint, default : AWS
 *
 * @schema CfnPrivateEndpointServicePropsCloudProvider
 */
export declare enum CfnPrivateEndpointServicePropsCloudProvider {
    /** AWS */
    AWS = "AWS",
    /** AZURE */
    AZURE = "AZURE",
    /** GCP */
    GCP = "GCP"
}
/**
 * A CloudFormation `MongoDB::Atlas::PrivateEndpointService`
 *
 * @cloudformationResource MongoDB::Atlas::PrivateEndpointService
 * @stability external
 */
export declare class CfnPrivateEndpointService extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::PrivateEndpointService";
    /**
     * Resource props.
     */
    readonly props: CfnPrivateEndpointServiceProps;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointService.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointService.EndpointServiceName`
     */
    readonly attrEndpointServiceName: string;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointService.ErrorMessage`
     */
    readonly attrErrorMessage: string;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointService.Status`
     */
    readonly attrStatus: string;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointService.InterfaceEndpoints`
     */
    readonly attrInterfaceEndpoints: string[];
    /**
     * Create a new `MongoDB::Atlas::PrivateEndpointService`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnPrivateEndpointServiceProps);
}
