import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Creates and manages a Service Account for an organization.
 *
 * @schema CfnServiceAccountProps
 */
export interface CfnServiceAccountProps {
    /**
     * Profile used to provide credentials information.
     *
     * @schema CfnServiceAccountProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the organization.
     *
     * @schema CfnServiceAccountProps#OrgId
     */
    readonly orgId: string;
    /**
     * Human-readable name for the Service Account.
     *
     * @schema CfnServiceAccountProps#Name
     */
    readonly name: string;
    /**
     * Human readable description for the Service Account.
     *
     * @schema CfnServiceAccountProps#Description
     */
    readonly description: string;
    /**
     * List of organization-level roles for the Service Account.
     *
     * @schema CfnServiceAccountProps#Roles
     */
    readonly roles: string[];
    /**
     * Expiration time of the new Service Account secret in hours.
     *
     * @schema CfnServiceAccountProps#SecretExpiresAfterHours
     */
    readonly secretExpiresAfterHours: number;
    /**
     * List of secrets associated with the Service Account.
     *
     * @schema CfnServiceAccountProps#Secrets
     */
    readonly secrets?: Secret[];
}
/**
 * Converts an object of type 'CfnServiceAccountProps' to JSON representation.
 */
export declare function toJson_CfnServiceAccountProps(obj: CfnServiceAccountProps | undefined): Record<string, any> | undefined;
/**
 * @schema Secret
 */
export interface Secret {
    /**
     * Unique identifier of the secret.
     *
     * @schema Secret#Id
     */
    readonly id?: string;
    /**
     * Date and time that the secret was created on.
     *
     * @schema Secret#CreatedAt
     */
    readonly createdAt?: string;
    /**
     * Date and time when the secret expires.
     *
     * @schema Secret#ExpiresAt
     */
    readonly expiresAt?: string;
    /**
     * Date and time when the secret was last used.
     *
     * @schema Secret#LastUsedAt
     */
    readonly lastUsedAt?: string;
    /**
     * Masked value of the secret.
     *
     * @schema Secret#MaskedSecretValue
     */
    readonly maskedSecretValue?: string;
    /**
     * The secret value. Only returned on create.
     *
     * @schema Secret#Secret
     */
    readonly secret?: string;
}
/**
 * Converts an object of type 'Secret' to JSON representation.
 */
export declare function toJson_Secret(obj: Secret | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::ServiceAccount`
 *
 * @cloudformationResource MongoDB::Atlas::ServiceAccount
 * @stability external
 */
export declare class CfnServiceAccount extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ServiceAccount";
    /**
     * Resource props.
     */
    readonly props: CfnServiceAccountProps;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccount.ClientId`
     */
    readonly attrClientId: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccount.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Create a new `MongoDB::Atlas::ServiceAccount`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnServiceAccountProps);
}
