import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * The maintenanceWindow resource provides access to retrieve or update the current Atlas project maintenance window.
 *
 * @schema CfnMaintenanceWindowProps
 */
export interface CfnMaintenanceWindowProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml)
     *
     * @schema CfnMaintenanceWindowProps#Profile
     */
    readonly profile?: string;
    /**
     * Flag that indicates whether MongoDB Cloud should defer all maintenance windows for one week after you enable them.
     *
     * @schema CfnMaintenanceWindowProps#AutoDeferOnceEnabled
     */
    readonly autoDeferOnceEnabled?: boolean;
    /**
     * One-based integer that represents the day of the week that the maintenance window starts.
     *
     * | Value | Day of Week |
     * |---|---|
     * | `1` | Sunday |
     * | `2` | Monday |
     * | `3` | Tuesday |
     * | `4` | Wednesday |
     * | `5` | Thursday |
     * | `6` | Friday |
     * | `7` | Saturday |
     *
     *
     * @schema CfnMaintenanceWindowProps#DayOfWeek
     */
    readonly dayOfWeek: number;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnMaintenanceWindowProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Zero-based integer that represents the hour of the of the day that the maintenance window starts according to a 24-hour clock. Use `0` for midnight and `12` for noon.
     *
     * @schema CfnMaintenanceWindowProps#HourOfDay
     */
    readonly hourOfDay: number;
    /**
     * Flag that indicates whether to defer the maintenance window. When set to true, the next scheduled maintenance will be deferred.
     *
     * @schema CfnMaintenanceWindowProps#Defer
     */
    readonly defer?: boolean;
    /**
     * Flag that indicates whether MongoDB Cloud should automatically defer maintenance windows for one week when they occur during the defined maintenance window.
     *
     * @schema CfnMaintenanceWindowProps#AutoDefer
     */
    readonly autoDefer?: boolean;
    /**
     * Protected hours during which MongoDB Cloud cannot start maintenance.
     *
     * @schema CfnMaintenanceWindowProps#ProtectedHours
     */
    readonly protectedHours?: CfnMaintenanceWindowPropsProtectedHours;
}
/**
 * Converts an object of type 'CfnMaintenanceWindowProps' to JSON representation.
 */
export declare function toJson_CfnMaintenanceWindowProps(obj: CfnMaintenanceWindowProps | undefined): Record<string, any> | undefined;
/**
 * Protected hours during which MongoDB Cloud cannot start maintenance.
 *
 * @schema CfnMaintenanceWindowPropsProtectedHours
 */
export interface CfnMaintenanceWindowPropsProtectedHours {
    /**
     * Hour of the day when protected hours start (0-23).
     *
     * @schema CfnMaintenanceWindowPropsProtectedHours#StartHourOfDay
     */
    readonly startHourOfDay?: number;
    /**
     * Hour of the day when protected hours end (0-23).
     *
     * @schema CfnMaintenanceWindowPropsProtectedHours#EndHourOfDay
     */
    readonly endHourOfDay?: number;
}
/**
 * Converts an object of type 'CfnMaintenanceWindowPropsProtectedHours' to JSON representation.
 */
export declare function toJson_CfnMaintenanceWindowPropsProtectedHours(obj: CfnMaintenanceWindowPropsProtectedHours | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::MaintenanceWindow`
 *
 * @cloudformationResource MongoDB::Atlas::MaintenanceWindow
 * @stability external
 */
export declare class CfnMaintenanceWindow extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::MaintenanceWindow";
    /**
     * Resource props.
     */
    readonly props: CfnMaintenanceWindowProps;
    /**
     * Attribute `MongoDB::Atlas::MaintenanceWindow.StartASAP`
     */
    readonly attrStartASAP: cdk.IResolvable;
    /**
     * Attribute `MongoDB::Atlas::MaintenanceWindow.NumberOfDeferrals`
     */
    readonly attrNumberOfDeferrals: number;
    /**
     * Attribute `MongoDB::Atlas::MaintenanceWindow.TimeZoneId`
     */
    readonly attrTimeZoneId: string;
    /**
     * Create a new `MongoDB::Atlas::MaintenanceWindow`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnMaintenanceWindowProps);
}
