import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * The log integration resource provides access to push-based log export configurations for MongoDB Atlas. The resource allows you to create, edit and delete log export integrations (e.g. to cloud storage or log services). This release supports S3 integration; additional integration types will be added as the API supports them. The resource requires your Project ID.
 *
 * @schema CfnLogIntegrationProps
 */
export interface CfnLogIntegrationProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnLogIntegrationProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project. Use the /groups endpoint to retrieve all projects to which the authenticated user has access. Groups and projects are synonymous terms. Your group id is the same as your project id.
     *
     * @schema CfnLogIntegrationProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Human-readable label that identifies the service to which you want to integrate with MongoDB Cloud. The value must match the log integration type.
     *
     * @schema CfnLogIntegrationProps#Type
     */
    readonly type: string;
    /**
     * Human-readable label that identifies the bucket (or storage container) name for storing log files.
     *
     * @schema CfnLogIntegrationProps#BucketName
     */
    readonly bucketName: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the AWS IAM role that MongoDB Cloud uses to access your S3 bucket.
     *
     * @schema CfnLogIntegrationProps#IamRoleId
     */
    readonly iamRoleId: string;
    /**
     * Path prefix where log files will be stored. MongoDB Cloud adds further sub-directories based on the log type.
     *
     * @schema CfnLogIntegrationProps#PrefixPath
     */
    readonly prefixPath: string;
    /**
     * AWS KMS key ID or ARN for server-side encryption (optional). If not provided, uses bucket default encryption settings.
     *
     * @schema CfnLogIntegrationProps#KmsKey
     */
    readonly kmsKey?: string;
    /**
     * Array of log types to export. Valid values depend on the integration type (e.g. MONGOD, MONGOS, MONGOD_AUDIT, MONGOS_AUDIT for S3).
     *
     * @schema CfnLogIntegrationProps#LogTypes
     */
    readonly logTypes: string[];
}
/**
 * Converts an object of type 'CfnLogIntegrationProps' to JSON representation.
 */
export declare function toJson_CfnLogIntegrationProps(obj: CfnLogIntegrationProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::LogIntegration`
 *
 * @cloudformationResource MongoDB::Atlas::LogIntegration
 * @stability external
 */
export declare class CfnLogIntegration extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::LogIntegration";
    /**
     * Resource props.
     */
    readonly props: CfnLogIntegrationProps;
    /**
     * Attribute `MongoDB::Atlas::LogIntegration.IntegrationId`
     */
    readonly attrIntegrationId: string;
    /**
     * Create a new `MongoDB::Atlas::LogIntegration`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnLogIntegrationProps);
}
