import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Resource for managing MongoDB Atlas Backup Compliance Policy. Backup Compliance Policy prevents any user, regardless of role, from modifying or deleting specific cluster settings, backups, and backup configurations. When enabled, the Backup Compliance Policy will be applied as the minimum policy for all clusters and backups in the project.
 *
 * @schema CfnBackupCompliancePolicyProps
 */
export interface CfnBackupCompliancePolicyProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnBackupCompliancePolicyProps#Profile
     */
    readonly profile?: string;
    /**
     * The unique identifier of the project for the Backup Compliance Policy.
     *
     * @schema CfnBackupCompliancePolicyProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Email address of the user authorized to update the Backup Compliance Policy settings.
     *
     * @schema CfnBackupCompliancePolicyProps#AuthorizedEmail
     */
    readonly authorizedEmail: string;
    /**
     * First name of the user authorized to update the Backup Compliance Policy settings.
     *
     * @schema CfnBackupCompliancePolicyProps#AuthorizedUserFirstName
     */
    readonly authorizedUserFirstName: string;
    /**
     * Last name of the user authorized to update the Backup Compliance Policy settings.
     *
     * @schema CfnBackupCompliancePolicyProps#AuthorizedUserLastName
     */
    readonly authorizedUserLastName: string;
    /**
     * Flag that indicates whether to enable additional copy protection for the cluster. If enabled, cloud backup snapshots cannot be deleted until the retention period expires. Defaults to false if not specified.
     *
     * @default false if not specified.
     * @schema CfnBackupCompliancePolicyProps#CopyProtectionEnabled
     */
    readonly copyProtectionEnabled?: boolean;
    /**
     * Flag that indicates whether Encryption at Rest using Customer Key Management is required for all clusters with a Backup Compliance Policy. Defaults to false if not specified.
     *
     * @default false if not specified.
     * @schema CfnBackupCompliancePolicyProps#EncryptionAtRestEnabled
     */
    readonly encryptionAtRestEnabled?: boolean;
    /**
     * Number of days back in time you can restore to with Continuous Cloud Backup accuracy. Must be a positive, non-zero integer. This field is optional and computed from the API.
     *
     * @schema CfnBackupCompliancePolicyProps#RestoreWindowDays
     */
    readonly restoreWindowDays?: number;
    /**
     * On-demand backup policy item configuration.
     *
     * @schema CfnBackupCompliancePolicyProps#OnDemandPolicyItem
     */
    readonly onDemandPolicyItem?: OnDemandPolicyItem;
    /**
     * Flag that indicates whether the cluster uses Continuous Cloud Backup. If enabled, cloud backup snapshots are taken every 6 hours. Defaults to false if not specified.
     *
     * @default false if not specified.
     * @schema CfnBackupCompliancePolicyProps#PitEnabled
     */
    readonly pitEnabled?: boolean;
    /**
     * Hourly backup policy item configuration. Only one hourly policy item is allowed.
     *
     * @schema CfnBackupCompliancePolicyProps#PolicyItemHourly
     */
    readonly policyItemHourly?: ScheduledPolicyItem;
    /**
     * Daily backup policy item configuration. Only one daily policy item is allowed.
     *
     * @schema CfnBackupCompliancePolicyProps#PolicyItemDaily
     */
    readonly policyItemDaily?: ScheduledPolicyItem;
    /**
     * Weekly backup policy item configuration. Multiple weekly policy items are allowed.
     *
     * @schema CfnBackupCompliancePolicyProps#PolicyItemWeekly
     */
    readonly policyItemWeekly?: ScheduledPolicyItem[];
    /**
     * Monthly backup policy item configuration. Multiple monthly policy items are allowed.
     *
     * @schema CfnBackupCompliancePolicyProps#PolicyItemMonthly
     */
    readonly policyItemMonthly?: ScheduledPolicyItem[];
    /**
     * Yearly backup policy item configuration. Multiple yearly policy items are allowed.
     *
     * @schema CfnBackupCompliancePolicyProps#PolicyItemYearly
     */
    readonly policyItemYearly?: ScheduledPolicyItem[];
}
/**
 * Converts an object of type 'CfnBackupCompliancePolicyProps' to JSON representation.
 */
export declare function toJson_CfnBackupCompliancePolicyProps(obj: CfnBackupCompliancePolicyProps | undefined): Record<string, any> | undefined;
/**
 * On-demand backup policy item configuration. When provided, FrequencyInterval, RetentionUnit, and RetentionValue are required.
 *
 * @schema OnDemandPolicyItem
 */
export interface OnDemandPolicyItem {
    /**
     * Unique identifier of the backup policy item.
     *
     * @schema OnDemandPolicyItem#Id
     */
    readonly id?: string;
    /**
     * Number that indicates the frequency interval for a set of snapshots. Required when OnDemandPolicyItem is provided.
     *
     * @schema OnDemandPolicyItem#FrequencyInterval
     */
    readonly frequencyInterval?: number;
    /**
     * Frequency associated with the backup policy item. For on-demand policies, the frequency type is 'ondemand'. This is a read-only value.
     *
     * @schema OnDemandPolicyItem#FrequencyType
     */
    readonly frequencyType?: string;
    /**
     * Unit of time in which MongoDB Cloud measures snapshot retention. Required when OnDemandPolicyItem is provided.
     *
     * @schema OnDemandPolicyItem#RetentionUnit
     */
    readonly retentionUnit?: OnDemandPolicyItemRetentionUnit;
    /**
     * Duration in days, weeks, months, or years that MongoDB Cloud retains the snapshot. Required when OnDemandPolicyItem is provided.
     *
     * @schema OnDemandPolicyItem#RetentionValue
     */
    readonly retentionValue?: number;
}
/**
 * Converts an object of type 'OnDemandPolicyItem' to JSON representation.
 */
export declare function toJson_OnDemandPolicyItem(obj: OnDemandPolicyItem | undefined): Record<string, any> | undefined;
/**
 * Scheduled backup policy item configuration (hourly, daily, weekly, monthly, or yearly). When provided, FrequencyInterval, RetentionUnit, and RetentionValue are required.
 *
 * @schema ScheduledPolicyItem
 */
export interface ScheduledPolicyItem {
    /**
     * Unique identifier of the backup policy item.
     *
     * @schema ScheduledPolicyItem#Id
     */
    readonly id?: string;
    /**
     * Frequency associated with the backup policy item. One of the following values: hourly, daily, weekly, monthly, or yearly. This is a read-only value.
     *
     * @schema ScheduledPolicyItem#FrequencyType
     */
    readonly frequencyType?: string;
    /**
     * Desired frequency of the new backup policy item specified by frequencyType. Required when the policy item is provided.
     *
     * @schema ScheduledPolicyItem#FrequencyInterval
     */
    readonly frequencyInterval?: number;
    /**
     * Unit of time in which MongoDB Cloud measures snapshot retention. Required when the policy item is provided.
     *
     * @schema ScheduledPolicyItem#RetentionUnit
     */
    readonly retentionUnit?: ScheduledPolicyItemRetentionUnit;
    /**
     * Duration in days, weeks, months, or years that MongoDB Cloud retains the snapshot. Required when the policy item is provided. For less frequent policy items, MongoDB Cloud requires that you specify a value greater than or equal to the value specified for more frequent policy items.
     *
     * @schema ScheduledPolicyItem#RetentionValue
     */
    readonly retentionValue?: number;
}
/**
 * Converts an object of type 'ScheduledPolicyItem' to JSON representation.
 */
export declare function toJson_ScheduledPolicyItem(obj: ScheduledPolicyItem | undefined): Record<string, any> | undefined;
/**
 * Unit of time in which MongoDB Cloud measures snapshot retention. Required when OnDemandPolicyItem is provided.
 *
 * @schema OnDemandPolicyItemRetentionUnit
 */
export declare enum OnDemandPolicyItemRetentionUnit {
    /** days */
    DAYS = "days",
    /** weeks */
    WEEKS = "weeks",
    /** months */
    MONTHS = "months",
    /** years */
    YEARS = "years"
}
/**
 * Unit of time in which MongoDB Cloud measures snapshot retention. Required when the policy item is provided.
 *
 * @schema ScheduledPolicyItemRetentionUnit
 */
export declare enum ScheduledPolicyItemRetentionUnit {
    /** days */
    DAYS = "days",
    /** weeks */
    WEEKS = "weeks",
    /** months */
    MONTHS = "months",
    /** years */
    YEARS = "years"
}
/**
 * A CloudFormation `MongoDB::Atlas::BackupCompliancePolicy`
 *
 * @cloudformationResource MongoDB::Atlas::BackupCompliancePolicy
 * @stability external
 */
export declare class CfnBackupCompliancePolicy extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::BackupCompliancePolicy";
    /**
     * Resource props.
     */
    readonly props: CfnBackupCompliancePolicyProps;
    /**
     * Attribute `MongoDB::Atlas::BackupCompliancePolicy.State`
     */
    readonly attrState: string;
    /**
     * Attribute `MongoDB::Atlas::BackupCompliancePolicy.UpdatedDate`
     */
    readonly attrUpdatedDate: string;
    /**
     * Attribute `MongoDB::Atlas::BackupCompliancePolicy.UpdatedUser`
     */
    readonly attrUpdatedUser: string;
    /**
     * Create a new `MongoDB::Atlas::BackupCompliancePolicy`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnBackupCompliancePolicyProps);
}
