import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Creates one API key for the specified organization. An organization API key grants programmatic access to an organization.
 *
 * @schema CfnApiKeyProps
 */
export interface CfnApiKeyProps {
    /**
     * Purpose or explanation provided when someone created this organization API key.
     *
     * @schema CfnApiKeyProps#Description
     */
    readonly description: string;
    /**
     * Name of the AWS Secrets Manager secret that stores the API key Details.
     *
     * @schema CfnApiKeyProps#AwsSecretName
     */
    readonly awsSecretName: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the organization that contains your projects. Use the /orgs endpoint to retrieve all organizations to which the authenticated user has access.
     *
     * @schema CfnApiKeyProps#OrgId
     */
    readonly orgId: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnApiKeyProps#Profile
     */
    readonly profile?: string;
    /**
     * ARN of the AWS Secrets Manager secret that stores the API key Details
     *
     * @schema CfnApiKeyProps#AwsSecretArn
     */
    readonly awsSecretArn?: string;
    /**
     * List of roles to grant this API key. If you provide this list, provide a minimum of one role and ensure each role applies to this organization.
     *
     * @schema CfnApiKeyProps#Roles
     */
    readonly roles?: string[];
    /**
     * @schema CfnApiKeyProps#ProjectAssignments
     */
    readonly projectAssignments?: ProjectAssignment[];
    /**
     * @schema CfnApiKeyProps#ListOptions
     */
    readonly listOptions?: ListOptions;
}
/**
 * Converts an object of type 'CfnApiKeyProps' to JSON representation.
 */
export declare function toJson_CfnApiKeyProps(obj: CfnApiKeyProps | undefined): Record<string, any> | undefined;
/**
 * @schema ProjectAssignment
 */
export interface ProjectAssignment {
    /**
     * List of roles to grant this API key. If you provide this list, provide a minimum of one role and ensure each role applies to this organization.
     *
     * @schema ProjectAssignment#Roles
     */
    readonly roles?: string[];
    /**
     * Unique 24-hexadecimal digit string that identifies the project in an organization.
     *
     * @schema ProjectAssignment#ProjectId
     */
    readonly projectId?: string;
}
/**
 * Converts an object of type 'ProjectAssignment' to JSON representation.
 */
export declare function toJson_ProjectAssignment(obj: ProjectAssignment | undefined): Record<string, any> | undefined;
/**
 * @schema ListOptions
 */
export interface ListOptions {
    /**
     * Number of the page that displays the current set of the total objects that the response returns.
     *
     * @schema ListOptions#PageNum
     */
    readonly pageNum?: number;
    /**
     * Number of items that the response returns per page.
     *
     * @schema ListOptions#ItemsPerPage
     */
    readonly itemsPerPage?: number;
    /**
     * Flag that indicates whether the response returns the total number of items (totalCount) in the response.
     *
     * @schema ListOptions#IncludeCount
     */
    readonly includeCount?: boolean;
}
/**
 * Converts an object of type 'ListOptions' to JSON representation.
 */
export declare function toJson_ListOptions(obj: ListOptions | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::APIKey`
 *
 * @cloudformationResource MongoDB::Atlas::APIKey
 * @stability external
 */
export declare class CfnApiKey extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::APIKey";
    /**
     * Resource props.
     */
    readonly props: CfnApiKeyProps;
    /**
     * Attribute `MongoDB::Atlas::APIKey.PrivateKey`
     */
    readonly attrPrivateKey: string;
    /**
     * Attribute `MongoDB::Atlas::APIKey.PublicKey`
     */
    readonly attrPublicKey: string;
    /**
     * Attribute `MongoDB::Atlas::APIKey.APIUserId`
     */
    readonly attrAPIUserId: string;
    /**
     * Create a new `MongoDB::Atlas::APIKey`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnApiKeyProps);
}
