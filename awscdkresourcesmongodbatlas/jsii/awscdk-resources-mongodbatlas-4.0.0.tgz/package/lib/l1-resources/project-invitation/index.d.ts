import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, and edits collections of clusters and users in MongoDB Cloud.
 *
 * @schema CfnProjectInvitationProps
 */
export interface CfnProjectInvitationProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnProjectInvitationProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnProjectInvitationProps#ProjectId
     */
    readonly projectId?: string;
    /**
     * Number of documents returned in this response.
     *
     * @schema CfnProjectInvitationProps#TotalCount
     */
    readonly totalCount?: number;
    /**
     * Number of the page that displays the current set of the total objects that the response returns.
     *
     * @schema CfnProjectInvitationProps#PageNum
     */
    readonly pageNum?: number;
    /**
     * Unique 24-hexadecimal digit string that identifies the invitation.
     *
     * @schema CfnProjectInvitationProps#InvitationId
     */
    readonly invitationId?: string;
    /**
     * One or more organization or project level roles to assign to the MongoDB Cloud user.
     *
     * @schema CfnProjectInvitationProps#Roles
     */
    readonly roles?: CfnProjectInvitationPropsRoles[];
    /**
     * Email address of the user account invited to this project.
     *
     * @schema CfnProjectInvitationProps#Username
     */
    readonly username?: string;
}
/**
 * Converts an object of type 'CfnProjectInvitationProps' to JSON representation.
 */
export declare function toJson_CfnProjectInvitationProps(obj: CfnProjectInvitationProps | undefined): Record<string, any> | undefined;
/**
 * @schema CfnProjectInvitationPropsRoles
 */
export declare enum CfnProjectInvitationPropsRoles {
    /** GROUP_CLUSTER_MANAGER */
    GROUP_CLUSTER_MANAGER = "GROUP_CLUSTER_MANAGER",
    /** GROUP_DATA_ACCESS_ADMIN */
    GROUP_DATA_ACCESS_ADMIN = "GROUP_DATA_ACCESS_ADMIN",
    /** GROUP_DATA_ACCESS_READ_ONLY */
    GROUP_DATA_ACCESS_READ_ONLY = "GROUP_DATA_ACCESS_READ_ONLY",
    /** GROUP_DATA_ACCESS_READ_WRITE */
    GROUP_DATA_ACCESS_READ_WRITE = "GROUP_DATA_ACCESS_READ_WRITE",
    /** GROUP_OWNER */
    GROUP_OWNER = "GROUP_OWNER",
    /** GROUP_READ_ONLY */
    GROUP_READ_ONLY = "GROUP_READ_ONLY"
}
/**
 * A CloudFormation `MongoDB::Atlas::ProjectInvitation`
 *
 * @cloudformationResource MongoDB::Atlas::ProjectInvitation
 * @stability external
 */
export declare class CfnProjectInvitation extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ProjectInvitation";
    /**
     * Resource props.
     */
    readonly props: CfnProjectInvitationProps;
    /**
     * Attribute `MongoDB::Atlas::ProjectInvitation.ExpiresAt`
     */
    readonly attrExpiresAt: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectInvitation.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectInvitation.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Attribute `MongoDB::Atlas::ProjectInvitation.InviterUsername`
     */
    readonly attrInviterUsername: string;
    /**
     * Create a new `MongoDB::Atlas::ProjectInvitation`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnProjectInvitationProps);
}
