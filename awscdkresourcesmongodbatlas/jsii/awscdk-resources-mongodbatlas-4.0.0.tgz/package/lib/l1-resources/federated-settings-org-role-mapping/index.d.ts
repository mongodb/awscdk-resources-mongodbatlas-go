import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, edits, and removes federation-related features such as role mappings and connected organization configurations.
 *
 * @schema CfnFederatedSettingsOrgRoleMappingProps
 */
export interface CfnFederatedSettingsOrgRoleMappingProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnFederatedSettingsOrgRoleMappingProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique human-readable label that identifies the identity provider group to whichthis role mapping applies.
     *
     * @schema CfnFederatedSettingsOrgRoleMappingProps#ExternalGroupName
     */
    readonly externalGroupName: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your federation.
     *
     * @schema CfnFederatedSettingsOrgRoleMappingProps#FederationSettingsId
     */
    readonly federationSettingsId: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the organization that contains your projects.
     *
     * @schema CfnFederatedSettingsOrgRoleMappingProps#OrgId
     */
    readonly orgId: string;
    /**
     * Atlas roles and the unique identifiers of the groups and organizations associated with each role.
     *
     * @schema CfnFederatedSettingsOrgRoleMappingProps#RoleAssignments
     */
    readonly roleAssignments?: RoleAssignment[];
}
/**
 * Converts an object of type 'CfnFederatedSettingsOrgRoleMappingProps' to JSON representation.
 */
export declare function toJson_CfnFederatedSettingsOrgRoleMappingProps(obj: CfnFederatedSettingsOrgRoleMappingProps | undefined): Record<string, any> | undefined;
/**
 * @schema RoleAssignment
 */
export interface RoleAssignment {
    /**
     * List that contains comma-separated key value pairs to map zones to geographic regions. These pairs map an ISO 3166-1a2 location code, with an ISO 3166-2 subdivision code when possible, to a unique 24-hexadecimal string that identifies the custom zone.
     *
     * This parameter returns an empty object if no custom zones exist.
     *
     * @schema RoleAssignment#ProjectId
     */
    readonly projectId?: string;
    /**
     * List that contains comma-separated key value pairs to map zones to geographic regions. These pairs map an ISO 3166-1a2 location code, with an ISO 3166-2 subdivision code when possible, to a unique 24-hexadecimal string that identifies the custom zone.
     *
     * This parameter returns an empty object if no custom zones exist.
     *
     * @schema RoleAssignment#OrgId
     */
    readonly orgId?: string;
    /**
     * @schema RoleAssignment#Role
     */
    readonly role?: string;
}
/**
 * Converts an object of type 'RoleAssignment' to JSON representation.
 */
export declare function toJson_RoleAssignment(obj: RoleAssignment | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::FederatedSettingsOrgRoleMapping`
 *
 * @cloudformationResource MongoDB::Atlas::FederatedSettingsOrgRoleMapping
 * @stability external
 */
export declare class CfnFederatedSettingsOrgRoleMapping extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::FederatedSettingsOrgRoleMapping";
    /**
     * Resource props.
     */
    readonly props: CfnFederatedSettingsOrgRoleMappingProps;
    /**
     * Attribute `MongoDB::Atlas::FederatedSettingsOrgRoleMapping.Id`
     */
    readonly attrId: string;
    /**
     * Create a new `MongoDB::Atlas::FederatedSettingsOrgRoleMapping`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnFederatedSettingsOrgRoleMappingProps);
}
