import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Creates one private endpoint for the specified cloud service provider. At this current version only AWS is supported
 *
 * @schema CfnPrivateEndpointAwsProps
 */
export interface CfnPrivateEndpointAwsProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml)
     *
     * @schema CfnPrivateEndpointAwsProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnPrivateEndpointAwsProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the private endpoint service for which you want to create a private endpoint.
     *
     * @schema CfnPrivateEndpointAwsProps#EndpointServiceId
     */
    readonly endpointServiceId: string;
    /**
     * Unique string that identifies the private endpoint. for AWS is the VPC endpoint ID, example: vpce-xxxxxxxx
     *
     * @schema CfnPrivateEndpointAwsProps#Id
     */
    readonly id: string;
    /**
     * If this proper is set to TRUE, the cloud formation resource will return success Only if the private connection is Succeeded
     *
     * @schema CfnPrivateEndpointAwsProps#EnforceConnectionSuccess
     */
    readonly enforceConnectionSuccess?: boolean;
}
/**
 * Converts an object of type 'CfnPrivateEndpointAwsProps' to JSON representation.
 */
export declare function toJson_CfnPrivateEndpointAwsProps(obj: CfnPrivateEndpointAwsProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::PrivateEndpointAWS`
 *
 * @cloudformationResource MongoDB::Atlas::PrivateEndpointAWS
 * @stability external
 */
export declare class CfnPrivateEndpointAws extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::PrivateEndpointAWS";
    /**
     * Resource props.
     */
    readonly props: CfnPrivateEndpointAwsProps;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointAWS.InterfaceEndpointId`
     */
    readonly attrInterfaceEndpointId: string;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointAWS.DeleteRequested`
     */
    readonly attrDeleteRequested: cdk.IResolvable;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointAWS.ConnectionStatus`
     */
    readonly attrConnectionStatus: string;
    /**
     * Attribute `MongoDB::Atlas::PrivateEndpointAWS.ErrorMessage`
     */
    readonly attrErrorMessage: string;
    /**
     * Create a new `MongoDB::Atlas::PrivateEndpointAWS`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnPrivateEndpointAwsProps);
}
