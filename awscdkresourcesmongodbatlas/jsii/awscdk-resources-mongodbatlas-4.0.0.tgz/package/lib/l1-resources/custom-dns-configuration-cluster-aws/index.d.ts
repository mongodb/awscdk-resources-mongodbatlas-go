import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * An example resource schema demonstrating some basic constructs and validation rules.
 *
 * @schema CfnCustomDnsConfigurationClusterAwsProps
 */
export interface CfnCustomDnsConfigurationClusterAwsProps {
    /**
     * Flag that indicates whether the project's clusters deployed to Amazon Web Services (AWS) use a custom Domain Name System (DNS)
     *
     * @schema CfnCustomDnsConfigurationClusterAwsProps#Enabled
     */
    readonly enabled?: boolean;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnCustomDnsConfigurationClusterAwsProps#ProjectId
     */
    readonly projectId: string;
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnCustomDnsConfigurationClusterAwsProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnCustomDnsConfigurationClusterAwsProps' to JSON representation.
 */
export declare function toJson_CfnCustomDnsConfigurationClusterAwsProps(obj: CfnCustomDnsConfigurationClusterAwsProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::CustomDnsConfigurationClusterAws`
 *
 * @cloudformationResource MongoDB::Atlas::CustomDnsConfigurationClusterAws
 * @stability external
 */
export declare class CfnCustomDnsConfigurationClusterAws extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::CustomDnsConfigurationClusterAws";
    /**
     * Resource props.
     */
    readonly props: CfnCustomDnsConfigurationClusterAwsProps;
    /**
     * Create a new `MongoDB::Atlas::CustomDnsConfigurationClusterAws`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnCustomDnsConfigurationClusterAwsProps);
}
