import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, updates, and removes Atlas Stream Processing Workspaces. The DataProcessRegion.Region property can be updated after creation. Other properties (WorkspaceName, ProjectId, Profile, StreamConfig, DataProcessRegion.CloudProvider) are create-only and require resource replacement to change.
 *
 * @schema CfnStreamWorkspaceProps
 */
export interface CfnStreamWorkspaceProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnStreamWorkspaceProps#Profile
     */
    readonly profile?: string;
    /**
     * Human-readable label that identifies the stream workspace.
     *
     * @schema CfnStreamWorkspaceProps#WorkspaceName
     */
    readonly workspaceName: string;
    /**
     * @schema CfnStreamWorkspaceProps#DataProcessRegion
     */
    readonly dataProcessRegion: StreamsDataProcessRegion;
    /**
     * @schema CfnStreamWorkspaceProps#StreamConfig
     */
    readonly streamConfig?: StreamConfig;
    /**
     * Unique 24-hexadecimal character string that identifies the project.
     *
     * @schema CfnStreamWorkspaceProps#ProjectId
     */
    readonly projectId: string;
}
/**
 * Converts an object of type 'CfnStreamWorkspaceProps' to JSON representation.
 */
export declare function toJson_CfnStreamWorkspaceProps(obj: CfnStreamWorkspaceProps | undefined): Record<string, any> | undefined;
/**
 * Information about the cloud provider region in which MongoDB Cloud processes the stream.
 *
 * @schema StreamsDataProcessRegion
 */
export interface StreamsDataProcessRegion {
    /**
     * Label that identifies the cloud service provider where MongoDB Cloud performs stream processing. For CloudFormation, this is restricted to AWS only.
     *
     * @schema StreamsDataProcessRegion#CloudProvider
     */
    readonly cloudProvider: StreamsDataProcessRegionCloudProvider;
    /**
     * @schema StreamsDataProcessRegion#Region
     */
    readonly region: string;
}
/**
 * Converts an object of type 'StreamsDataProcessRegion' to JSON representation.
 */
export declare function toJson_StreamsDataProcessRegion(obj: StreamsDataProcessRegion | undefined): Record<string, any> | undefined;
/**
 * Configuration options for an Atlas Stream Processing Workspace.
 *
 * @schema StreamConfig
 */
export interface StreamConfig {
    /**
     * Selected tier for the Stream Workspace. Configures Memory / VCPU allowances. Valid values: SP2, SP5, SP10, SP30, SP50.
     *
     * @schema StreamConfig#Tier
     */
    readonly tier: string;
    /**
     * Max tier size for the Stream Workspace. Configures Memory / VCPU allowances. Valid values: SP2, SP5, SP10, SP30, SP50.
     *
     * @schema StreamConfig#MaxTierSize
     */
    readonly maxTierSize?: string;
}
/**
 * Converts an object of type 'StreamConfig' to JSON representation.
 */
export declare function toJson_StreamConfig(obj: StreamConfig | undefined): Record<string, any> | undefined;
/**
 * Label that identifies the cloud service provider where MongoDB Cloud performs stream processing. For CloudFormation, this is restricted to AWS only.
 *
 * @schema StreamsDataProcessRegionCloudProvider
 */
export declare enum StreamsDataProcessRegionCloudProvider {
    /** AWS */
    AWS = "AWS"
}
/**
 * A CloudFormation `MongoDB::Atlas::StreamWorkspace`
 *
 * @cloudformationResource MongoDB::Atlas::StreamWorkspace
 * @stability external
 */
export declare class CfnStreamWorkspace extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::StreamWorkspace";
    /**
     * Resource props.
     */
    readonly props: CfnStreamWorkspaceProps;
    /**
     * Attribute `MongoDB::Atlas::StreamWorkspace.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::StreamWorkspace.Hostnames`
     */
    readonly attrHostnames: string[];
    /**
     * Create a new `MongoDB::Atlas::StreamWorkspace`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnStreamWorkspaceProps);
}
