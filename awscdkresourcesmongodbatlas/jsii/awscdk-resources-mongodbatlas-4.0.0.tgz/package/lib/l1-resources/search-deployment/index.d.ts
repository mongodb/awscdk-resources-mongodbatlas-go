import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * The resource lets you create, edit and delete dedicated search nodes in a cluster. For details on supported cloud providers and existing limitations you can visit the Search Node Documentation: https://www.mongodb.com/docs/atlas/cluster-config/multi-cloud-distribution/#search-nodes-for-workload-isolation. Only a single search deployment resource can be defined for each cluster.
 *
 * @schema CfnSearchDeploymentProps
 */
export interface CfnSearchDeploymentProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnSearchDeploymentProps#Profile
     */
    readonly profile?: string;
    /**
     * Label that identifies the cluster to return the search nodes for.
     *
     * @schema CfnSearchDeploymentProps#ClusterName
     */
    readonly clusterName: string;
    /**
     * Unique 24-hexadecimal character string that identifies the project.
     *
     * @schema CfnSearchDeploymentProps#ProjectId
     */
    readonly projectId: string;
    /**
     * List of settings that configure the search nodes for your cluster. This list is currently limited to defining a single element.
     *
     * @schema CfnSearchDeploymentProps#Specs
     */
    readonly specs: ApiSearchDeploymentSpec[];
}
/**
 * Converts an object of type 'CfnSearchDeploymentProps' to JSON representation.
 */
export declare function toJson_CfnSearchDeploymentProps(obj: CfnSearchDeploymentProps | undefined): Record<string, any> | undefined;
/**
 * @schema ApiSearchDeploymentSpec
 */
export interface ApiSearchDeploymentSpec {
    /**
     * Hardware specification for the search node instance sizes. The [MongoDB Atlas API](https://www.mongodb.com/docs/atlas/reference/api-resources-spec/#tag/Atlas-Search/operation/createAtlasSearchDeployment) describes the valid values. More details can also be found in the [Search Node Documentation](https://www.mongodb.com/docs/atlas/cluster-config/multi-cloud-distribution/#search-tier).
     *
     * @schema ApiSearchDeploymentSpec#InstanceSize
     */
    readonly instanceSize: string;
    /**
     * Number of search nodes in the cluster.
     *
     * @schema ApiSearchDeploymentSpec#NodeCount
     */
    readonly nodeCount: number;
}
/**
 * Converts an object of type 'ApiSearchDeploymentSpec' to JSON representation.
 */
export declare function toJson_ApiSearchDeploymentSpec(obj: ApiSearchDeploymentSpec | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::SearchDeployment`
 *
 * @cloudformationResource MongoDB::Atlas::SearchDeployment
 * @stability external
 */
export declare class CfnSearchDeployment extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::SearchDeployment";
    /**
     * Resource props.
     */
    readonly props: CfnSearchDeploymentProps;
    /**
     * Attribute `MongoDB::Atlas::SearchDeployment.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::SearchDeployment.StateName`
     */
    readonly attrStateName: string;
    /**
     * Attribute `MongoDB::Atlas::SearchDeployment.EncryptionAtRestProvider`
     */
    readonly attrEncryptionAtRestProvider: string;
    /**
     * Create a new `MongoDB::Atlas::SearchDeployment`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnSearchDeploymentProps);
}
