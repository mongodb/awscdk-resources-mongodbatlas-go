import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Adds one team to the specified project. All members of the team share the same project access. To use this resource, the requesting API Key must have the Project User Admin role. This resource doesn't require the API Key to have an Access List.
 *
 * @schema CfnTeamsProps
 */
export interface CfnTeamsProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnTeamsProps#Profile
     */
    readonly profile?: string;
    /**
     * One or more organization- or project-level roles to assign to the MongoDB Cloud user.
     *
     * @schema CfnTeamsProps#RoleNames
     */
    readonly roleNames?: CfnTeamsPropsRoleNames[];
    /**
     * Unique 24-hexadecimal character string that identifies the organization.
     *
     * @schema CfnTeamsProps#OrgId
     */
    readonly orgId?: string;
    /**
     * Unique 24-hexadecimal character string that identifies the project.
     *
     * @schema CfnTeamsProps#ProjectId
     */
    readonly projectId?: string;
    /**
     * Human-readable label that identifies the team.
     *
     * @schema CfnTeamsProps#Name
     */
    readonly name?: string;
    /**
     * List that contains the MongoDB Cloud users in this team.
     *
     * @schema CfnTeamsProps#Usernames
     */
    readonly usernames?: string[];
    /**
     * List of returned documents that MongoDB Cloud provides when completing this request.
     *
     * @schema CfnTeamsProps#Users
     */
    readonly users?: AtlasUser[];
}
/**
 * Converts an object of type 'CfnTeamsProps' to JSON representation.
 */
export declare function toJson_CfnTeamsProps(obj: CfnTeamsProps | undefined): Record<string, any> | undefined;
/**
 * @schema CfnTeamsPropsRoleNames
 */
export declare enum CfnTeamsPropsRoleNames {
    /** GROUP_CLUSTER_MANAGER */
    GROUP_CLUSTER_MANAGER = "GROUP_CLUSTER_MANAGER",
    /** GROUP_DATA_ACCESS_ADMIN */
    GROUP_DATA_ACCESS_ADMIN = "GROUP_DATA_ACCESS_ADMIN",
    /** GROUP_DATA_ACCESS_READ_ONLY */
    GROUP_DATA_ACCESS_READ_ONLY = "GROUP_DATA_ACCESS_READ_ONLY",
    /** GROUP_DATA_ACCESS_READ_WRITE */
    GROUP_DATA_ACCESS_READ_WRITE = "GROUP_DATA_ACCESS_READ_WRITE",
    /** GROUP_OWNER */
    GROUP_OWNER = "GROUP_OWNER",
    /** GROUP_READ_ONLY */
    GROUP_READ_ONLY = "GROUP_READ_ONLY"
}
/**
 * @schema AtlasUser
 */
export interface AtlasUser {
    /**
     * Two alphabet characters that identifies MongoDB Cloud user's geographic location. This parameter uses the ISO 3166-1a2 code format.
     *
     * @schema AtlasUser#Country
     */
    readonly country?: string;
    /**
     * Email address that belongs to the MongoDB Cloud user.
     *
     * @schema AtlasUser#EmailAddress
     */
    readonly emailAddress?: string;
    /**
     * First or given name that belongs to the MongoDB Cloud user.
     *
     * @schema AtlasUser#FirstName
     */
    readonly firstName?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the MongoDB Cloud user.
     *
     * @schema AtlasUser#Id
     */
    readonly id?: string;
    /**
     * Last name, family name, or surname that belongs to the MongoDB Cloud user.
     *
     * @schema AtlasUser#LastName
     */
    readonly lastName?: string;
    /**
     * List of one or more Uniform Resource Locators (URLs) that point to API sub-resources, related API resources, or both. RFC 5988 outlines these relationships.
     *
     * @schema AtlasUser#Links
     */
    readonly links?: Link[];
    /**
     * Mobile phone number that belongs to the MongoDB Cloud user.
     *
     * @schema AtlasUser#MobileNumber
     */
    readonly mobileNumber?: string;
    /**
     * Password applied with the username to log in to MongoDB Cloud. MongoDB Cloud does not return this parameter except in response to creating a new MongoDB Cloud user. Only the MongoDB Cloud user can update their password after it has been set from the MongoDB Cloud console.
     *
     * @schema AtlasUser#Password
     */
    readonly password?: string;
    /**
     * List of objects that display the MongoDB Cloud user's roles and the corresponding organization or project to which that role applies. A role can apply to one organization or one project but not both.
     *
     * @schema AtlasUser#Roles
     */
    readonly roles?: AtlasRole[];
    /**
     * List of unique 24-hexadecimal digit strings that identifies the teams to which this MongoDB Cloud user belongs.
     *
     * @schema AtlasUser#TeamIds
     */
    readonly teamIds?: string[];
    /**
     * Email address that represents the username of the MongoDB Cloud user.
     *
     * @schema AtlasUser#Username
     */
    readonly username?: string;
}
/**
 * Converts an object of type 'AtlasUser' to JSON representation.
 */
export declare function toJson_AtlasUser(obj: AtlasUser | undefined): Record<string, any> | undefined;
/**
 * One or more links to sub-resources and/or related resources.
 *
 * @schema Link
 */
export interface Link {
    /**
     * @schema Link#Rel
     */
    readonly rel?: string;
    /**
     * @schema Link#Href
     */
    readonly href?: string;
}
/**
 * Converts an object of type 'Link' to JSON representation.
 */
export declare function toJson_Link(obj: Link | undefined): Record<string, any> | undefined;
/**
 * @schema AtlasRole
 */
export interface AtlasRole {
    /**
     * Unique 24-hexadecimal digit string that identifies the project to which this role belongs. You can set a value for this parameter or **orgId** but not both in the same request.
     *
     * @schema AtlasRole#ProjectId
     */
    readonly projectId?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the organization to which this role belongs. You can set a value for this parameter or **groupId** but not both in the same request
     *
     * @schema AtlasRole#OrgId
     */
    readonly orgId?: string;
    /**
     * Human-readable label that identifies the collection of privileges that MongoDB Cloud grants a specific API key, MongoDB Cloud user, or MongoDB Cloud team. These roles include organization- and project-level roles.
     *
     * Organization Roles
     *
     * * ORG_OWNER
     * * ORG_MEMBER
     * * ORG_GROUP_CREATOR
     * * ORG_BILLING_ADMIN
     * * ORG_READ_ONLY
     *
     * Project Roles
     *
     * * GROUP_CLUSTER_MANAGER
     * * GROUP_DATA_ACCESS_ADMIN
     * * GROUP_DATA_ACCESS_READ_ONLY
     * * GROUP_DATA_ACCESS_READ_WRITE
     * * GROUP_OWNER
     * * GROUP_READ_ONLY
     *
     *
     *
     * @schema AtlasRole#RoleName
     */
    readonly roleName?: AtlasRoleRoleName;
}
/**
 * Converts an object of type 'AtlasRole' to JSON representation.
 */
export declare function toJson_AtlasRole(obj: AtlasRole | undefined): Record<string, any> | undefined;
/**
 * Human-readable label that identifies the collection of privileges that MongoDB Cloud grants a specific API key, MongoDB Cloud user, or MongoDB Cloud team. These roles include organization- and project-level roles.
 *
 * Organization Roles
 *
 * * ORG_OWNER
 * * ORG_MEMBER
 * * ORG_GROUP_CREATOR
 * * ORG_BILLING_ADMIN
 * * ORG_READ_ONLY
 *
 * Project Roles
 *
 * * GROUP_CLUSTER_MANAGER
 * * GROUP_DATA_ACCESS_ADMIN
 * * GROUP_DATA_ACCESS_READ_ONLY
 * * GROUP_DATA_ACCESS_READ_WRITE
 * * GROUP_OWNER
 * * GROUP_READ_ONLY
 *
 *
 *
 * @schema AtlasRoleRoleName
 */
export declare enum AtlasRoleRoleName {
    /** ORG_OWNER */
    ORG_OWNER = "ORG_OWNER",
    /** ORG_MEMBER */
    ORG_MEMBER = "ORG_MEMBER",
    /** ORG_GROUP_CREATOR */
    ORG_GROUP_CREATOR = "ORG_GROUP_CREATOR",
    /** ORG_BILLING_ADMIN */
    ORG_BILLING_ADMIN = "ORG_BILLING_ADMIN",
    /** ORG_READ_ONLY */
    ORG_READ_ONLY = "ORG_READ_ONLY",
    /** GROUP_CLUSTER_MANAGER */
    GROUP_CLUSTER_MANAGER = "GROUP_CLUSTER_MANAGER",
    /** GROUP_DATA_ACCESS_ADMIN */
    GROUP_DATA_ACCESS_ADMIN = "GROUP_DATA_ACCESS_ADMIN",
    /** GROUP_DATA_ACCESS_READ_ONLY */
    GROUP_DATA_ACCESS_READ_ONLY = "GROUP_DATA_ACCESS_READ_ONLY",
    /** GROUP_DATA_ACCESS_READ_WRITE */
    GROUP_DATA_ACCESS_READ_WRITE = "GROUP_DATA_ACCESS_READ_WRITE",
    /** GROUP_OWNER */
    GROUP_OWNER = "GROUP_OWNER",
    /** GROUP_READ_ONLY */
    GROUP_READ_ONLY = "GROUP_READ_ONLY"
}
/**
 * A CloudFormation `MongoDB::Atlas::Teams`
 *
 * @cloudformationResource MongoDB::Atlas::Teams
 * @stability external
 */
export declare class CfnTeams extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::Teams";
    /**
     * Resource props.
     */
    readonly props: CfnTeamsProps;
    /**
     * Attribute `MongoDB::Atlas::Teams.TeamId`
     */
    readonly attrTeamId: string;
    /**
     * Create a new `MongoDB::Atlas::Teams`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnTeamsProps);
}
