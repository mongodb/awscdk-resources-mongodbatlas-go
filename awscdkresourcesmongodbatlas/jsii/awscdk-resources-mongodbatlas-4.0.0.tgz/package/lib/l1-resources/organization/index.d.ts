import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, and edits organizational units in MongoDB Cloud.
 *
 * @schema CfnOrganizationProps
 */
export interface CfnOrganizationProps {
    /**
     * Human-readable label that identifies the organization.
     *
     * @schema CfnOrganizationProps#Name
     */
    readonly name: string;
    /**
     * @schema CfnOrganizationProps#APIKey
     */
    readonly apiKey?: ApiKey;
    /**
     * Unique 24-hexadecimal digit string that identifies the federation to link the newly created organization to. If specified, the proposed Organization Owner of the new organization must have the Organization Owner role in an organization associated with the federation.
     *
     * @schema CfnOrganizationProps#FederatedSettingsId
     */
    readonly federatedSettingsId?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the MongoDB Cloud user that you want to assign the Organization Owner role. This user must be a member of the same organization as the calling API key. If you provide federationSettingsId, this user must instead have the Organization Owner role on an organization in the specified federation. This parameter is required only when you authenticate with Programmatic API Keys.
     *
     * @schema CfnOrganizationProps#OrgOwnerId
     */
    readonly orgOwnerId: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnOrganizationProps#Profile
     */
    readonly profile?: string;
    /**
     * AwsSecretName used to set newly created Org credentials information.
     *
     * @schema CfnOrganizationProps#AwsSecretName
     */
    readonly awsSecretName: string;
    /**
     * Disables automatic alert creation. When set to `true`, Atlas doesn't automatically create organization-level alerts. Defaults to `true` for new Atlas Organizations created with the provider to prevent infrastructure drift caused by creation of new alerts.
     *
     * @default true` for new Atlas Organizations created with the provider to prevent infrastructure drift caused by creation of new alerts.
     * @schema CfnOrganizationProps#SkipDefaultAlertsSettings
     */
    readonly skipDefaultAlertsSettings?: boolean;
    /**
     * Flag that indicates whether this organization has access to generative AI features. This setting only applies to Atlas Commercial and defaults to `true`. With this setting on, Project Owners may be able to enable or disable individual AI features at the project level. To learn more, see https://www.mongodb.com/docs/generative-ai-faq/
     *
     * @schema CfnOrganizationProps#GenAIFeaturesEnabled
     */
    readonly genAiFeaturesEnabled?: boolean;
    /**
     * Flag that indicates whether this organization has been deleted.
     *
     * @schema CfnOrganizationProps#IsDeleted
     */
    readonly isDeleted?: boolean;
    /**
     * Flag that indicates whether to require API operations to originate from an IP Address added to the API access list for the specified organization.
     *
     * @schema CfnOrganizationProps#ApiAccessListRequired
     */
    readonly apiAccessListRequired?: boolean;
    /**
     * Flag that indicates whether to require users to set up Multi-Factor Authentication (MFA) before accessing the specified organization. To learn more, see: https://www.mongodb.com/docs/atlas/security-multi-factor-authentication/.
     *
     * @schema CfnOrganizationProps#MultiFactorAuthRequired
     */
    readonly multiFactorAuthRequired?: boolean;
    /**
     * Flag that indicates whether to block MongoDB Support from accessing Atlas infrastructure for any deployment in the specified organization without explicit permission. Once this setting is turned on, you can grant MongoDB Support a 24-hour bypass access to the Atlas deployment to resolve support issues. To learn more, see: https://www.mongodb.com/docs/atlas/security-restrict-support-access/.
     *
     * @schema CfnOrganizationProps#RestrictEmployeeAccess
     */
    readonly restrictEmployeeAccess?: boolean;
    /**
     * Email address of the security contact for the organization.
     *
     * @schema CfnOrganizationProps#SecurityContact
     */
    readonly securityContact?: string;
}
/**
 * Converts an object of type 'CfnOrganizationProps' to JSON representation.
 */
export declare function toJson_CfnOrganizationProps(obj: CfnOrganizationProps | undefined): Record<string, any> | undefined;
/**
 * @schema APIKey
 */
export interface ApiKey {
    /**
     * Purpose or explanation provided when someone created this organization API key. 1 to 250 characters
     *
     * @schema APIKey#Description
     */
    readonly description?: string;
    /**
     * List of roles to grant this API key. If you provide this list, provide a minimum of one role and ensure each role applies to this organization.
     *
     * @schema APIKey#Roles
     */
    readonly roles?: string[];
}
/**
 * Converts an object of type 'ApiKey' to JSON representation.
 */
export declare function toJson_ApiKey(obj: ApiKey | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::Organization`
 *
 * @cloudformationResource MongoDB::Atlas::Organization
 * @stability external
 */
export declare class CfnOrganization extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::Organization";
    /**
     * Resource props.
     */
    readonly props: CfnOrganizationProps;
    /**
     * Attribute `MongoDB::Atlas::Organization.OrgId`
     */
    readonly attrOrgId: string;
    /**
     * Create a new `MongoDB::Atlas::Organization`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnOrganizationProps);
}
