import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, edits, verifies, and removes LDAP configurations.
 *
 * @schema CfnLdapConfigurationProps
 */
export interface CfnLdapConfigurationProps {
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnLdapConfigurationProps#Profile
     */
    readonly profile?: string;
    /**
     * Full Distinguished Name (DN) of the Lightweight Directory Access Protocol (LDAP) user that MongoDB Cloud uses to connect to the LDAP host. LDAP distinguished names must be formatted according to RFC 2253.
     *
     * @schema CfnLdapConfigurationProps#BindUsername
     */
    readonly bindUsername: string;
    /**
     * The current status of the LDAP over TLS/SSL configuration.
     *
     * @schema CfnLdapConfigurationProps#Status
     */
    readonly status?: string;
    /**
     * Human-readable label that identifies the hostname or Internet Protocol (IP) address of the Lightweight Directory Access Protocol (LDAP) host. This host must have access to the internet or have a Virtual Private Cloud (VPC) peering connection to your cluster.
     *
     * @schema CfnLdapConfigurationProps#Hostname
     */
    readonly hostname: string;
    /**
     * Flag that indicates whether users can authenticate using an Lightweight Directory Access Protocol (LDAP) host.
     *
     * @schema CfnLdapConfigurationProps#AuthenticationEnabled
     */
    readonly authenticationEnabled?: boolean;
    /**
     * Flag that indicates whether users can authorize access to MongoDB Cloud resources using an Lightweight Directory Access Protocol (LDAP) host.
     *
     * @schema CfnLdapConfigurationProps#AuthorizationEnabled
     */
    readonly authorizationEnabled?: boolean;
    /**
     * Certificate Authority (CA) certificate that MongoDB Cloud uses to verify the identity of the Lightweight Directory Access Protocol (LDAP) host. MongoDB Cloud allows self-signed certificates. To delete an assigned value, pass an empty string: `"caCertificate": ""`
     *
     * @schema CfnLdapConfigurationProps#CaCertificate
     */
    readonly caCertificate?: string;
    /**
     * Lightweight Directory Access Protocol (LDAP) query template that MongoDB Cloud runs to obtain the LDAP groups associated with the authenticated user. MongoDB Cloud uses this parameter only for user authorization. Use the `{USER}` placeholder in the Uniform Resource Locator (URL) to substitute the authenticated username. The query relates to the host specified with the hostname. Format this query according to [RFC 4515](https://tools.ietf.org/search/rfc4515) and [RFC 4516](https://datatracker.ietf.org/doc/html/rfc4516).
     *
     * @schema CfnLdapConfigurationProps#AuthzQueryTemplate
     */
    readonly authzQueryTemplate?: string;
    /**
     * Password that MongoDB Cloud uses to authenticate the **bindUsername**.
     *
     * @schema CfnLdapConfigurationProps#BindPassword
     */
    readonly bindPassword: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnLdapConfigurationProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Port to which the Lightweight Directory Access Protocol (LDAP) host listens for client connections.
     *
     * @schema CfnLdapConfigurationProps#Port
     */
    readonly port: number;
    /**
     * User-to-Distinguished Name (DN) map that MongoDB Cloud uses to transform a Lightweight Directory Access Protocol (LDAP) username into an LDAP DN.
     *
     * @schema CfnLdapConfigurationProps#UserToDNMapping
     */
    readonly userToDnMapping?: ApiAtlasNdsUserToDnMappingView[];
}
/**
 * Converts an object of type 'CfnLdapConfigurationProps' to JSON representation.
 */
export declare function toJson_CfnLdapConfigurationProps(obj: CfnLdapConfigurationProps | undefined): Record<string, any> | undefined;
/**
 * @schema ApiAtlasNDSUserToDNMappingView
 */
export interface ApiAtlasNdsUserToDnMappingView {
    /**
     * Lightweight Directory Access Protocol (LDAP) query template that inserts the LDAP name that the regular expression matches into an LDAP query Uniform Resource Identifier (URI). The formatting for the query must conform to [RFC 4515](https://datatracker.ietf.org/doc/html/rfc4515) and [RFC 4516](https://datatracker.ietf.org/doc/html/rfc4516).
     *
     * @schema ApiAtlasNDSUserToDNMappingView#LdapQuery
     */
    readonly ldapQuery?: string;
    /**
     * Regular expression that MongoDB Cloud uses to match against the provided Lightweight Directory Access Protocol (LDAP) username. Each parenthesis-enclosed section represents a regular expression capture group that the substitution or `ldapQuery` template uses.
     *
     * @schema ApiAtlasNDSUserToDNMappingView#Match
     */
    readonly match?: string;
    /**
     * Lightweight Directory Access Protocol (LDAP) Distinguished Name (DN) template that converts the LDAP username that matches regular expression in the *match* parameter into an LDAP Distinguished Name (DN).
     *
     * @schema ApiAtlasNDSUserToDNMappingView#Substitution
     */
    readonly substitution?: string;
}
/**
 * Converts an object of type 'ApiAtlasNdsUserToDnMappingView' to JSON representation.
 */
export declare function toJson_ApiAtlasNdsUserToDnMappingView(obj: ApiAtlasNdsUserToDnMappingView | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::LDAPConfiguration`
 *
 * @cloudformationResource MongoDB::Atlas::LDAPConfiguration
 * @stability external
 */
export declare class CfnLdapConfiguration extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::LDAPConfiguration";
    /**
     * Resource props.
     */
    readonly props: CfnLdapConfigurationProps;
    /**
     * Create a new `MongoDB::Atlas::LDAPConfiguration`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnLdapConfigurationProps);
}
