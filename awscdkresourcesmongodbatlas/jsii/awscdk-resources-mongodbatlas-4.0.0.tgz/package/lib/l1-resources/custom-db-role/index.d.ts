import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, edits, and removes custom database user privilege roles.
 *
 * @schema CfnCustomDbRoleProps
 */
export interface CfnCustomDbRoleProps {
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnCustomDbRoleProps#ProjectId
     */
    readonly projectId: string;
    /**
     * List of the individual privilege actions that the role grants.
     *
     * @schema CfnCustomDbRoleProps#Actions
     */
    readonly actions?: Action[];
    /**
     * List of the built-in roles that this custom role inherits.
     *
     * @schema CfnCustomDbRoleProps#InheritedRoles
     */
    readonly inheritedRoles?: InheritedRole[];
    /**
     * Human-readable label that identifies the role for the request. This name must be unique for this custom role in this project.
     *
     * @schema CfnCustomDbRoleProps#RoleName
     */
    readonly roleName: string;
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnCustomDbRoleProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnCustomDbRoleProps' to JSON representation.
 */
export declare function toJson_CfnCustomDbRoleProps(obj: CfnCustomDbRoleProps | undefined): Record<string, any> | undefined;
/**
 * @schema Action
 */
export interface Action {
    /**
     * Human-readable label that identifies the privilege action.
     *
     * @schema Action#Action
     */
    readonly action?: string;
    /**
     * List of resources on which you grant the action.
     *
     * @schema Action#Resources
     */
    readonly resources?: Resource[];
}
/**
 * Converts an object of type 'Action' to JSON representation.
 */
export declare function toJson_Action(obj: Action | undefined): Record<string, any> | undefined;
/**
 * @schema InheritedRole
 */
export interface InheritedRole {
    /**
     * @schema InheritedRole#Db
     */
    readonly db?: string;
    /**
     * @schema InheritedRole#Role
     */
    readonly role?: string;
}
/**
 * Converts an object of type 'InheritedRole' to JSON representation.
 */
export declare function toJson_InheritedRole(obj: InheritedRole | undefined): Record<string, any> | undefined;
/**
 * List of resources on which you grant the action.
 *
 * @schema Resource
 */
export interface Resource {
    /**
     * Human-readable label that identifies the collection on which you grant the action to one MongoDB user. If you don't set this parameter, you grant the action to all collections in the database specified in the actions.resources.db parameter. If you set "actions.resources.cluster" : true, MongoDB Cloud ignores this parameter. Use the empty string ("") to allow an action on all collections.
     *
     * @schema Resource#Collection
     */
    readonly collection?: string;
    /**
     * Human-readable label that identifies the database on which you grant the action to one MongoDB user. If you set "actions.resources.cluster" : true, MongoDB Cloud ignores this parameter. Use the empty string ("") to allow an action on all databases.
     *
     * @schema Resource#DB
     */
    readonly db?: string;
    /**
     * Flag that indicates whether to grant the action on the cluster resource. If true, MongoDB Cloud ignores the actions.resources.collection and actions.resources.db parameters.
     *
     * @schema Resource#Cluster
     */
    readonly cluster?: boolean;
}
/**
 * Converts an object of type 'Resource' to JSON representation.
 */
export declare function toJson_Resource(obj: Resource | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::CustomDBRole`
 *
 * @cloudformationResource MongoDB::Atlas::CustomDBRole
 * @stability external
 */
export declare class CfnCustomDbRole extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::CustomDBRole";
    /**
     * Resource props.
     */
    readonly props: CfnCustomDbRoleProps;
    /**
     * Create a new `MongoDB::Atlas::CustomDBRole`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnCustomDbRoleProps);
}
