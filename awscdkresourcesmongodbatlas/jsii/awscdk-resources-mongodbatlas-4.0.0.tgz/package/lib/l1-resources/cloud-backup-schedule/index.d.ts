import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * An example resource schema demonstrating some basic constructs and validation rules.
 *
 * @schema CfnCloudBackupScheduleProps
 */
export interface CfnCloudBackupScheduleProps {
    /**
     * The unique identifier of the project for the Atlas cluster.
     *
     * @schema CfnCloudBackupScheduleProps#ProjectId
     */
    readonly projectId?: string;
    /**
     * The name of the Atlas cluster that contains the snapshots you want to retrieve.
     *
     * @schema CfnCloudBackupScheduleProps#ClusterName
     */
    readonly clusterName?: string;
    /**
     * Unique identifier of the snapshot.
     *
     * @schema CfnCloudBackupScheduleProps#Id
     */
    readonly id?: string;
    /**
     * Flag that indicates whether automatic export of cloud backup snapshots to the AWS bucket is enabled.
     *
     * @schema CfnCloudBackupScheduleProps#AutoExportEnabled
     */
    readonly autoExportEnabled: boolean;
    /**
     * Specify true to use organization and project names instead of organization and project UUIDs in the path for the metadata files that Atlas uploads to your S3 bucket after it finishes exporting the snapshots.
     *
     * @schema CfnCloudBackupScheduleProps#UseOrgAndGroupNamesInExportPrefix
     */
    readonly useOrgAndGroupNamesInExportPrefix?: boolean;
    /**
     * Policy for automatically exporting cloud backup snapshots.
     *
     * @schema CfnCloudBackupScheduleProps#Export
     */
    readonly export?: Export;
    /**
     * List that contains a document for each copy setting item in the desired backup policy.
     *
     * @schema CfnCloudBackupScheduleProps#CopySettings
     */
    readonly copySettings?: ApiAtlasDiskBackupCopySettingView[];
    /**
     * List that contains a document for each deleted copy setting whose backup copies you want to delete.
     *
     * @schema CfnCloudBackupScheduleProps#DeleteCopiedBackups
     */
    readonly deleteCopiedBackups?: ApiDeleteCopiedBackupsView[];
    /**
     * Rules set for this backup schedule.
     *
     * @schema CfnCloudBackupScheduleProps#Policies
     */
    readonly policies?: ApiPolicyView[];
    /**
     * UTC Hour of day between 0 and 23 representing which hour of the day that Atlas takes a snapshot
     *
     * @schema CfnCloudBackupScheduleProps#ReferenceHourOfDay
     */
    readonly referenceHourOfDay?: number;
    /**
     * UTC Minute of day between 0 and 59 representing which minute of the referenceHourOfDay that Atlas takes the snapshot.
     *
     * @schema CfnCloudBackupScheduleProps#ReferenceMinuteOfHour
     */
    readonly referenceMinuteOfHour?: number;
    /**
     * Number of days back in time you can restore to with Continuous Cloud Backup accuracy. Must be a positive, non-zero integer.
     *
     * @schema CfnCloudBackupScheduleProps#RestoreWindowDays
     */
    readonly restoreWindowDays?: number;
    /**
     * Flag indicating if updates to retention in the backup policy were applied to snapshots that Atlas took earlier.
     *
     * @schema CfnCloudBackupScheduleProps#UpdateSnapshots
     */
    readonly updateSnapshots?: boolean;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnCloudBackupScheduleProps#Profile
     */
    readonly profile?: string;
    /**
     * List of one or more Uniform Resource Locators (URLs) that point to API sub-resources, related API resources, or both. RFC 5988 outlines these relationships.
     *
     * @schema CfnCloudBackupScheduleProps#Links
     */
    readonly links?: Link[];
}
/**
 * Converts an object of type 'CfnCloudBackupScheduleProps' to JSON representation.
 */
export declare function toJson_CfnCloudBackupScheduleProps(obj: CfnCloudBackupScheduleProps | undefined): Record<string, any> | undefined;
/**
 * @schema Export
 */
export interface Export {
    /**
     * Unique identifier of the AWS bucket to export the cloud backup snapshot to
     *
     * @schema Export#ExportBucketId
     */
    readonly exportBucketId?: string;
    /**
     * Frequency associated with the export policy. Value can be daily, weekly, monthly or yearly.
     *
     * @schema Export#FrequencyType
     */
    readonly frequencyType?: string;
}
/**
 * Converts an object of type 'Export' to JSON representation.
 */
export declare function toJson_Export(obj: Export | undefined): Record<string, any> | undefined;
/**
 * @schema ApiAtlasDiskBackupCopySettingView
 */
export interface ApiAtlasDiskBackupCopySettingView {
    /**
     * A label that identifies the cloud provider that stores the snapshot copy.
     *
     * @schema ApiAtlasDiskBackupCopySettingView#CloudProvider
     */
    readonly cloudProvider?: string;
    /**
     * Target region to copy snapshots belonging to replicationSpecId to.
     *
     * @schema ApiAtlasDiskBackupCopySettingView#RegionName
     */
    readonly regionName?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the replication object for a zone in a cluster.
     *
     * @schema ApiAtlasDiskBackupCopySettingView#ReplicationSpecId
     */
    readonly replicationSpecId?: string;
    /**
     * Flag that indicates whether to copy the oplogs to the target region.
     *
     * @schema ApiAtlasDiskBackupCopySettingView#ShouldCopyOplogs
     */
    readonly shouldCopyOplogs?: boolean;
    /**
     * List that describes which types of snapshots to copy.
     *
     * @schema ApiAtlasDiskBackupCopySettingView#Frequencies
     */
    readonly frequencies?: string[];
}
/**
 * Converts an object of type 'ApiAtlasDiskBackupCopySettingView' to JSON representation.
 */
export declare function toJson_ApiAtlasDiskBackupCopySettingView(obj: ApiAtlasDiskBackupCopySettingView | undefined): Record<string, any> | undefined;
/**
 * @schema ApiDeleteCopiedBackupsView
 */
export interface ApiDeleteCopiedBackupsView {
    /**
     * A label that identifies the cloud provider for the deleted copy setting whose backup copies you want to delete
     *
     * @schema ApiDeleteCopiedBackupsView#CloudProvider
     */
    readonly cloudProvider?: string;
    /**
     * Target region for the deleted copy setting whose backup copies you want to delete.
     *
     * @schema ApiDeleteCopiedBackupsView#RegionName
     */
    readonly regionName?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the replication object for a zone in a cluster.
     *
     * @schema ApiDeleteCopiedBackupsView#ReplicationSpecId
     */
    readonly replicationSpecId?: string;
}
/**
 * Converts an object of type 'ApiDeleteCopiedBackupsView' to JSON representation.
 */
export declare function toJson_ApiDeleteCopiedBackupsView(obj: ApiDeleteCopiedBackupsView | undefined): Record<string, any> | undefined;
/**
 * @schema ApiPolicyView
 */
export interface ApiPolicyView {
    /**
     * Unique 24-hexadecimal digit string that identifies this backup policy. The policy id can be retrieved by running: atlas backups schedule describe "${clusterName}" --projectId "${projectId}" | jq -r '.policies[0].id'
     *
     * @schema ApiPolicyView#ID
     */
    readonly id?: string;
    /**
     * @schema ApiPolicyView#PolicyItems
     */
    readonly policyItems?: ApiPolicyItemView[];
}
/**
 * Converts an object of type 'ApiPolicyView' to JSON representation.
 */
export declare function toJson_ApiPolicyView(obj: ApiPolicyView | undefined): Record<string, any> | undefined;
/**
 * @schema Link
 */
export interface Link {
    /**
     * Uniform Resource Locator (URL) that points another API resource to which this response has some relationship. This URL often begins with `https://mms.mongodb.com`.
     *
     * @schema Link#Href
     */
    readonly href?: string;
    /**
     * Uniform Resource Locator (URL) that defines the semantic relationship between this resource and another API resource. This URL often begins with `https://mms.mongodb.com`.
     *
     * @schema Link#Rel
     */
    readonly rel?: string;
}
/**
 * Converts an object of type 'Link' to JSON representation.
 */
export declare function toJson_Link(obj: Link | undefined): Record<string, any> | undefined;
/**
 * @schema ApiPolicyItemView
 */
export interface ApiPolicyItemView {
    /**
     * Unique identifier of the backup policy item.
     *
     * @schema ApiPolicyItemView#ID
     */
    readonly id?: string;
    /**
     * Frequency associated with the backup policy item. One of the following values: hourly, daily, weekly, monthly or yearly.
     *
     * @schema ApiPolicyItemView#FrequencyType
     */
    readonly frequencyType?: string;
    /**
     * Desired frequency of the new backup policy item specified by frequencyType.
     *
     * @schema ApiPolicyItemView#FrequencyInterval
     */
    readonly frequencyInterval?: number;
    /**
     * Duration for which the backup is kept. Associated with retentionUnit.
     *
     * @schema ApiPolicyItemView#RetentionValue
     */
    readonly retentionValue?: number;
    /**
     * Metric of duration of the backup policy item: days, weeks, months or years.
     *
     * @schema ApiPolicyItemView#RetentionUnit
     */
    readonly retentionUnit?: string;
}
/**
 * Converts an object of type 'ApiPolicyItemView' to JSON representation.
 */
export declare function toJson_ApiPolicyItemView(obj: ApiPolicyItemView | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::CloudBackupSchedule`
 *
 * @cloudformationResource MongoDB::Atlas::CloudBackupSchedule
 * @stability external
 */
export declare class CfnCloudBackupSchedule extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::CloudBackupSchedule";
    /**
     * Resource props.
     */
    readonly props: CfnCloudBackupScheduleProps;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSchedule.ClusterId`
     */
    readonly attrClusterId: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSchedule.NextSnapshot`
     */
    readonly attrNextSnapshot: string;
    /**
     * Create a new `MongoDB::Atlas::CloudBackupSchedule`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnCloudBackupScheduleProps);
}
