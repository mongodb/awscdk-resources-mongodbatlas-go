import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Creates a secret for the specified Service Account at the organization level.
 *
 * @schema CfnServiceAccountSecretProps
 */
export interface CfnServiceAccountSecretProps {
    /**
     * Unique 24-hexadecimal digit string that identifies the organization that contains your projects.
     *
     * @schema CfnServiceAccountSecretProps#OrgId
     */
    readonly orgId: string;
    /**
     * The Client ID of the Service Account.
     *
     * @schema CfnServiceAccountSecretProps#ClientId
     */
    readonly clientId: string;
    /**
     * The expiration time of the new Service Account secret, provided in hours. The minimum and maximum allowed expiration times are subject to change and are controlled by the organization's settings.
     *
     * @schema CfnServiceAccountSecretProps#SecretExpiresAfterHours
     */
    readonly secretExpiresAfterHours?: number;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used.
     *
     * @schema CfnServiceAccountSecretProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnServiceAccountSecretProps' to JSON representation.
 */
export declare function toJson_CfnServiceAccountSecretProps(obj: CfnServiceAccountSecretProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::ServiceAccountSecret`
 *
 * @cloudformationResource MongoDB::Atlas::ServiceAccountSecret
 * @stability external
 */
export declare class CfnServiceAccountSecret extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ServiceAccountSecret";
    /**
     * Resource props.
     */
    readonly props: CfnServiceAccountSecretProps;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountSecret.SecretId`
     */
    readonly attrSecretId: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountSecret.Secret`
     */
    readonly attrSecret: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountSecret.MaskedSecretValue`
     */
    readonly attrMaskedSecretValue: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountSecret.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountSecret.ExpiresAt`
     */
    readonly attrExpiresAt: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountSecret.LastUsedAt`
     */
    readonly attrLastUsedAt: string;
    /**
     * Create a new `MongoDB::Atlas::ServiceAccountSecret`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnServiceAccountSecretProps);
}
