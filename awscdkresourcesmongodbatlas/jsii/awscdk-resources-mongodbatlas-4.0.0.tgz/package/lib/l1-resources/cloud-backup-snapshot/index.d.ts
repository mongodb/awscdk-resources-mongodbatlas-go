import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, takes, and removes Cloud Backup snapshots.
 *
 * @schema CfnCloudBackupSnapshotProps
 */
export interface CfnCloudBackupSnapshotProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnCloudBackupSnapshotProps#Profile
     */
    readonly profile?: string;
    /**
     * Type of instance specified on the Instance Name.
     *
     * @schema CfnCloudBackupSnapshotProps#InstanceType
     */
    readonly instanceType: CfnCloudBackupSnapshotPropsInstanceType;
    /**
     * Human-readable label that identifies the cluster.
     *
     * @schema CfnCloudBackupSnapshotProps#InstanceName
     */
    readonly instanceName: string;
    /**
     * Human-readable phrase or sentence that explains the purpose of the snapshot. The resource returns this parameter when `"status": "onDemand"`.
     *
     * @schema CfnCloudBackupSnapshotProps#Description
     */
    readonly description?: string;
    /**
     * Human-readable label that identifies how often this snapshot triggers.
     *
     * @schema CfnCloudBackupSnapshotProps#FrequencyType
     */
    readonly frequencyType?: CfnCloudBackupSnapshotPropsFrequencyType;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnCloudBackupSnapshotProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Flag that indicates whether the response returns the total number of items (**totalCount**) in the response.
     *
     * @schema CfnCloudBackupSnapshotProps#IncludeCount
     */
    readonly includeCount?: boolean;
    /**
     * Number of items that the response returns per page.
     *
     * @schema CfnCloudBackupSnapshotProps#ItemsPerPage
     */
    readonly itemsPerPage?: number;
    /**
     * List that includes the snapshots and the cloud provider that stores the snapshots. The resource returns this parameter when `"type" : "SHARDED_CLUSTER"`.
     *
     * @schema CfnCloudBackupSnapshotProps#Members
     */
    readonly members?: ApiAtlasDiskBackupShardedClusterSnapshotMemberView[];
    /**
     * Number of the page that displays the current set of the total objects that the response returns.
     *
     * @schema CfnCloudBackupSnapshotProps#PageNum
     */
    readonly pageNum?: number;
    /**
     * List that contains unique identifiers for the policy items.
     *
     * @schema CfnCloudBackupSnapshotProps#PolicyItems
     */
    readonly policyItems?: string[];
    /**
     * List of returned documents that MongoDB Cloud provides when completing this request.
     *
     * @schema CfnCloudBackupSnapshotProps#Results
     */
    readonly results?: ApiAtlasDiskBackupShardedClusterSnapshotView[];
    /**
     * Number of days that MongoDB Cloud should retain the on-demand snapshot. Must be at least **1**
     *
     * @schema CfnCloudBackupSnapshotProps#RetentionInDays
     */
    readonly retentionInDays?: number;
    /**
     * Human-readable label that identifies when this snapshot triggers.
     *
     * @schema CfnCloudBackupSnapshotProps#SnapshotType
     */
    readonly snapshotType?: CfnCloudBackupSnapshotPropsSnapshotType;
    /**
     * Number of documents returned in this response.
     *
     * @schema CfnCloudBackupSnapshotProps#TotalCount
     */
    readonly totalCount?: number;
}
/**
 * Converts an object of type 'CfnCloudBackupSnapshotProps' to JSON representation.
 */
export declare function toJson_CfnCloudBackupSnapshotProps(obj: CfnCloudBackupSnapshotProps | undefined): Record<string, any> | undefined;
/**
 * Type of instance specified on the Instance Name.
 *
 * @schema CfnCloudBackupSnapshotPropsInstanceType
 */
export declare enum CfnCloudBackupSnapshotPropsInstanceType {
    /** cluster */
    CLUSTER = "cluster"
}
/**
 * Human-readable label that identifies how often this snapshot triggers.
 *
 * @schema CfnCloudBackupSnapshotPropsFrequencyType
 */
export declare enum CfnCloudBackupSnapshotPropsFrequencyType {
    /** hourly */
    HOURLY = "hourly",
    /** daily */
    DAILY = "daily",
    /** weekly */
    WEEKLY = "weekly",
    /** monthly */
    MONTHLY = "monthly"
}
/**
 * @schema ApiAtlasDiskBackupShardedClusterSnapshotMemberView
 */
export interface ApiAtlasDiskBackupShardedClusterSnapshotMemberView {
    /**
     * Human-readable label that identifies the cloud provider that stores this snapshot. The resource returns this parameter when `"type": "replicaSet".`
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotMemberView#CloudProvider
     */
    readonly cloudProvider?: ApiAtlasDiskBackupShardedClusterSnapshotMemberViewCloudProvider;
    /**
     * Unique 24-hexadecimal digit string that identifies the snapshot.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotMemberView#Id
     */
    readonly id?: string;
    /**
     * Human-readable label that identifies the shard or config host from which MongoDB Cloud took this snapshot.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotMemberView#ReplicaSetName
     */
    readonly replicaSetName?: string;
}
/**
 * Converts an object of type 'ApiAtlasDiskBackupShardedClusterSnapshotMemberView' to JSON representation.
 */
export declare function toJson_ApiAtlasDiskBackupShardedClusterSnapshotMemberView(obj: ApiAtlasDiskBackupShardedClusterSnapshotMemberView | undefined): Record<string, any> | undefined;
/**
 * @schema ApiAtlasDiskBackupShardedClusterSnapshotView
 */
export interface ApiAtlasDiskBackupShardedClusterSnapshotView {
    /**
     * Date and time when MongoDB Cloud took the snapshot. This parameter expresses its value in the ISO 8601 timestamp format in UTC.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#CreatedAt
     */
    readonly createdAt?: string;
    /**
     * Human-readable phrase or sentence that explains the purpose of the snapshot. The resource returns this parameter when `"status": "onDemand"`.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#Description
     */
    readonly description?: string;
    /**
     * Date and time when MongoDB Cloud deletes the snapshot. This parameter expresses its value in the ISO 8601 timestamp format in UTC.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#ExpiresAt
     */
    readonly expiresAt?: string;
    /**
     * Human-readable label that identifies how often this snapshot triggers.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#FrequencyType
     */
    readonly frequencyType?: ApiAtlasDiskBackupShardedClusterSnapshotViewFrequencyType;
    /**
     * Unique 24-hexadecimal digit string that identifies the snapshot.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#Id
     */
    readonly id?: string;
    /**
     * Unique string that identifies the Amazon Web Services (AWS) Key Management Service (KMS) Customer Master Key (CMK) used to encrypt the snapshot. The resource returns this value when `"encryptionEnabled" : true`.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#MasterKeyUUID
     */
    readonly masterKeyUuid?: string;
    /**
     * List that includes the snapshots and the cloud provider that stores the snapshots. The resource returns this parameter when `"type" : "SHARDED_CLUSTER"`.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#Members
     */
    readonly members?: ApiAtlasDiskBackupShardedClusterSnapshotMemberView[];
    /**
     * Version of the MongoDB host that this snapshot backs up.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#MongodVersion
     */
    readonly mongodVersion?: string;
    /**
     * List that contains unique identifiers for the policy items.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#PolicyItems
     */
    readonly policyItems?: string[];
    /**
     * List that contains the unique identifiers of the snapshots created for the shards and config host for a sharded cluster. The resource returns this parameter when `"type": "SHARDED_CLUSTER"`. These identifiers should match the ones specified in the **members[n].id** parameters. This allows you to map a snapshot to its shard or config host name.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#SnapshotIds
     */
    readonly snapshotIds?: string[];
    /**
     * Human-readable label that identifies when this snapshot triggers.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#SnapshotType
     */
    readonly snapshotType?: ApiAtlasDiskBackupShardedClusterSnapshotViewSnapshotType;
    /**
     * Human-readable label that indicates the stage of the backup process for this snapshot.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#Status
     */
    readonly status?: ApiAtlasDiskBackupShardedClusterSnapshotViewStatus;
    /**
     * Number of bytes taken to store the backup snapshot.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#StorageSizeBytes
     */
    readonly storageSizeBytes?: string;
    /**
     * Human-readable label that categorizes the cluster as a replica set or sharded cluster.
     *
     * @schema ApiAtlasDiskBackupShardedClusterSnapshotView#Type
     */
    readonly type?: ApiAtlasDiskBackupShardedClusterSnapshotViewType;
}
/**
 * Converts an object of type 'ApiAtlasDiskBackupShardedClusterSnapshotView' to JSON representation.
 */
export declare function toJson_ApiAtlasDiskBackupShardedClusterSnapshotView(obj: ApiAtlasDiskBackupShardedClusterSnapshotView | undefined): Record<string, any> | undefined;
/**
 * Human-readable label that identifies when this snapshot triggers.
 *
 * @schema CfnCloudBackupSnapshotPropsSnapshotType
 */
export declare enum CfnCloudBackupSnapshotPropsSnapshotType {
    /** onDemand */
    ON_DEMAND = "onDemand",
    /** scheduled */
    SCHEDULED = "scheduled"
}
/**
 * Human-readable label that identifies the cloud provider that stores this snapshot. The resource returns this parameter when `"type": "replicaSet".`
 *
 * @schema ApiAtlasDiskBackupShardedClusterSnapshotMemberViewCloudProvider
 */
export declare enum ApiAtlasDiskBackupShardedClusterSnapshotMemberViewCloudProvider {
    /** AWS */
    AWS = "AWS",
    /** AZURE */
    AZURE = "AZURE",
    /** GCP */
    GCP = "GCP"
}
/**
 * Human-readable label that identifies how often this snapshot triggers.
 *
 * @schema ApiAtlasDiskBackupShardedClusterSnapshotViewFrequencyType
 */
export declare enum ApiAtlasDiskBackupShardedClusterSnapshotViewFrequencyType {
    /** hourly */
    HOURLY = "hourly",
    /** daily */
    DAILY = "daily",
    /** weekly */
    WEEKLY = "weekly",
    /** monthly */
    MONTHLY = "monthly"
}
/**
 * Human-readable label that identifies when this snapshot triggers.
 *
 * @schema ApiAtlasDiskBackupShardedClusterSnapshotViewSnapshotType
 */
export declare enum ApiAtlasDiskBackupShardedClusterSnapshotViewSnapshotType {
    /** onDemand */
    ON_DEMAND = "onDemand",
    /** scheduled */
    SCHEDULED = "scheduled"
}
/**
 * Human-readable label that indicates the stage of the backup process for this snapshot.
 *
 * @schema ApiAtlasDiskBackupShardedClusterSnapshotViewStatus
 */
export declare enum ApiAtlasDiskBackupShardedClusterSnapshotViewStatus {
    /** queued */
    QUEUED = "queued",
    /** inProgress */
    IN_PROGRESS = "inProgress",
    /** completed */
    COMPLETED = "completed",
    /** failed */
    FAILED = "failed"
}
/**
 * Human-readable label that categorizes the cluster as a replica set or sharded cluster.
 *
 * @schema ApiAtlasDiskBackupShardedClusterSnapshotViewType
 */
export declare enum ApiAtlasDiskBackupShardedClusterSnapshotViewType {
    /** REPLICA_SET */
    REPLICA_SET = "REPLICA_SET",
    /** SHARDED_CLUSTER */
    SHARDED_CLUSTER = "SHARDED_CLUSTER"
}
/**
 * A CloudFormation `MongoDB::Atlas::CloudBackupSnapshot`
 *
 * @cloudformationResource MongoDB::Atlas::CloudBackupSnapshot
 * @stability external
 */
export declare class CfnCloudBackupSnapshot extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::CloudBackupSnapshot";
    /**
     * Resource props.
     */
    readonly props: CfnCloudBackupSnapshotProps;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.SnapshotId`
     */
    readonly attrSnapshotId: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.SnapshotIds`
     */
    readonly attrSnapshotIds: string[];
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.MasterKeyUUID`
     */
    readonly attrMasterKeyUUID: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.Type`
     */
    readonly attrType: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.ExpiresAt`
     */
    readonly attrExpiresAt: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.StorageSizeBytes`
     */
    readonly attrStorageSizeBytes: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.CloudProvider`
     */
    readonly attrCloudProvider: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.MongodVersion`
     */
    readonly attrMongodVersion: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.ReplicaSetName`
     */
    readonly attrReplicaSetName: string;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshot.Status`
     */
    readonly attrStatus: string;
    /**
     * Create a new `MongoDB::Atlas::CloudBackupSnapshot`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnCloudBackupSnapshotProps);
}
