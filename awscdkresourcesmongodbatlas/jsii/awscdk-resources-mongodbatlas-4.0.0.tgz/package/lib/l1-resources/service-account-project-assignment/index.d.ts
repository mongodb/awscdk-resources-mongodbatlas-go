import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Assigns a Service Account to a Project with specified roles in MongoDB Atlas.
 *
 * @schema CfnServiceAccountProjectAssignmentProps
 */
export interface CfnServiceAccountProjectAssignmentProps {
    /**
     * Unique 24-hexadecimal digit string that identifies the organization. Required for List operation.
     *
     * @schema CfnServiceAccountProjectAssignmentProps#OrgId
     */
    readonly orgId?: string;
    /**
     * The Client ID of the Service Account.
     *
     * @schema CfnServiceAccountProjectAssignmentProps#ClientId
     */
    readonly clientId: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnServiceAccountProjectAssignmentProps#ProjectId
     */
    readonly projectId: string;
    /**
     * The Project permissions for the Service Account in the specified Project.
     *
     * @schema CfnServiceAccountProjectAssignmentProps#Roles
     */
    readonly roles: string[];
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnServiceAccountProjectAssignmentProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnServiceAccountProjectAssignmentProps' to JSON representation.
 */
export declare function toJson_CfnServiceAccountProjectAssignmentProps(obj: CfnServiceAccountProjectAssignmentProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::ServiceAccountProjectAssignment`
 *
 * @cloudformationResource MongoDB::Atlas::ServiceAccountProjectAssignment
 * @stability external
 */
export declare class CfnServiceAccountProjectAssignment extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ServiceAccountProjectAssignment";
    /**
     * Resource props.
     */
    readonly props: CfnServiceAccountProjectAssignmentProps;
    /**
     * Create a new `MongoDB::Atlas::ServiceAccountProjectAssignment`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnServiceAccountProjectAssignmentProps);
}
