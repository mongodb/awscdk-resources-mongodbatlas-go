import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * The exportBuckets resource allows you to grant Atlas access to the specified bucket for exporting backup snapshots.
 *
 * @schema CfnCloudBackupSnapshotExportBucketProps
 */
export interface CfnCloudBackupSnapshotExportBucketProps {
    /**
     * The profile is defined in AWS Secret manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnCloudBackupSnapshotExportBucketProps#Profile
     */
    readonly profile?: string;
    /**
     * Human-readable label that identifies the AWS bucket that the role is authorized to access.
     *
     * @schema CfnCloudBackupSnapshotExportBucketProps#BucketName
     */
    readonly bucketName: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your project.
     *
     * @schema CfnCloudBackupSnapshotExportBucketProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Unique 24-hexadecimal character string that identifies the AWS IAM role that MongoDB Cloud uses to access the AWS S3 bucket.
     *
     * @schema CfnCloudBackupSnapshotExportBucketProps#IamRoleID
     */
    readonly iamRoleId: string;
}
/**
 * Converts an object of type 'CfnCloudBackupSnapshotExportBucketProps' to JSON representation.
 */
export declare function toJson_CfnCloudBackupSnapshotExportBucketProps(obj: CfnCloudBackupSnapshotExportBucketProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::CloudBackupSnapshotExportBucket`
 *
 * @cloudformationResource MongoDB::Atlas::CloudBackupSnapshotExportBucket
 * @stability external
 */
export declare class CfnCloudBackupSnapshotExportBucket extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::CloudBackupSnapshotExportBucket";
    /**
     * Resource props.
     */
    readonly props: CfnCloudBackupSnapshotExportBucketProps;
    /**
     * Attribute `MongoDB::Atlas::CloudBackupSnapshotExportBucket.Id`
     */
    readonly attrId: string;
    /**
     * Create a new `MongoDB::Atlas::CloudBackupSnapshotExportBucket`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnCloudBackupSnapshotExportBucketProps);
}
