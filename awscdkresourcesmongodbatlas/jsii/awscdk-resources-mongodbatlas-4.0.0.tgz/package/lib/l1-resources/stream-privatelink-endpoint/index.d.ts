import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Returns, adds, and removes Atlas Stream Processing Private Link Endpoints. This resource supports AWS only.
 *
 * @schema CfnStreamPrivatelinkEndpointProps
 */
export interface CfnStreamPrivatelinkEndpointProps {
    /**
     * Unique 24-hexadecimal digit string that identifies your project. Use the [/groups](#tag/Projects/operation/listProjects) endpoint to retrieve all projects to which the authenticated user has access. **NOTE**: Groups and projects are synonymous terms. Your group id is the same as your project id. For existing groups, your group or project id remains the same. The resource and corresponding endpoints use the term groups.
     *
     * @schema CfnStreamPrivatelinkEndpointProps#ProjectId
     */
    readonly projectId: string;
    /**
     * Provider where the endpoint is deployed. For CloudFormation, this is always AWS.
     *
     * @schema CfnStreamPrivatelinkEndpointProps#ProviderName
     */
    readonly providerName: string;
    /**
     * Vendor that manages the endpoint. For AWS, valid values are: MSK, CONFLUENT, and S3.
     *
     * @schema CfnStreamPrivatelinkEndpointProps#Vendor
     */
    readonly vendor: string;
    /**
     * The region of the Provider's cluster. See [AWS](https://www.mongodb.com/docs/atlas/reference/amazon-aws/#stream-processing-instances) supported regions. When the vendor is CONFLUENT, this is the domain name of Confluent cluster. When the vendor is MSK, this is computed by the API from the provided ARN.
     *
     * @schema CfnStreamPrivatelinkEndpointProps#Region
     */
    readonly region?: string;
    /**
     * For AWS CONFLUENT cluster, this is the [VPC Endpoint service name](https://docs.confluent.io/cloud/current/networking/private-links/aws-privatelink.html). For AWS S3 vendor, this should follow the format 'com.amazonaws.<region>.s3', for example 'com.amazonaws.us-east-1.s3'.
     *
     * @schema CfnStreamPrivatelinkEndpointProps#ServiceEndpointId
     */
    readonly serviceEndpointId?: string;
    /**
     * Amazon Resource Name (ARN). Required for AWS Provider and MSK vendor.
     *
     * @schema CfnStreamPrivatelinkEndpointProps#Arn
     */
    readonly arn?: string;
    /**
     * The domain hostname. Required for AWS provider with CONFLUENT vendor.
     *
     * @schema CfnStreamPrivatelinkEndpointProps#DnsDomain
     */
    readonly dnsDomain?: string;
    /**
     * Sub-Domain name of Confluent cluster. These are typically your availability zones. Required for AWS Provider and CONFLUENT vendor. If your AWS CONFLUENT cluster doesn't use subdomains, you must set this to the empty array [].
     *
     * @schema CfnStreamPrivatelinkEndpointProps#DnsSubDomain
     */
    readonly dnsSubDomain?: string[];
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used
     *
     * @schema CfnStreamPrivatelinkEndpointProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnStreamPrivatelinkEndpointProps' to JSON representation.
 */
export declare function toJson_CfnStreamPrivatelinkEndpointProps(obj: CfnStreamPrivatelinkEndpointProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::StreamPrivatelinkEndpoint`
 *
 * @cloudformationResource MongoDB::Atlas::StreamPrivatelinkEndpoint
 * @stability external
 */
export declare class CfnStreamPrivatelinkEndpoint extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::StreamPrivatelinkEndpoint";
    /**
     * Resource props.
     */
    readonly props: CfnStreamPrivatelinkEndpointProps;
    /**
     * Attribute `MongoDB::Atlas::StreamPrivatelinkEndpoint.Id`
     */
    readonly attrId: string;
    /**
     * Attribute `MongoDB::Atlas::StreamPrivatelinkEndpoint.InterfaceEndpointId`
     */
    readonly attrInterfaceEndpointId: string;
    /**
     * Attribute `MongoDB::Atlas::StreamPrivatelinkEndpoint.InterfaceEndpointName`
     */
    readonly attrInterfaceEndpointName: string;
    /**
     * Attribute `MongoDB::Atlas::StreamPrivatelinkEndpoint.ProviderAccountId`
     */
    readonly attrProviderAccountId: string;
    /**
     * Attribute `MongoDB::Atlas::StreamPrivatelinkEndpoint.State`
     */
    readonly attrState: string;
    /**
     * Attribute `MongoDB::Atlas::StreamPrivatelinkEndpoint.ErrorMessage`
     */
    readonly attrErrorMessage: string;
    /**
     * Create a new `MongoDB::Atlas::StreamPrivatelinkEndpoint`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnStreamPrivatelinkEndpointProps);
}
