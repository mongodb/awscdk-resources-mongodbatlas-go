import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Resource for managing MongoDB Atlas Federated Settings Identity Providers (SAML and OIDC) within an Atlas federation.
 *
 * @schema CfnFederatedSettingsIdentityProviderProps
 */
export interface CfnFederatedSettingsIdentityProviderProps {
    /**
     * The profile is defined in AWS Secrets Manager. See [Secret Manager Profile setup](../../../examples/profile-secret.yaml).
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#Profile
     */
    readonly profile?: string;
    /**
     * Unique 24-hexadecimal digit string that identifies your federation.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#FederationSettingsId
     */
    readonly federationSettingsId: string;
    /**
     * Human-readable name (display name) of the identity provider.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#Name
     */
    readonly name: string;
    /**
     * Issuer URI of the identity provider.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#IssuerUri
     */
    readonly issuerUri: string;
    /**
     * SAML request binding.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#RequestBinding
     */
    readonly requestBinding?: string;
    /**
     * SAML response signature algorithm.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#ResponseSignatureAlgorithm
     */
    readonly responseSignatureAlgorithm?: string;
    /**
     * List of associated domains for this identity provider.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#AssociatedDomains
     */
    readonly associatedDomains?: string[];
    /**
     * Flag that indicates whether to enable SSO debug.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#SsoDebugEnabled
     */
    readonly ssoDebugEnabled?: boolean;
    /**
     * SSO URL.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#SsoUrl
     */
    readonly ssoUrl?: string;
    /**
     * Identity provider status.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#Status
     */
    readonly status?: string;
    /**
     * Identity provider protocol.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#Protocol
     */
    readonly protocol?: CfnFederatedSettingsIdentityProviderPropsProtocol;
    /**
     * OIDC audience.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#Audience
     */
    readonly audience?: string;
    /**
     * OIDC client ID.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#ClientId
     */
    readonly clientId?: string;
    /**
     * OIDC groups claim.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#GroupsClaim
     */
    readonly groupsClaim?: string;
    /**
     * OIDC requested scopes.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#RequestedScopes
     */
    readonly requestedScopes?: string[];
    /**
     * OIDC user claim.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#UserClaim
     */
    readonly userClaim?: string;
    /**
     * Description of the identity provider.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#Description
     */
    readonly description?: string;
    /**
     * OIDC authorization type.
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#AuthorizationType
     */
    readonly authorizationType?: string;
    /**
     * Identity provider type (for OIDC).
     *
     * @schema CfnFederatedSettingsIdentityProviderProps#IdpType
     */
    readonly idpType?: string;
}
/**
 * Converts an object of type 'CfnFederatedSettingsIdentityProviderProps' to JSON representation.
 */
export declare function toJson_CfnFederatedSettingsIdentityProviderProps(obj: CfnFederatedSettingsIdentityProviderProps | undefined): Record<string, any> | undefined;
/**
 * Identity provider protocol.
 *
 * @schema CfnFederatedSettingsIdentityProviderPropsProtocol
 */
export declare enum CfnFederatedSettingsIdentityProviderPropsProtocol {
    /** SAML */
    SAML = "SAML",
    /** OIDC */
    OIDC = "OIDC"
}
/**
 * A CloudFormation `MongoDB::Atlas::FederatedSettingsIdentityProvider`
 *
 * @cloudformationResource MongoDB::Atlas::FederatedSettingsIdentityProvider
 * @stability external
 */
export declare class CfnFederatedSettingsIdentityProvider extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::FederatedSettingsIdentityProvider";
    /**
     * Resource props.
     */
    readonly props: CfnFederatedSettingsIdentityProviderProps;
    /**
     * Attribute `MongoDB::Atlas::FederatedSettingsIdentityProvider.OktaIdpId`
     */
    readonly attrOktaIdpId: string;
    /**
     * Attribute `MongoDB::Atlas::FederatedSettingsIdentityProvider.IdpId`
     */
    readonly attrIdpId: string;
    /**
     * Create a new `MongoDB::Atlas::FederatedSettingsIdentityProvider`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnFederatedSettingsIdentityProviderProps);
}
