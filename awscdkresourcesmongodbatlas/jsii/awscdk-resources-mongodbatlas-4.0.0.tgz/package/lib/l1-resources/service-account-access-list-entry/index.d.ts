import * as cdk from "aws-cdk-lib";
import * as constructs from "constructs";
/**
 * Manages IP access list entries for MongoDB Atlas Service Accounts at the organization level.
 *
 * @schema CfnServiceAccountAccessListEntryProps
 */
export interface CfnServiceAccountAccessListEntryProps {
    /**
     * Unique 24-hexadecimal digit string that identifies the organization.
     *
     * @schema CfnServiceAccountAccessListEntryProps#OrgId
     */
    readonly orgId: string;
    /**
     * The Client ID of the Service Account.
     *
     * @schema CfnServiceAccountAccessListEntryProps#ClientId
     */
    readonly clientId: string;
    /**
     * Range of IP addresses in CIDR notation to be added to the access list. You can set a value for this parameter or IPAddress, but not both.
     *
     * @schema CfnServiceAccountAccessListEntryProps#CIDRBlock
     */
    readonly cidrBlock?: string;
    /**
     * Single IP address to be added to the access list. You can set a value for this parameter or CIDRBlock, but not both.
     *
     * @schema CfnServiceAccountAccessListEntryProps#IPAddress
     */
    readonly ipAddress?: string;
    /**
     * Profile used to provide credentials information, (a secret with the cfn/atlas/profile/{Profile}, is required), if not provided default is used.
     *
     * @schema CfnServiceAccountAccessListEntryProps#Profile
     */
    readonly profile?: string;
}
/**
 * Converts an object of type 'CfnServiceAccountAccessListEntryProps' to JSON representation.
 */
export declare function toJson_CfnServiceAccountAccessListEntryProps(obj: CfnServiceAccountAccessListEntryProps | undefined): Record<string, any> | undefined;
/**
 * A CloudFormation `MongoDB::Atlas::ServiceAccountAccessListEntry`
 *
 * @cloudformationResource MongoDB::Atlas::ServiceAccountAccessListEntry
 * @stability external
 */
export declare class CfnServiceAccountAccessListEntry extends cdk.CfnResource {
    /**
     * The CloudFormation resource type name for this resource class.
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "MongoDB::Atlas::ServiceAccountAccessListEntry";
    /**
     * Resource props.
     */
    readonly props: CfnServiceAccountAccessListEntryProps;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountAccessListEntry.CreatedAt`
     */
    readonly attrCreatedAt: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountAccessListEntry.LastUsedAddress`
     */
    readonly attrLastUsedAddress: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountAccessListEntry.LastUsedAt`
     */
    readonly attrLastUsedAt: string;
    /**
     * Attribute `MongoDB::Atlas::ServiceAccountAccessListEntry.RequestCount`
     */
    readonly attrRequestCount: number;
    /**
     * Create a new `MongoDB::Atlas::ServiceAccountAccessListEntry`.
     *
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: constructs.Construct, id: string, props: CfnServiceAccountAccessListEntryProps);
}
